window.YTD.profile.part0 = [
  {
    "profile" : {
      "description" : {
        "bio" : "I put unicode characters in certain orders which you may or may not find enjoyable, with the occasional rectangle of colored pixels.",
        "website" : "",
        "location" : ""
      },
      "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/1177020068691152898/-kl_OZKZ.jpg",
      "headerMediaUrl" : "https://pbs.twimg.com/profile_banners/2444552670/1569460092"
    }
  }
]