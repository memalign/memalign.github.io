window.YTD.twitter_circle.part0 = [
  {
    "twitterCircle" : {
      "id" : "1539226233271115776",
      "ownerUserId" : "2444552670",
      "createdAt" : "2022-06-21T12:38:26.108Z"
    }
  }
]