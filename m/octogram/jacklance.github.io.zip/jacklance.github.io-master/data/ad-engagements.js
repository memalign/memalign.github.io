window.YTD.ad_engagements.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89971",
                  "name" : "#GalaxyZFlip4",
                  "description" : ""
                },
                "advertiserInfo" : {
                  "advertiserName" : "Samsung Mobile US",
                  "screenName" : "@SamsungMobileUS"
                },
                "impressionTime" : "2022-08-11 01:53:22"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-11 01:53:23",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89971",
                  "name" : "#GalaxyZFlip4",
                  "description" : ""
                },
                "advertiserInfo" : {
                  "advertiserName" : "Samsung Mobile US",
                  "screenName" : "@SamsungMobileUS"
                },
                "impressionTime" : "2022-08-10 22:15:38"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-10 22:15:39",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89992",
                  "name" : "#BodiesBodiesBodies",
                  "description" : "Now Playing in Theaters Everywhere"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Bodies Bodies Bodies",
                  "screenName" : "@bodiesbodies"
                },
                "impressionTime" : "2022-08-11 14:55:57"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-11 14:55:58",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89992",
                  "name" : "#BodiesBodiesBodies",
                  "description" : "Now Playing in Theaters Everywhere"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Bodies Bodies Bodies",
                  "screenName" : "@bodiesbodies"
                },
                "impressionTime" : "2022-08-11 14:55:36"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-11 14:55:37",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89971",
                  "name" : "#GalaxyZFlip4",
                  "description" : ""
                },
                "advertiserInfo" : {
                  "advertiserName" : "Samsung Mobile US",
                  "screenName" : "@SamsungMobileUS"
                },
                "impressionTime" : "2022-08-11 03:07:46"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-11 03:07:49",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89992",
                  "name" : "#BodiesBodiesBodies",
                  "description" : "Now Playing in Theaters Everywhere"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Bodies Bodies Bodies",
                  "screenName" : "@bodiesbodies"
                },
                "impressionTime" : "2022-08-11 13:00:26"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-11 13:00:27",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89992",
                  "name" : "#BodiesBodiesBodies",
                  "description" : "Now Playing in Theaters Everywhere"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Bodies Bodies Bodies",
                  "screenName" : "@bodiesbodies"
                },
                "impressionTime" : "2022-08-11 13:18:10"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-11 13:18:11",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89663",
                  "name" : "#HOTD",
                  "description" : "Streaming tonight at 9PM"
                },
                "advertiserInfo" : {
                  "advertiserName" : "HBO Max",
                  "screenName" : "@hbomax"
                },
                "impressionTime" : "2022-08-21 22:46:57"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-21 22:46:57",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89663",
                  "name" : "#HOTD",
                  "description" : "Streaming tonight at 9PM"
                },
                "advertiserInfo" : {
                  "advertiserName" : "HBO Max",
                  "screenName" : "@hbomax"
                },
                "impressionTime" : "2022-08-22 03:06:19"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-22 03:06:20",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90079",
                  "name" : "#TheRingsOfPower",
                  "description" : "New Trailer Tomorrow"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Prime Video",
                  "screenName" : "@PrimeVideo"
                },
                "impressionTime" : "2022-08-22 14:38:43"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-22 14:38:44",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90079",
                  "name" : "#TheRingsOfPower",
                  "description" : "New Trailer Tomorrow"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Prime Video",
                  "screenName" : "@PrimeVideo"
                },
                "impressionTime" : "2022-08-22 14:30:48"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-22 14:30:49",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90079",
                  "name" : "#TheRingsOfPower",
                  "description" : "New Trailer Tomorrow"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Prime Video",
                  "screenName" : "@PrimeVideo"
                },
                "impressionTime" : "2022-08-22 21:23:21"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-22 21:23:22",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1545092606736175104",
                  "tweetText" : "Eat your food not your words; take the EXTRA pause #ChewItBeforeYouDoIt",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "EXTRA GUM",
                  "screenName" : "@ExtraGum"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "13 to 49"
                  }
                ],
                "impressionTime" : "2022-08-27 03:00:58"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-27 03:01:00",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90228",
                  "name" : "#MyStyleIsMyPower",
                  "description" : "Style is a superpower. Own it."
                },
                "advertiserInfo" : {
                  "advertiserName" : "TRESemmé",
                  "screenName" : "@TRESemme"
                },
                "impressionTime" : "2022-08-27 20:18:09"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-27 20:18:10",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90081",
                  "name" : "#TheRingsOfPower",
                  "description" : "Watch the first two episodes now"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Prime Video",
                  "screenName" : "@PrimeVideo"
                },
                "impressionTime" : "2022-09-02 13:17:01"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-02 13:17:02",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90081",
                  "name" : "#TheRingsOfPower",
                  "description" : "Watch the first two episodes now"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Prime Video",
                  "screenName" : "@PrimeVideo"
                },
                "impressionTime" : "2022-09-02 19:52:08"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-02 19:52:09",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90463",
                  "name" : "#DisneyPinocchio",
                  "description" : "Stream it Thursday #DisneyPlusDay"
                },
                "advertiserInfo" : {
                  "advertiserName" : "DisneyPinocchio",
                  "screenName" : "@DisneyPinocchio"
                },
                "impressionTime" : "2022-09-05 21:05:12"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-05 21:05:12",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1552713429563150338",
                  "tweetText" : "Nothing cools tension quite like the fun of ice cream, especially when M&amp;M'S Ice Cream Cookie Sandwiches are involved.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "M&M'S",
                  "screenName" : "@mmschocolate"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "13 to 49"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  }
                ],
                "impressionTime" : "2022-09-05 21:43:17"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-05 21:43:18",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90463",
                  "name" : "#DisneyPinocchio",
                  "description" : "Stream it Thursday #DisneyPlusDay"
                },
                "advertiserInfo" : {
                  "advertiserName" : "DisneyPinocchio",
                  "screenName" : "@DisneyPinocchio"
                },
                "impressionTime" : "2022-09-05 21:29:13"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-05 21:29:14",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90490",
                  "name" : "#DisneyPlusDay",
                  "description" : "Join the celebration on 9/8!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-09-06 14:10:31"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-06 14:10:32",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90490",
                  "name" : "#DisneyPlusDay",
                  "description" : "Join the celebration on 9/8!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-09-06 14:04:00"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-06 14:04:01",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90490",
                  "name" : "#DisneyPlusDay",
                  "description" : "Join the celebration on 9/8!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-09-06 13:42:37"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-06 13:42:38",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90490",
                  "name" : "#DisneyPlusDay",
                  "description" : "Join the celebration on 9/8!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-09-06 17:49:55"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-06 17:49:56",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89992",
                  "name" : "#BodiesBodiesBodies",
                  "description" : "Now Playing in Theaters Everywhere"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Bodies Bodies Bodies",
                  "screenName" : "@bodiesbodies"
                },
                "impressionTime" : "2022-08-11 19:36:49"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-11 19:36:50",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89992",
                  "name" : "#BodiesBodiesBodies",
                  "description" : "Now Playing in Theaters Everywhere"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Bodies Bodies Bodies",
                  "screenName" : "@bodiesbodies"
                },
                "impressionTime" : "2022-08-11 22:04:37"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-11 22:04:38",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "SearchTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1556739584666501123",
                  "tweetText" : "New White Claw REFRSHR Hard Seltzer Lemonade Strawberry with a hint of kiwi.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "White Claw Hard Seltzer",
                  "screenName" : "@WhiteClaw"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Fashion Tags"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "21 to 34"
                  }
                ],
                "impressionTime" : "2022-08-11 22:04:46"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-11 22:05:48",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89992",
                  "name" : "#BodiesBodiesBodies",
                  "description" : "Now Playing in Theaters Everywhere"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Bodies Bodies Bodies",
                  "screenName" : "@bodiesbodies"
                },
                "impressionTime" : "2022-08-11 18:53:28"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-11 18:53:29",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89992",
                  "name" : "#BodiesBodiesBodies",
                  "description" : "Now Playing in Theaters Everywhere"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Bodies Bodies Bodies",
                  "screenName" : "@bodiesbodies"
                },
                "impressionTime" : "2022-08-11 18:51:59"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-11 18:52:00",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89992",
                  "name" : "#BodiesBodiesBodies",
                  "description" : "Now Playing in Theaters Everywhere"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Bodies Bodies Bodies",
                  "screenName" : "@bodiesbodies"
                },
                "impressionTime" : "2022-08-11 18:51:35"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-11 18:51:36",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90490",
                  "name" : "#DisneyPlusDay",
                  "description" : "Join the celebration on 9/8!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-09-07 03:27:43"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-07 03:27:45",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89964",
                  "name" : "#NFLplus",
                  "description" : "Stream #BUFvsLAR tomorrow night, LIVE on NFL+, and NEVER miss a moment"
                },
                "advertiserInfo" : {
                  "advertiserName" : "NFL",
                  "screenName" : "@NFL"
                },
                "impressionTime" : "2022-09-07 14:22:00"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-07 14:22:00",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89964",
                  "name" : "#NFLplus",
                  "description" : "Stream #BUFvsLAR tomorrow night, LIVE on NFL+, and NEVER miss a moment"
                },
                "advertiserInfo" : {
                  "advertiserName" : "NFL",
                  "screenName" : "@NFL"
                },
                "impressionTime" : "2022-09-07 20:15:43"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-07 20:15:45",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89964",
                  "name" : "#NFLplus",
                  "description" : "Stream #BUFvsLAR tomorrow night, LIVE on NFL+, and NEVER miss a moment"
                },
                "advertiserInfo" : {
                  "advertiserName" : "NFL",
                  "screenName" : "@NFL"
                },
                "impressionTime" : "2022-09-08 01:37:01"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-08 01:37:02",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89964",
                  "name" : "#NFLplus",
                  "description" : "Stream #BUFvsLAR tomorrow night, LIVE on NFL+, and NEVER miss a moment"
                },
                "advertiserInfo" : {
                  "advertiserName" : "NFL",
                  "screenName" : "@NFL"
                },
                "impressionTime" : "2022-09-07 17:31:07"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-07 17:31:08",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89866",
                  "name" : "#StarTrekDay",
                  "description" : "Stream every Star Trek series exclusively on Paramount+."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Star Trek on Paramount+",
                  "screenName" : "@StarTrekOnPPlus"
                },
                "impressionTime" : "2022-09-08 13:27:28"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-08 13:27:29",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89964",
                  "name" : "#NFLplus",
                  "description" : "Stream #BUFvsLAR tomorrow night, LIVE on NFL+, and NEVER miss a moment"
                },
                "advertiserInfo" : {
                  "advertiserName" : "NFL",
                  "screenName" : "@NFL"
                },
                "impressionTime" : "2022-09-08 03:09:34"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-08 03:09:35",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89866",
                  "name" : "#StarTrekDay",
                  "description" : "Stream every Star Trek series exclusively on Paramount+."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Star Trek on Paramount+",
                  "screenName" : "@StarTrekOnPPlus"
                },
                "impressionTime" : "2022-09-09 01:56:09"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-09 01:56:10",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1565820029119217665",
                  "tweetText" : "Reason #2 to use Carmyn's carbon-neutral-gasoline delivery service: \n\nHelp build a clean energy future now. For everyone. \nCarmyn uses the revenue from its delivery service to build solar energy installations in the communities that Carmyn serves. https://t.co/tdMKb6lWsA",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/tdMKb6lWsA"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Carmyn Inc.",
                  "screenName" : "@CarmynInc"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "01742"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "13 and up"
                  }
                ],
                "impressionTime" : "2022-09-09 01:49:39"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-09 01:49:40",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89866",
                  "name" : "#StarTrekDay",
                  "description" : "Stream every Star Trek series exclusively on Paramount+."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Star Trek on Paramount+",
                  "screenName" : "@StarTrekOnPPlus"
                },
                "impressionTime" : "2022-09-09 01:46:04"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-09 01:46:05",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89866",
                  "name" : "#StarTrekDay",
                  "description" : "Stream every Star Trek series exclusively on Paramount+."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Star Trek on Paramount+",
                  "screenName" : "@StarTrekOnPPlus"
                },
                "impressionTime" : "2022-09-09 01:22:05"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-09 01:22:05",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89866",
                  "name" : "#StarTrekDay",
                  "description" : "Stream every Star Trek series exclusively on Paramount+."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Star Trek on Paramount+",
                  "screenName" : "@StarTrekOnPPlus"
                },
                "impressionTime" : "2022-09-09 01:43:05"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-09 01:43:06",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89866",
                  "name" : "#StarTrekDay",
                  "description" : "Stream every Star Trek series exclusively on Paramount+."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Star Trek on Paramount+",
                  "screenName" : "@StarTrekOnPPlus"
                },
                "impressionTime" : "2022-09-08 21:14:16"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-08 21:14:17",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89866",
                  "name" : "#StarTrekDay",
                  "description" : "Stream every Star Trek series exclusively on Paramount+."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Star Trek on Paramount+",
                  "screenName" : "@StarTrekOnPPlus"
                },
                "impressionTime" : "2022-09-08 21:05:11"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-08 21:05:11",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89866",
                  "name" : "#StarTrekDay",
                  "description" : "Stream every Star Trek series exclusively on Paramount+."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Star Trek on Paramount+",
                  "screenName" : "@StarTrekOnPPlus"
                },
                "impressionTime" : "2022-09-09 00:46:44"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-09 00:46:45",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89866",
                  "name" : "#StarTrekDay",
                  "description" : "Stream every Star Trek series exclusively on Paramount+."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Star Trek on Paramount+",
                  "screenName" : "@StarTrekOnPPlus"
                },
                "impressionTime" : "2022-09-08 20:20:02"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-08 20:20:04",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89866",
                  "name" : "#StarTrekDay",
                  "description" : "Stream every Star Trek series exclusively on Paramount+."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Star Trek on Paramount+",
                  "screenName" : "@StarTrekOnPPlus"
                },
                "impressionTime" : "2022-09-08 20:49:18"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-08 20:49:18",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89866",
                  "name" : "#StarTrekDay",
                  "description" : "Stream every Star Trek series exclusively on Paramount+."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Star Trek on Paramount+",
                  "screenName" : "@StarTrekOnPPlus"
                },
                "impressionTime" : "2022-09-08 20:30:57"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-08 20:30:58",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89866",
                  "name" : "#StarTrekDay",
                  "description" : "Stream every Star Trek series exclusively on Paramount+."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Star Trek on Paramount+",
                  "screenName" : "@StarTrekOnPPlus"
                },
                "impressionTime" : "2022-09-08 20:40:27"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-08 20:40:28",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89866",
                  "name" : "#StarTrekDay",
                  "description" : "Stream every Star Trek series exclusively on Paramount+."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Star Trek on Paramount+",
                  "screenName" : "@StarTrekOnPPlus"
                },
                "impressionTime" : "2022-09-09 02:16:36"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-09 02:16:37",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89866",
                  "name" : "#StarTrekDay",
                  "description" : "Stream every Star Trek series exclusively on Paramount+."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Star Trek on Paramount+",
                  "screenName" : "@StarTrekOnPPlus"
                },
                "impressionTime" : "2022-09-09 02:36:04"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-09 02:36:05",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89866",
                  "name" : "#StarTrekDay",
                  "description" : "Stream every Star Trek series exclusively on Paramount+."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Star Trek on Paramount+",
                  "screenName" : "@StarTrekOnPPlus"
                },
                "impressionTime" : "2022-09-09 03:04:18"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-09 03:04:20",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89866",
                  "name" : "#StarTrekDay",
                  "description" : "Stream every Star Trek series exclusively on Paramount+."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Star Trek on Paramount+",
                  "screenName" : "@StarTrekOnPPlus"
                },
                "impressionTime" : "2022-09-09 03:28:21"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-09 03:28:22",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89866",
                  "name" : "#StarTrekDay",
                  "description" : "Stream every Star Trek series exclusively on Paramount+."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Star Trek on Paramount+",
                  "screenName" : "@StarTrekOnPPlus"
                },
                "impressionTime" : "2022-09-09 03:21:58"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-09 03:21:59",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90624",
                  "name" : "#DisneyPlus",
                  "description" : "Disney+ is $1.99 for 1 month!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-09-09 10:56:57"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-09 10:56:58",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90624",
                  "name" : "#DisneyPlus",
                  "description" : "Disney+ is $1.99 for 1 month!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-09-09 11:04:28"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-09 11:04:30",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90624",
                  "name" : "#DisneyPlus",
                  "description" : "Disney+ is $1.99 for 1 month!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-09-09 11:08:34"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-09 11:08:35",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90624",
                  "name" : "#DisneyPlus",
                  "description" : "Disney+ is $1.99 for 1 month!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-09-09 11:07:28"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-09 11:07:28",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90624",
                  "name" : "#DisneyPlus",
                  "description" : "Disney+ is $1.99 for 1 month!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-09-09 11:11:13"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-09 11:11:15",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90624",
                  "name" : "#DisneyPlus",
                  "description" : "Disney+ is $1.99 for 1 month!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-09-09 13:16:02"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-09 13:16:03",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90624",
                  "name" : "#DisneyPlus",
                  "description" : "Disney+ is $1.99 for 1 month!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-09-09 19:19:56"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-09 19:19:57",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90624",
                  "name" : "#DisneyPlus",
                  "description" : "Disney+ is $1.99 for 1 month!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-09-09 16:31:35"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-09 16:31:36",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90624",
                  "name" : "#DisneyPlus",
                  "description" : "Disney+ is $1.99 for 1 month!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-09-09 23:48:11"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-09 23:48:12",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90624",
                  "name" : "#DisneyPlus",
                  "description" : "Disney+ is $1.99 for 1 month!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-09-09 17:48:34"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-09 17:48:35",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90632",
                  "name" : "#AsteproAndGo",
                  "description" : "Starts working in 30 minutes"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Astepro® Allergy",
                  "screenName" : "@astepro_us"
                },
                "impressionTime" : "2022-09-10 12:15:02"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-10 12:15:02",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1568280028080644097",
                  "tweetText" : "Today, we remember the lives lost on 9/11 and honor the resilience of our home. https://t.co/NqvGiU0eX8",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/NqvGiU0eX8"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Con Edison",
                  "screenName" : "@ConEdison"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Manhattan"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2022-09-11 12:03:46"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-11 12:03:47",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90632",
                  "name" : "#AsteproAndGo",
                  "description" : "Starts working in 30 minutes"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Astepro® Allergy",
                  "screenName" : "@astepro_us"
                },
                "impressionTime" : "2022-09-11 04:06:40"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-11 04:06:41",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90632",
                  "name" : "#AsteproAndGo",
                  "description" : "Starts working in 30 minutes"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Astepro® Allergy",
                  "screenName" : "@astepro_us"
                },
                "impressionTime" : "2022-09-11 03:45:11"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-11 03:45:13",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90632",
                  "name" : "#AsteproAndGo",
                  "description" : "Starts working in 30 minutes"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Astepro® Allergy",
                  "screenName" : "@astepro_us"
                },
                "impressionTime" : "2022-09-11 03:42:23"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-11 03:42:25",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90632",
                  "name" : "#AsteproAndGo",
                  "description" : "Starts working in 30 minutes"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Astepro® Allergy",
                  "screenName" : "@astepro_us"
                },
                "impressionTime" : "2022-09-11 03:51:10"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-11 03:51:12",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86355",
                  "name" : "#Flonase",
                  "description" : "Defeat Allergy Headaches Fast!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Flonase",
                  "screenName" : "@flonase"
                },
                "impressionTime" : "2022-09-12 16:38:19"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-12 16:38:20",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86355",
                  "name" : "#Flonase",
                  "description" : "Defeat Allergy Headaches Fast!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Flonase",
                  "screenName" : "@flonase"
                },
                "impressionTime" : "2022-09-13 02:31:29"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-13 02:31:30",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86355",
                  "name" : "#Flonase",
                  "description" : "Defeat Allergy Headaches Fast!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Flonase",
                  "screenName" : "@flonase"
                },
                "impressionTime" : "2022-09-13 02:31:38"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-13 02:31:39",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86355",
                  "name" : "#Flonase",
                  "description" : "Defeat Allergy Headaches Fast!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Flonase",
                  "screenName" : "@flonase"
                },
                "impressionTime" : "2022-09-13 02:31:43"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-13 02:31:44",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86355",
                  "name" : "#Flonase",
                  "description" : "Defeat Allergy Headaches Fast!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Flonase",
                  "screenName" : "@flonase"
                },
                "impressionTime" : "2022-09-13 02:15:10"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-13 02:15:11",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86355",
                  "name" : "#Flonase",
                  "description" : "Defeat Allergy Headaches Fast!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Flonase",
                  "screenName" : "@flonase"
                },
                "impressionTime" : "2022-09-13 01:51:27"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-13 01:51:29",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86355",
                  "name" : "#Flonase",
                  "description" : "Defeat Allergy Headaches Fast!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Flonase",
                  "screenName" : "@flonase"
                },
                "impressionTime" : "2022-09-13 01:58:09"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-13 01:58:10",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86355",
                  "name" : "#Flonase",
                  "description" : "Defeat Allergy Headaches Fast!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Flonase",
                  "screenName" : "@flonase"
                },
                "impressionTime" : "2022-09-13 01:45:48"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-13 01:45:49",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86355",
                  "name" : "#Flonase",
                  "description" : "Defeat Allergy Headaches Fast!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Flonase",
                  "screenName" : "@flonase"
                },
                "impressionTime" : "2022-09-12 23:26:10"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-12 23:26:12",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90728",
                  "name" : "#SmarterNotHarder",
                  "description" : "Your way to conquer the market"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Tiger.Trade",
                  "screenName" : "@tiger_trade"
                },
                "impressionTime" : "2022-09-13 15:45:24"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-13 15:45:24",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90023",
                  "name" : "#FYC",
                  "description" : "Watch Severance on Apple TV+"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Apple TV+",
                  "screenName" : "@AppleTVPlus"
                },
                "impressionTime" : "2022-08-12 20:40:54"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-12 20:40:55",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90023",
                  "name" : "#FYC",
                  "description" : "Watch Severance on Apple TV+"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Apple TV+",
                  "screenName" : "@AppleTVPlus"
                },
                "impressionTime" : "2022-08-12 20:16:07"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-12 20:16:08",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90023",
                  "name" : "#FYC",
                  "description" : "Watch Severance on Apple TV+"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Apple TV+",
                  "screenName" : "@AppleTVPlus"
                },
                "impressionTime" : "2022-08-12 20:16:05"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-12 20:16:06",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90023",
                  "name" : "#FYC",
                  "description" : "Watch Severance on Apple TV+"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Apple TV+",
                  "screenName" : "@AppleTVPlus"
                },
                "impressionTime" : "2022-08-12 23:20:15"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-12 23:20:16",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1554914360836988929",
                  "tweetText" : "Supercharge your home with supersonic WiFi, ultra-fast and incredibly powerful.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Xfinity",
                  "screenName" : "@Xfinity"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Online gaming"
                  },
                  {
                    "targetingType" : "Conversation topics"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Minecraft"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Roblox"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "DOOM"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Epic Games"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Nintendo"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Nintendo"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Boston MA-Manchester NH, US"
                  }
                ],
                "impressionTime" : "2022-09-14 14:28:11"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-14 14:28:13",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90565",
                  "name" : "#TheHandmaidsTale",
                  "description" : "New Season. Now Streaming on Hulu."
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Handmaid's Tale",
                  "screenName" : "@HandmaidsOnHulu"
                },
                "impressionTime" : "2022-09-14 11:10:29"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-14 11:10:31",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90565",
                  "name" : "#TheHandmaidsTale",
                  "description" : "New Season. Now Streaming on Hulu."
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Handmaid's Tale",
                  "screenName" : "@HandmaidsOnHulu"
                },
                "impressionTime" : "2022-09-14 23:25:48"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-14 23:25:49",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90565",
                  "name" : "#TheHandmaidsTale",
                  "description" : "New Season. Now Streaming on Hulu."
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Handmaid's Tale",
                  "screenName" : "@HandmaidsOnHulu"
                },
                "impressionTime" : "2022-09-14 21:57:37"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-14 21:57:38",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90565",
                  "name" : "#TheHandmaidsTale",
                  "description" : "New Season. Now Streaming on Hulu."
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Handmaid's Tale",
                  "screenName" : "@HandmaidsOnHulu"
                },
                "impressionTime" : "2022-09-14 20:26:49"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-14 20:26:50",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90565",
                  "name" : "#TheHandmaidsTale",
                  "description" : "New Season. Now Streaming on Hulu."
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Handmaid's Tale",
                  "screenName" : "@HandmaidsOnHulu"
                },
                "impressionTime" : "2022-09-14 20:31:56"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-14 20:31:57",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90565",
                  "name" : "#TheHandmaidsTale",
                  "description" : "New Season. Now Streaming on Hulu."
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Handmaid's Tale",
                  "screenName" : "@HandmaidsOnHulu"
                },
                "impressionTime" : "2022-09-14 19:57:37"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-14 19:57:39",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90565",
                  "name" : "#TheHandmaidsTale",
                  "description" : "New Season. Now Streaming on Hulu."
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Handmaid's Tale",
                  "screenName" : "@HandmaidsOnHulu"
                },
                "impressionTime" : "2022-09-14 19:58:40"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-14 19:58:41",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90565",
                  "name" : "#TheHandmaidsTale",
                  "description" : "New Season. Now Streaming on Hulu."
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Handmaid's Tale",
                  "screenName" : "@HandmaidsOnHulu"
                },
                "impressionTime" : "2022-09-14 16:45:27"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-14 16:45:28",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90565",
                  "name" : "#TheHandmaidsTale",
                  "description" : "New Season. Now Streaming on Hulu."
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Handmaid's Tale",
                  "screenName" : "@HandmaidsOnHulu"
                },
                "impressionTime" : "2022-09-14 16:35:23"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-14 16:35:24",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90565",
                  "name" : "#TheHandmaidsTale",
                  "description" : "New Season. Now Streaming on Hulu."
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Handmaid's Tale",
                  "screenName" : "@HandmaidsOnHulu"
                },
                "impressionTime" : "2022-09-14 16:43:47"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-14 16:43:47",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90565",
                  "name" : "#TheHandmaidsTale",
                  "description" : "New Season. Now Streaming on Hulu."
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Handmaid's Tale",
                  "screenName" : "@HandmaidsOnHulu"
                },
                "impressionTime" : "2022-09-15 02:40:44"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-15 02:40:44",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90565",
                  "name" : "#TheHandmaidsTale",
                  "description" : "New Season. Now Streaming on Hulu."
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Handmaid's Tale",
                  "screenName" : "@HandmaidsOnHulu"
                },
                "impressionTime" : "2022-09-15 02:47:02"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-15 02:47:03",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1568330239805202432",
                  "tweetText" : "Legacy is on the line as @Canelo is ready to take on GGG for the final time in Las Vegas. Tune in to #HennessyFightNight to catch history in the making.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Hennessy",
                  "screenName" : "@Hennessy"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Rap"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Jazz"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Ubisoft"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Nintendo"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Whiskey"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "PlayStation"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 to 49"
                  }
                ],
                "impressionTime" : "2022-09-15 02:47:40"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-15 02:47:42",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90565",
                  "name" : "#TheHandmaidsTale",
                  "description" : "New Season. Now Streaming on Hulu."
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Handmaid's Tale",
                  "screenName" : "@HandmaidsOnHulu"
                },
                "impressionTime" : "2022-09-15 03:31:39"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-15 03:31:40",
                  "engagementType" : "TrendView"
                },
                {
                  "engagementTime" : "2022-09-15 03:31:41",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90565",
                  "name" : "#TheHandmaidsTale",
                  "description" : "New Season. Now Streaming on Hulu."
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Handmaid's Tale",
                  "screenName" : "@HandmaidsOnHulu"
                },
                "impressionTime" : "2022-09-15 03:46:21"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-15 03:46:22",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90565",
                  "name" : "#TheHandmaidsTale",
                  "description" : "New Season. Now Streaming on Hulu."
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Handmaid's Tale",
                  "screenName" : "@HandmaidsOnHulu"
                },
                "impressionTime" : "2022-09-15 03:22:03"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-15 03:22:04",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90565",
                  "name" : "#TheHandmaidsTale",
                  "description" : "New Season. Now Streaming on Hulu."
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Handmaid's Tale",
                  "screenName" : "@HandmaidsOnHulu"
                },
                "impressionTime" : "2022-09-15 04:15:17"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-15 04:15:18",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90565",
                  "name" : "#TheHandmaidsTale",
                  "description" : "New Season. Now Streaming on Hulu."
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Handmaid's Tale",
                  "screenName" : "@HandmaidsOnHulu"
                },
                "impressionTime" : "2022-09-15 04:22:52"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-15 04:22:53",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90565",
                  "name" : "#TheHandmaidsTale",
                  "description" : "New Season. Now Streaming on Hulu."
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Handmaid's Tale",
                  "screenName" : "@HandmaidsOnHulu"
                },
                "impressionTime" : "2022-09-15 04:06:37"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-15 04:06:39",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90771",
                  "name" : "#iPhone14Pro",
                  "description" : "Introducing Dynamic Island"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Apple",
                  "screenName" : "@Apple"
                },
                "impressionTime" : "2022-09-16 13:57:11"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-16 13:57:13",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90771",
                  "name" : "#iPhone14Pro",
                  "description" : "Introducing Dynamic Island"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Apple",
                  "screenName" : "@Apple"
                },
                "impressionTime" : "2022-09-16 14:25:33"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-16 14:25:34",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90771",
                  "name" : "#iPhone14Pro",
                  "description" : "Introducing Dynamic Island"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Apple",
                  "screenName" : "@Apple"
                },
                "impressionTime" : "2022-09-16 20:30:52"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-16 20:30:53",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90771",
                  "name" : "#iPhone14Pro",
                  "description" : "Introducing Dynamic Island"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Apple",
                  "screenName" : "@Apple"
                },
                "impressionTime" : "2022-09-17 00:29:18"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-17 00:29:19",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90771",
                  "name" : "#iPhone14Pro",
                  "description" : "Introducing Dynamic Island"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Apple",
                  "screenName" : "@Apple"
                },
                "impressionTime" : "2022-09-17 00:27:08"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-17 00:27:09",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90771",
                  "name" : "#iPhone14Pro",
                  "description" : "Introducing Dynamic Island"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Apple",
                  "screenName" : "@Apple"
                },
                "impressionTime" : "2022-09-17 00:57:32"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-17 00:57:33",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90771",
                  "name" : "#iPhone14Pro",
                  "description" : "Introducing Dynamic Island"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Apple",
                  "screenName" : "@Apple"
                },
                "impressionTime" : "2022-09-17 02:57:32"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-17 02:57:34",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90771",
                  "name" : "#iPhone14Pro",
                  "description" : "Introducing Dynamic Island"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Apple",
                  "screenName" : "@Apple"
                },
                "impressionTime" : "2022-09-16 17:57:03"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-16 17:57:04",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90771",
                  "name" : "#iPhone14Pro",
                  "description" : "Introducing Dynamic Island"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Apple",
                  "screenName" : "@Apple"
                },
                "impressionTime" : "2022-09-16 17:31:34"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-16 17:31:35",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1569330543392866305",
                  "tweetText" : "RT @FashionWeek: #NYFW is back! See some of our favorite street style moments so far: https://t.co/j5oQha6mvd",
                  "urls" : [
                    "https://t.co/j5oQha6mvd"
                  ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Intuit Mailchimp",
                  "screenName" : "@Mailchimp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Business news"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Marketing"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  }
                ],
                "impressionTime" : "2022-09-16 17:31:36"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-16 17:31:38",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90873",
                  "name" : "#Andor",
                  "description" : "Three-episode premiere streaming Wednesday"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Star Wars | Andor & Tales of the Jedi On Disney+",
                  "screenName" : "@starwars"
                },
                "impressionTime" : "2022-09-17 12:46:09"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-17 12:46:09",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90873",
                  "name" : "#Andor",
                  "description" : "Three-episode premiere streaming Wednesday"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Star Wars | Andor & Tales of the Jedi On Disney+",
                  "screenName" : "@starwars"
                },
                "impressionTime" : "2022-09-17 07:26:08"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-17 07:26:09",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90873",
                  "name" : "#Andor",
                  "description" : "Three-episode premiere streaming Wednesday"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Star Wars | Andor & Tales of the Jedi On Disney+",
                  "screenName" : "@starwars"
                },
                "impressionTime" : "2022-09-17 07:26:06"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-17 07:26:07",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90873",
                  "name" : "#Andor",
                  "description" : "Three-episode premiere streaming Wednesday"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Star Wars | Andor & Tales of the Jedi On Disney+",
                  "screenName" : "@starwars"
                },
                "impressionTime" : "2022-09-17 07:26:43"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-17 07:26:44",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90771",
                  "name" : "#iPhone14Pro",
                  "description" : "Introducing Dynamic Island"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Apple",
                  "screenName" : "@Apple"
                },
                "impressionTime" : "2022-09-17 03:01:11"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-17 03:01:12",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90873",
                  "name" : "#Andor",
                  "description" : "Three-episode premiere streaming Wednesday"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Star Wars | Andor & Tales of the Jedi On Disney+",
                  "screenName" : "@starwars"
                },
                "impressionTime" : "2022-09-17 15:25:20"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-17 15:25:21",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90873",
                  "name" : "#Andor",
                  "description" : "Three-episode premiere streaming Wednesday"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Star Wars | Andor & Tales of the Jedi On Disney+",
                  "screenName" : "@starwars"
                },
                "impressionTime" : "2022-09-17 20:53:46"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-17 20:53:49",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90873",
                  "name" : "#Andor",
                  "description" : "Three-episode premiere streaming Wednesday"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Star Wars | Andor & Tales of the Jedi On Disney+",
                  "screenName" : "@starwars"
                },
                "impressionTime" : "2022-09-18 03:46:05"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-18 03:46:06",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90873",
                  "name" : "#Andor",
                  "description" : "Three-episode premiere streaming Wednesday"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Star Wars | Andor & Tales of the Jedi On Disney+",
                  "screenName" : "@starwars"
                },
                "impressionTime" : "2022-09-18 03:35:52"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-18 03:35:53",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1531768291580166145",
                  "tweetText" : "Break out some belVita Breakfast Biscuits in the morning, they’re baked with slow-release carbs and provide steady energy to help you #RiseAndThrive 😋",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "belVita",
                  "screenName" : "@belVita"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 to 54"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  }
                ],
                "impressionTime" : "2022-09-18 16:16:42"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-18 16:16:43",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1544394399873994756",
                  "tweetText" : "Discover Card’s cash back never expires. That\nsushi you bought, however, is another story.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Discover",
                  "screenName" : "@Discover"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Gymnastics"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Entertainment"
                  },
                  {
                    "targetingType" : "Conversation topics"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Netflix"
                  },
                  {
                    "targetingType" : "Conversation topics"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Disney"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "HBO"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "LiveRamp_Suppression_CMBDSTS_EA=1"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "New York NY, US"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Boston MA-Manchester NH, US"
                  }
                ],
                "impressionTime" : "2022-09-18 21:12:35"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-18 21:12:37",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1569369864925577219",
                  "tweetText" : "The future of crypto includes all of us. Help us drive financial inclusion at Converge22.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Circle",
                  "screenName" : "@circle"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Tech news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Technology"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Cryptocurrencies"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  }
                ],
                "impressionTime" : "2022-09-19 02:22:54"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-19 02:33:44",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90811",
                  "name" : "#DWTS",
                  "description" : "LIVE TONIGHT 8ET/5PT Disney+ "
                },
                "advertiserInfo" : {
                  "advertiserName" : "Dancing with the Stars #DWTS",
                  "screenName" : "@officialdwts"
                },
                "impressionTime" : "2022-09-19 13:32:22"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-19 13:32:23",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90811",
                  "name" : "#DWTS",
                  "description" : "LIVE TONIGHT 8ET/5PT Disney+ "
                },
                "advertiserInfo" : {
                  "advertiserName" : "Dancing with the Stars #DWTS",
                  "screenName" : "@officialdwts"
                },
                "impressionTime" : "2022-09-19 13:36:43"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-19 13:36:44",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90811",
                  "name" : "#DWTS",
                  "description" : "LIVE TONIGHT 8ET/5PT Disney+ "
                },
                "advertiserInfo" : {
                  "advertiserName" : "Dancing with the Stars #DWTS",
                  "screenName" : "@officialdwts"
                },
                "impressionTime" : "2022-09-19 13:14:39"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-19 13:14:41",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90811",
                  "name" : "#DWTS",
                  "description" : "LIVE TONIGHT 8ET/5PT Disney+ "
                },
                "advertiserInfo" : {
                  "advertiserName" : "Dancing with the Stars #DWTS",
                  "screenName" : "@officialdwts"
                },
                "impressionTime" : "2022-09-19 14:55:39"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-19 14:55:41",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90009",
                  "name" : "#MyPLMorning",
                  "description" : "Premier League on NBC/USA/🦚 "
                },
                "advertiserInfo" : {
                  "advertiserName" : "NBC Sports Soccer",
                  "screenName" : "@NBCSportsSoccer"
                },
                "impressionTime" : "2022-08-13 13:02:37"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-13 13:02:38",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90009",
                  "name" : "#MyPLMorning",
                  "description" : "Premier League on NBC/USA/🦚 "
                },
                "advertiserInfo" : {
                  "advertiserName" : "NBC Sports Soccer",
                  "screenName" : "@NBCSportsSoccer"
                },
                "impressionTime" : "2022-08-13 13:00:35"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-13 13:00:36",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90811",
                  "name" : "#DWTS",
                  "description" : "LIVE TONIGHT 8ET/5PT Disney+ "
                },
                "advertiserInfo" : {
                  "advertiserName" : "Dancing with the Stars #DWTS",
                  "screenName" : "@officialdwts"
                },
                "impressionTime" : "2022-09-19 18:27:39"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-19 18:27:39",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90811",
                  "name" : "#DWTS",
                  "description" : "LIVE TONIGHT 8ET/5PT Disney+ "
                },
                "advertiserInfo" : {
                  "advertiserName" : "Dancing with the Stars #DWTS",
                  "screenName" : "@officialdwts"
                },
                "impressionTime" : "2022-09-19 18:27:33"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-19 18:27:34",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90811",
                  "name" : "#DWTS",
                  "description" : "LIVE TONIGHT 8ET/5PT Disney+ "
                },
                "advertiserInfo" : {
                  "advertiserName" : "Dancing with the Stars #DWTS",
                  "screenName" : "@officialdwts"
                },
                "impressionTime" : "2022-09-19 17:25:16"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-19 17:25:17",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90811",
                  "name" : "#DWTS",
                  "description" : "LIVE TONIGHT 8ET/5PT Disney+ "
                },
                "advertiserInfo" : {
                  "advertiserName" : "Dancing with the Stars #DWTS",
                  "screenName" : "@officialdwts"
                },
                "impressionTime" : "2022-09-20 02:56:01"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-20 02:56:03",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90811",
                  "name" : "#DWTS",
                  "description" : "LIVE TONIGHT 8ET/5PT Disney+ "
                },
                "advertiserInfo" : {
                  "advertiserName" : "Dancing with the Stars #DWTS",
                  "screenName" : "@officialdwts"
                },
                "impressionTime" : "2022-09-20 02:52:04"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-20 02:52:05",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90811",
                  "name" : "#DWTS",
                  "description" : "LIVE TONIGHT 8ET/5PT Disney+ "
                },
                "advertiserInfo" : {
                  "advertiserName" : "Dancing with the Stars #DWTS",
                  "screenName" : "@officialdwts"
                },
                "impressionTime" : "2022-09-20 02:54:57"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-20 02:54:57",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90811",
                  "name" : "#DWTS",
                  "description" : "LIVE TONIGHT 8ET/5PT Disney+ "
                },
                "advertiserInfo" : {
                  "advertiserName" : "Dancing with the Stars #DWTS",
                  "screenName" : "@officialdwts"
                },
                "impressionTime" : "2022-09-20 02:31:23"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-20 02:31:23",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90874",
                  "name" : "#ATT5G",
                  "description" : "Buy it today"
                },
                "advertiserInfo" : {
                  "advertiserName" : "AT&T",
                  "screenName" : "@ATT"
                },
                "impressionTime" : "2022-09-20 11:03:43"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-20 11:03:45",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90874",
                  "name" : "#ATT5G",
                  "description" : "Buy it today"
                },
                "advertiserInfo" : {
                  "advertiserName" : "AT&T",
                  "screenName" : "@ATT"
                },
                "impressionTime" : "2022-09-20 14:37:08"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-20 14:37:09",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90874",
                  "name" : "#ATT5G",
                  "description" : "Buy it today"
                },
                "advertiserInfo" : {
                  "advertiserName" : "AT&T",
                  "screenName" : "@ATT"
                },
                "impressionTime" : "2022-09-20 10:58:52"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-20 10:58:53",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90874",
                  "name" : "#ATT5G",
                  "description" : "Buy it today"
                },
                "advertiserInfo" : {
                  "advertiserName" : "AT&T",
                  "screenName" : "@ATT"
                },
                "impressionTime" : "2022-09-20 13:31:47"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-20 13:31:48",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90874",
                  "name" : "#ATT5G",
                  "description" : "Buy it today"
                },
                "advertiserInfo" : {
                  "advertiserName" : "AT&T",
                  "screenName" : "@ATT"
                },
                "impressionTime" : "2022-09-20 19:36:05"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-20 19:36:06",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90874",
                  "name" : "#ATT5G",
                  "description" : "Buy it today"
                },
                "advertiserInfo" : {
                  "advertiserName" : "AT&T",
                  "screenName" : "@ATT"
                },
                "impressionTime" : "2022-09-21 01:54:29"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-21 01:54:30",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90874",
                  "name" : "#ATT5G",
                  "description" : "Buy it today"
                },
                "advertiserInfo" : {
                  "advertiserName" : "AT&T",
                  "screenName" : "@ATT"
                },
                "impressionTime" : "2022-09-21 01:54:14"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-21 01:54:14",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90874",
                  "name" : "#ATT5G",
                  "description" : "Buy it today"
                },
                "advertiserInfo" : {
                  "advertiserName" : "AT&T",
                  "screenName" : "@ATT"
                },
                "impressionTime" : "2022-09-20 18:38:30"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-20 18:38:31",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90874",
                  "name" : "#ATT5G",
                  "description" : "Buy it today"
                },
                "advertiserInfo" : {
                  "advertiserName" : "AT&T",
                  "screenName" : "@ATT"
                },
                "impressionTime" : "2022-09-20 18:56:11"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-20 18:56:12",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90874",
                  "name" : "#ATT5G",
                  "description" : "Buy it today"
                },
                "advertiserInfo" : {
                  "advertiserName" : "AT&T",
                  "screenName" : "@ATT"
                },
                "impressionTime" : "2022-09-21 03:31:18"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-21 03:31:20",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90874",
                  "name" : "#ATT5G",
                  "description" : "Buy it today"
                },
                "advertiserInfo" : {
                  "advertiserName" : "AT&T",
                  "screenName" : "@ATT"
                },
                "impressionTime" : "2022-09-21 03:37:10"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-21 03:37:12",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90874",
                  "name" : "#ATT5G",
                  "description" : "Buy it today"
                },
                "advertiserInfo" : {
                  "advertiserName" : "AT&T",
                  "screenName" : "@ATT"
                },
                "impressionTime" : "2022-09-21 03:34:59"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-21 03:35:01",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90804",
                  "name" : "#AbbottElementary",
                  "description" : "ABC Tonight and Stream on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Abbott Elementary",
                  "screenName" : "@AbbottElemABC"
                },
                "impressionTime" : "2022-09-21 23:56:32"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-21 23:56:33",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90804",
                  "name" : "#AbbottElementary",
                  "description" : "ABC Tonight and Stream on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Abbott Elementary",
                  "screenName" : "@AbbottElemABC"
                },
                "impressionTime" : "2022-09-21 23:57:14"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-21 23:57:15",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90804",
                  "name" : "#AbbottElementary",
                  "description" : "ABC Tonight and Stream on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Abbott Elementary",
                  "screenName" : "@AbbottElemABC"
                },
                "impressionTime" : "2022-09-22 02:37:13"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 02:37:14",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90804",
                  "name" : "#AbbottElementary",
                  "description" : "ABC Tonight and Stream on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Abbott Elementary",
                  "screenName" : "@AbbottElemABC"
                },
                "impressionTime" : "2022-09-22 02:46:17"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 02:46:18",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1566833890551103490",
                  "tweetText" : "Witness a legend in the making... #OntheComeUp premieres September 23 on #ParamountPlus. https://t.co/sJC45dXsgA",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/sJC45dXsgA"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Paramount+",
                  "screenName" : "@paramountplus"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Music festivals and concerts"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Rap"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 54"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  }
                ],
                "impressionTime" : "2022-09-22 02:30:03"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 02:30:04",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90804",
                  "name" : "#AbbottElementary",
                  "description" : "ABC Tonight and Stream on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Abbott Elementary",
                  "screenName" : "@AbbottElemABC"
                },
                "impressionTime" : "2022-09-22 02:51:57"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 02:51:58",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90804",
                  "name" : "#AbbottElementary",
                  "description" : "ABC Tonight and Stream on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Abbott Elementary",
                  "screenName" : "@AbbottElemABC"
                },
                "impressionTime" : "2022-09-21 18:00:06"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-21 18:00:07",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90804",
                  "name" : "#AbbottElementary",
                  "description" : "ABC Tonight and Stream on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Abbott Elementary",
                  "screenName" : "@AbbottElemABC"
                },
                "impressionTime" : "2022-09-21 18:02:55"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-21 18:02:56",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90804",
                  "name" : "#AbbottElementary",
                  "description" : "ABC Tonight and Stream on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Abbott Elementary",
                  "screenName" : "@AbbottElemABC"
                },
                "impressionTime" : "2022-09-21 19:32:11"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-21 19:32:12",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90804",
                  "name" : "#AbbottElementary",
                  "description" : "ABC Tonight and Stream on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Abbott Elementary",
                  "screenName" : "@AbbottElemABC"
                },
                "impressionTime" : "2022-09-21 19:13:06"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-21 19:13:07",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1570885316151767040",
                  "tweetText" : "Day or night, our Scalp Shield Technology is Never Not Working to protect against flakes*! ☀️➡️🌙 @PatrickMahomes *visible flakes, with regular use",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Head & Shoulders",
                  "screenName" : "@Headshoulders"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2022-09-22 03:28:33"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 03:31:02",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1548023593241522182",
                  "tweetText" : "Dedicated support for your business—ensuring you have the tools you need to succeed.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Truist",
                  "screenName" : "@TruistNews"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Small business"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "Onboarded - Truist - Do Not Contact"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "Onboarded - Sm Biz Clients - 0622"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "New York NY, US"
                  }
                ],
                "impressionTime" : "2022-09-22 03:28:33"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 03:29:23",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1567589214916853760",
                  "tweetText" : "Get marketing suggestions backed by insights from the billions of emails we send.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Intuit Mailchimp",
                  "screenName" : "@Mailchimp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "#business"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "startup"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "startups"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Business news"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Marketing"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "marketing_customer_type=Legacy Monthly"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "marketing_customer_type=Premium Monthly"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "marketing_customer_type=Standard Monthly"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "marketing_customer_type=Essential Monthly"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "21 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  }
                ],
                "impressionTime" : "2022-09-22 03:33:25"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 03:34:03",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1483815742910910470",
                  "tweetText" : "Travel makes us take great leaps. Create lasting memories at our 30 hotel brands. #TravelMakesUs",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Marriott Bonvoy",
                  "screenName" : "@MarriottBonvoy"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics"
                  },
                  {
                    "targetingType" : "Conversation topics"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Travel Actions"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Adventure travel"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "Marriott_Employee_Suppression=1"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 to 54"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  }
                ],
                "impressionTime" : "2022-09-22 03:33:25"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 03:34:27",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1572118366491447297",
                  "tweetText" : "time to get spooked. #31nightsofhalloween starts october 1st 💚 this tweet for a reminder.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Freeform's 31 Nights of Halloween",
                  "screenName" : "@31Nights"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "The Nightmare Before Christmas"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 49"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  }
                ],
                "impressionTime" : "2022-09-22 03:28:33"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 03:30:43",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1566833890551103490",
                  "tweetText" : "Witness a legend in the making... #OntheComeUp premieres September 23 on #ParamountPlus. https://t.co/sJC45dXsgA",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/sJC45dXsgA"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Paramount+",
                  "screenName" : "@paramountplus"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "Blindspotting"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 54"
                  }
                ],
                "impressionTime" : "2022-09-22 03:24:16"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 03:24:32",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1542845150514364416",
                  "tweetText" : "Take care of yourself like a New York Yankee would. Book an  appointment today at the Official Hospital of the New York Yankees. STAY AMAZING.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "NewYork-Presbyterian",
                  "screenName" : "@nyphospital"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "MLB"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "New York NY, US"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  }
                ],
                "impressionTime" : "2022-09-22 03:28:33"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 03:30:38",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1562482583744937986",
                  "tweetText" : "#dowhatdriverscant",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "MBTA Commuter Rail",
                  "screenName" : "@MBTA_CR"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Music festivals and concerts"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Technology"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 34"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "01742"
                  }
                ],
                "impressionTime" : "2022-09-22 03:28:33"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 03:28:54",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1570156478509584384",
                  "tweetText" : "Amazon offers prepaid college tuition, GEDs, and ESL certifications to 750,000+ hourly employees.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Amazon News",
                  "screenName" : "@amazonnews"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Political News"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Business news"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "The New York Times"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Technology"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "10002"
                  }
                ],
                "impressionTime" : "2022-09-22 03:24:16"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 03:24:58",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1567215641110740997",
                  "tweetText" : "You can navigate growing inflation with a plan. Hear how other small business owners tackle inflation at our webinar on September 22, 12 pm EST.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Truist",
                  "screenName" : "@TruistNews"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Small business"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "Onboarded - Truist - Do Not Contact"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "Onboarded - Sm Biz Clients - 0622"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "New York NY, US"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  }
                ],
                "impressionTime" : "2022-09-22 03:26:00"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 03:28:03",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1567769835861381121",
                  "tweetText" : "Cut your admin time with a whole range of CRM templates on Pipedrive",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Pipedrive",
                  "screenName" : "@pipedrive"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Technology"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Sign Up - SU complete"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Purchase - credit card details entered"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "paying_customers_2022_Mar_02"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "trial_customers_2022_Mar_03"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "30 second website visit"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Sign Up Started (pageload)"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Sign Up - Step 1"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Sign Up Started - Pageload"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 to 54"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "New York"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Massachusetts"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2022-09-22 03:31:13"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 03:33:07",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1559206800217473025",
                  "tweetText" : "Celebrate artists for inspiring us to think differently. #MoreByMany #HennessyVSOP",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Hennessy",
                  "screenName" : "@Hennessy"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "Game"
                  },
                  {
                    "targetingType" : "Conversation topics"
                  },
                  {
                    "targetingType" : "Conversation topics"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Nintendo"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Whiskey"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "PlayStation"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Online gaming"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Massachusetts"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "New York"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 to 49"
                  }
                ],
                "impressionTime" : "2022-09-22 03:26:00"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 03:27:56",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1536444632619442178",
                  "tweetText" : "The perfect French fry doesn’t exi-",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Ore-Ida Potatoes",
                  "screenName" : "@OreIdaPotatoes"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "Cooking"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 to 49"
                  }
                ],
                "impressionTime" : "2022-09-22 03:26:00"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 03:26:02",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1571142229431029760",
                  "tweetText" : "Trot over to your favorite retailer today and pick up a #MegaMillions ticket for your chance to wrangle a $277 million jackpot. #newyorklottery #pleaseplayresponsibly https://t.co/HEPCe0edj4",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/HEPCe0edj4"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "New York Lottery",
                  "screenName" : "@newyorklottery"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Online gaming"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "New York"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "21 and up"
                  }
                ],
                "impressionTime" : "2022-09-22 03:26:00"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 03:26:04",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1572603432162459649",
                  "tweetText" : "RT @GMA: Man turns love of skiing into new company; @GoDaddy spotlights Creighton Elinski of Hinterland Skis, who was able to expand his bu…",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "GoDaddy",
                  "screenName" : "@GoDaddy"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Entrepreneurship"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 49"
                  }
                ],
                "impressionTime" : "2022-09-22 03:33:25"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 03:33:58",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1571142229431029760",
                  "tweetText" : "Trot over to your favorite retailer today and pick up a #MegaMillions ticket for your chance to wrangle a $277 million jackpot. #newyorklottery #pleaseplayresponsibly https://t.co/HEPCe0edj4",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/HEPCe0edj4"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "New York Lottery",
                  "screenName" : "@newyorklottery"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Online gaming"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "21 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "New York"
                  }
                ],
                "impressionTime" : "2022-09-22 03:31:13"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 03:32:18",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1565716974965063680",
                  "tweetText" : "Pediatric care available 7 days a week, virtually.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "NewYork-Presbyterian",
                  "screenName" : "@nyphospital"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "New York NY, US"
                  }
                ],
                "impressionTime" : "2022-09-22 03:31:13"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 03:33:17",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1558158593425539072",
                  "tweetText" : "$10 Weekends = Unlimited rides Sat + Sun.\n\nNo traffic on the way.\n\nNo parking when you get there.\n\nNo limit on the number of trips.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "MBTA Commuter Rail",
                  "screenName" : "@MBTA_CR"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "business"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "work"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "01742"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 34"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  }
                ],
                "impressionTime" : "2022-09-22 03:26:00"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 03:26:06",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1536444632619442178",
                  "tweetText" : "The perfect French fry doesn’t exi-",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Ore-Ida Potatoes",
                  "screenName" : "@OreIdaPotatoes"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "Cooking"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 to 49"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  }
                ],
                "impressionTime" : "2022-09-22 03:24:16"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 03:24:20",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1556898070930923521",
                  "tweetText" : "No matter the moment, you should always look to level up your hydration with bold flavor from MiO #MioLevelUp",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "MiO Water Enhancer",
                  "screenName" : "@DrinkMiO"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Gaming news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Online gaming"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "Adventure"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "Water"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "Beverages"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "Beverage"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "Fantasy"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 49"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  }
                ],
                "impressionTime" : "2022-09-22 03:31:13"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 03:33:00",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1560006552206974979",
                  "tweetText" : "Add Coca-Cola to your roster to make the perfect play on game day. #CocaCola #RealMagic",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Coca-Cola",
                  "screenName" : "@CocaCola"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "Cooking"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "Food"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Hershey's"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Doritos"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "NFL"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 to 49"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  }
                ],
                "impressionTime" : "2022-09-22 03:33:25"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 03:34:11",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1567135553866571777",
                  "tweetText" : "Catching fireflies is an end of summer tradition. Create a new one this summer, and catch our latest ticket drop featuring Triple Red 777, Cash To Go!, and $5,000 Cash!. What’s your favorite end-of-summer tradition? #newyorklottery #pleaseplayresponsibly https://t.co/6JYE4niVwo",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/6JYE4niVwo"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "New York Lottery",
                  "screenName" : "@newyorklottery"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Online gaming"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "21 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "New York"
                  }
                ],
                "impressionTime" : "2022-09-22 03:28:33"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 03:28:36",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1560002408968757248",
                  "tweetText" : "With the NEW IHG One Rewards you can earn points faster every time you stay with us and #GuestHowYouGuest",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "IHG One Rewards",
                  "screenName" : "@IHGOneRewards"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Travel Actions"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Adventure travel"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "#Today"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "Today"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "US_IHG_All_Members=1"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 to 49"
                  }
                ],
                "impressionTime" : "2022-09-22 03:28:33"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 03:31:11",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1570156478509584384",
                  "tweetText" : "Amazon offers prepaid college tuition, GEDs, and ESL certifications to 750,000+ hourly employees.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Amazon News",
                  "screenName" : "@amazonnews"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Political News"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Business news"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "The New York Times"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Technology"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "01742"
                  }
                ],
                "impressionTime" : "2022-09-22 03:31:13"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 03:32:02",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1549876184741122048",
                  "tweetText" : "$10 Weekends = Unlimited rides Sat + Sun.\n\nNo traffic on the way.\n\nNo parking when you get there.\n\nNo limit on the number of trips.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "MBTA Commuter Rail",
                  "screenName" : "@MBTA_CR"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "business"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "01742"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 34"
                  }
                ],
                "impressionTime" : "2022-09-22 03:31:13"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 03:32:55",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1560001268462112770",
                  "tweetText" : "Can you build a table? The buildabilities are endless when you #LunchabuildThis. Now share what you can Lunchabuild! Find more inspiration on the link below!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Real Lunchables",
                  "screenName" : "@RealLunchables"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Family & relationships"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Netflix"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Family and life stages"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Disney"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 to 49"
                  }
                ],
                "impressionTime" : "2022-09-22 03:24:16"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 03:25:16",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91033",
                  "name" : "#Avatar",
                  "description" : "Returns to theaters tomorrow"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Avatar",
                  "screenName" : "@officialavatar"
                },
                "impressionTime" : "2022-09-22 16:17:46"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 16:17:47",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91033",
                  "name" : "#Avatar",
                  "description" : "Returns to theaters tomorrow"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Avatar",
                  "screenName" : "@officialavatar"
                },
                "impressionTime" : "2022-09-22 16:29:08"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 16:29:08",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91033",
                  "name" : "#Avatar",
                  "description" : "Returns to theaters tomorrow"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Avatar",
                  "screenName" : "@officialavatar"
                },
                "impressionTime" : "2022-09-22 20:57:14"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 20:57:15",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1521852161050746883",
                  "tweetText" : "We welcome you to give us a Like to receive your very own #RITZRecipe!  When you ( ❤️ ) this tweet we’ll take a little peek at your profile to serve up the best recipe for you. https://t.co/LTDvp8C95d",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/LTDvp8C95d"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "RITZ Crackers",
                  "screenName" : "@Ritzcrackers"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 49"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  }
                ],
                "impressionTime" : "2022-09-22 18:41:39"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 18:41:40",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91033",
                  "name" : "#Avatar",
                  "description" : "Returns to theaters tomorrow"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Avatar",
                  "screenName" : "@officialavatar"
                },
                "impressionTime" : "2022-09-22 18:22:55"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 18:22:56",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91033",
                  "name" : "#Avatar",
                  "description" : "Returns to theaters tomorrow"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Avatar",
                  "screenName" : "@officialavatar"
                },
                "impressionTime" : "2022-09-22 15:51:15"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 15:51:16",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91033",
                  "name" : "#Avatar",
                  "description" : "Returns to theaters tomorrow"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Avatar",
                  "screenName" : "@officialavatar"
                },
                "impressionTime" : "2022-09-22 19:48:05"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-22 19:48:05",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90934",
                  "name" : "#TheKardashians",
                  "description" : "Now Streaming on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Kardashians",
                  "screenName" : "@kardashianshulu"
                },
                "impressionTime" : "2022-09-23 20:48:53"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-23 20:48:54",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90934",
                  "name" : "#TheKardashians",
                  "description" : "Now Streaming on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Kardashians",
                  "screenName" : "@kardashianshulu"
                },
                "impressionTime" : "2022-09-23 19:02:38"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-23 19:02:39",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90933",
                  "name" : "#SuperNaturalSeries",
                  "description" : "Now Streaming on Disney+"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-09-24 14:44:41"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-24 14:44:43",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90933",
                  "name" : "#SuperNaturalSeries",
                  "description" : "Now Streaming on Disney+"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-09-24 16:45:23"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-24 16:45:24",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90933",
                  "name" : "#SuperNaturalSeries",
                  "description" : "Now Streaming on Disney+"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-09-24 16:57:01"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-24 16:57:02",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90933",
                  "name" : "#SuperNaturalSeries",
                  "description" : "Now Streaming on Disney+"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-09-24 15:19:16"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-24 15:19:16",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90933",
                  "name" : "#SuperNaturalSeries",
                  "description" : "Now Streaming on Disney+"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-09-24 19:15:45"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-24 19:15:46",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90933",
                  "name" : "#SuperNaturalSeries",
                  "description" : "Now Streaming on Disney+"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-09-24 19:15:50"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-24 19:15:51",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90009",
                  "name" : "#MyPLMorning",
                  "description" : "Premier League on NBC/USA/🦚 "
                },
                "advertiserInfo" : {
                  "advertiserName" : "NBC Sports Soccer",
                  "screenName" : "@NBCSportsSoccer"
                },
                "impressionTime" : "2022-08-14 01:45:14"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-14 01:45:15",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90009",
                  "name" : "#MyPLMorning",
                  "description" : "Premier League on NBC/USA/🦚 "
                },
                "advertiserInfo" : {
                  "advertiserName" : "NBC Sports Soccer",
                  "screenName" : "@NBCSportsSoccer"
                },
                "impressionTime" : "2022-08-14 02:08:33"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-14 02:08:34",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90009",
                  "name" : "#MyPLMorning",
                  "description" : "Premier League on NBC/USA/🦚 "
                },
                "advertiserInfo" : {
                  "advertiserName" : "NBC Sports Soccer",
                  "screenName" : "@NBCSportsSoccer"
                },
                "impressionTime" : "2022-08-14 02:08:52"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-14 02:08:52",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91112",
                  "name" : "#AmsterdamMovie",
                  "description" : "Get Tickets Now. In Theaters 10.7"
                },
                "advertiserInfo" : {
                  "advertiserName" : "20th Century Studios",
                  "screenName" : "@20thcentury"
                },
                "impressionTime" : "2022-09-25 19:37:36"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-25 19:37:37",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91112",
                  "name" : "#AmsterdamMovie",
                  "description" : "Get Tickets Now. In Theaters 10.7"
                },
                "advertiserInfo" : {
                  "advertiserName" : "20th Century Studios",
                  "screenName" : "@20thcentury"
                },
                "impressionTime" : "2022-09-25 21:04:37"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-25 21:04:38",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91112",
                  "name" : "#AmsterdamMovie",
                  "description" : "Get Tickets Now. In Theaters 10.7"
                },
                "advertiserInfo" : {
                  "advertiserName" : "20th Century Studios",
                  "screenName" : "@20thcentury"
                },
                "impressionTime" : "2022-09-25 18:42:11"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-25 18:42:12",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91112",
                  "name" : "#AmsterdamMovie",
                  "description" : "Get Tickets Now. In Theaters 10.7"
                },
                "advertiserInfo" : {
                  "advertiserName" : "20th Century Studios",
                  "screenName" : "@20thcentury"
                },
                "impressionTime" : "2022-09-26 01:08:06"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-26 01:08:06",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91110",
                  "name" : "#GetReadyWithMusic",
                  "description" : "What songs match your style?"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Spotify",
                  "screenName" : "@Spotify"
                },
                "impressionTime" : "2022-09-26 13:53:44"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-26 13:53:45",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91110",
                  "name" : "#GetReadyWithMusic",
                  "description" : "What songs match your style?"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Spotify",
                  "screenName" : "@Spotify"
                },
                "impressionTime" : "2022-09-26 14:25:54"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-26 14:25:55",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91110",
                  "name" : "#GetReadyWithMusic",
                  "description" : "What songs match your style?"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Spotify",
                  "screenName" : "@Spotify"
                },
                "impressionTime" : "2022-09-26 14:22:02"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-26 14:22:03",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91110",
                  "name" : "#GetReadyWithMusic",
                  "description" : "What songs match your style?"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Spotify",
                  "screenName" : "@Spotify"
                },
                "impressionTime" : "2022-09-26 21:26:32"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-26 21:26:32",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91110",
                  "name" : "#GetReadyWithMusic",
                  "description" : "What songs match your style?"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Spotify",
                  "screenName" : "@Spotify"
                },
                "impressionTime" : "2022-09-26 21:01:52"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-26 21:01:53",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91110",
                  "name" : "#GetReadyWithMusic",
                  "description" : "What songs match your style?"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Spotify",
                  "screenName" : "@Spotify"
                },
                "impressionTime" : "2022-09-27 02:05:48"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-27 02:05:50",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91079",
                  "name" : "#TheRookieFeds",
                  "description" : "ABC Tonight and Stream on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Rookie: Feds",
                  "screenName" : "@TheRookieFeds"
                },
                "impressionTime" : "2022-09-27 18:29:20"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-27 18:29:20",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91079",
                  "name" : "#TheRookieFeds",
                  "description" : "ABC Tonight and Stream on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Rookie: Feds",
                  "screenName" : "@TheRookieFeds"
                },
                "impressionTime" : "2022-09-27 18:17:41"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-27 18:17:42",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91079",
                  "name" : "#TheRookieFeds",
                  "description" : "ABC Tonight and Stream on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Rookie: Feds",
                  "screenName" : "@TheRookieFeds"
                },
                "impressionTime" : "2022-09-27 16:18:26"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-27 16:18:27",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91079",
                  "name" : "#TheRookieFeds",
                  "description" : "ABC Tonight and Stream on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Rookie: Feds",
                  "screenName" : "@TheRookieFeds"
                },
                "impressionTime" : "2022-09-28 01:25:18"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-28 01:25:20",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91079",
                  "name" : "#TheRookieFeds",
                  "description" : "ABC Tonight and Stream on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Rookie: Feds",
                  "screenName" : "@TheRookieFeds"
                },
                "impressionTime" : "2022-09-28 01:26:58"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-28 01:26:59",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91079",
                  "name" : "#TheRookieFeds",
                  "description" : "ABC Tonight and Stream on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Rookie: Feds",
                  "screenName" : "@TheRookieFeds"
                },
                "impressionTime" : "2022-09-27 21:20:38"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-27 21:20:39",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91079",
                  "name" : "#TheRookieFeds",
                  "description" : "ABC Tonight and Stream on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Rookie: Feds",
                  "screenName" : "@TheRookieFeds"
                },
                "impressionTime" : "2022-09-27 21:09:58"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-27 21:09:58",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91079",
                  "name" : "#TheRookieFeds",
                  "description" : "ABC Tonight and Stream on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Rookie: Feds",
                  "screenName" : "@TheRookieFeds"
                },
                "impressionTime" : "2022-09-28 00:32:39"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-28 00:32:40",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91079",
                  "name" : "#TheRookieFeds",
                  "description" : "ABC Tonight and Stream on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Rookie: Feds",
                  "screenName" : "@TheRookieFeds"
                },
                "impressionTime" : "2022-09-28 00:16:36"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-28 00:16:37",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91146",
                  "name" : "#ReasonableDoubtHulu",
                  "description" : "Now Streaming on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Reasonable Doubt on Hulu",
                  "screenName" : "@ReasonableHulu"
                },
                "impressionTime" : "2022-09-28 13:26:21"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-28 13:26:22",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91146",
                  "name" : "#ReasonableDoubtHulu",
                  "description" : "Now Streaming on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Reasonable Doubt on Hulu",
                  "screenName" : "@ReasonableHulu"
                },
                "impressionTime" : "2022-09-28 14:15:50"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-28 14:15:51",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91146",
                  "name" : "#ReasonableDoubtHulu",
                  "description" : "Now Streaming on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Reasonable Doubt on Hulu",
                  "screenName" : "@ReasonableHulu"
                },
                "impressionTime" : "2022-09-28 14:58:04"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-28 14:58:04",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91146",
                  "name" : "#ReasonableDoubtHulu",
                  "description" : "Now Streaming on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Reasonable Doubt on Hulu",
                  "screenName" : "@ReasonableHulu"
                },
                "impressionTime" : "2022-09-28 14:34:35"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-28 14:34:36",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91146",
                  "name" : "#ReasonableDoubtHulu",
                  "description" : "Now Streaming on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Reasonable Doubt on Hulu",
                  "screenName" : "@ReasonableHulu"
                },
                "impressionTime" : "2022-09-29 00:06:45"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-29 00:06:47",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91146",
                  "name" : "#ReasonableDoubtHulu",
                  "description" : "Now Streaming on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Reasonable Doubt on Hulu",
                  "screenName" : "@ReasonableHulu"
                },
                "impressionTime" : "2022-09-28 21:13:25"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-28 21:13:26",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91146",
                  "name" : "#ReasonableDoubtHulu",
                  "description" : "Now Streaming on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Reasonable Doubt on Hulu",
                  "screenName" : "@ReasonableHulu"
                },
                "impressionTime" : "2022-09-28 21:00:56"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-28 21:00:57",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91146",
                  "name" : "#ReasonableDoubtHulu",
                  "description" : "Now Streaming on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Reasonable Doubt on Hulu",
                  "screenName" : "@ReasonableHulu"
                },
                "impressionTime" : "2022-09-28 21:27:56"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-28 21:27:56",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91146",
                  "name" : "#ReasonableDoubtHulu",
                  "description" : "Now Streaming on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Reasonable Doubt on Hulu",
                  "screenName" : "@ReasonableHulu"
                },
                "impressionTime" : "2022-09-28 19:56:45"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-28 19:56:45",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91146",
                  "name" : "#ReasonableDoubtHulu",
                  "description" : "Now Streaming on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Reasonable Doubt on Hulu",
                  "screenName" : "@ReasonableHulu"
                },
                "impressionTime" : "2022-09-28 16:58:18"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-28 16:58:19",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91146",
                  "name" : "#ReasonableDoubtHulu",
                  "description" : "Now Streaming on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Reasonable Doubt on Hulu",
                  "screenName" : "@ReasonableHulu"
                },
                "impressionTime" : "2022-09-28 16:47:58"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-28 16:47:58",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91146",
                  "name" : "#ReasonableDoubtHulu",
                  "description" : "Now Streaming on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Reasonable Doubt on Hulu",
                  "screenName" : "@ReasonableHulu"
                },
                "impressionTime" : "2022-09-28 16:48:48"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-28 16:48:49",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91146",
                  "name" : "#ReasonableDoubtHulu",
                  "description" : "Now Streaming on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Reasonable Doubt on Hulu",
                  "screenName" : "@ReasonableHulu"
                },
                "impressionTime" : "2022-09-29 02:44:10"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-29 02:44:11",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91146",
                  "name" : "#ReasonableDoubtHulu",
                  "description" : "Now Streaming on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Reasonable Doubt on Hulu",
                  "screenName" : "@ReasonableHulu"
                },
                "impressionTime" : "2022-09-28 22:17:14"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-28 22:17:15",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89865",
                  "name" : "#SmileMovie",
                  "description" : "Get Tickets Now"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Smile Movie",
                  "screenName" : "@SmileMovie"
                },
                "impressionTime" : "2022-09-29 11:47:54"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-29 11:47:56",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89865",
                  "name" : "#SmileMovie",
                  "description" : "Get Tickets Now"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Smile Movie",
                  "screenName" : "@SmileMovie"
                },
                "impressionTime" : "2022-09-29 17:39:30"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-29 17:39:31",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89865",
                  "name" : "#SmileMovie",
                  "description" : "Get Tickets Now"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Smile Movie",
                  "screenName" : "@SmileMovie"
                },
                "impressionTime" : "2022-09-29 17:13:30"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-29 17:13:31",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89865",
                  "name" : "#SmileMovie",
                  "description" : "Get Tickets Now"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Smile Movie",
                  "screenName" : "@SmileMovie"
                },
                "impressionTime" : "2022-09-29 17:32:53"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-29 17:32:54",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89865",
                  "name" : "#SmileMovie",
                  "description" : "Get Tickets Now"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Smile Movie",
                  "screenName" : "@SmileMovie"
                },
                "impressionTime" : "2022-09-29 17:53:34"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-29 17:53:36",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89865",
                  "name" : "#SmileMovie",
                  "description" : "Get Tickets Now"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Smile Movie",
                  "screenName" : "@SmileMovie"
                },
                "impressionTime" : "2022-09-29 17:18:49"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-29 17:18:49",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89865",
                  "name" : "#SmileMovie",
                  "description" : "Get Tickets Now"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Smile Movie",
                  "screenName" : "@SmileMovie"
                },
                "impressionTime" : "2022-09-29 19:09:24"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-29 19:09:25",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91175",
                  "name" : "#BrosMovie",
                  "description" : "Only in Theaters Now!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Bros",
                  "screenName" : "@brosthemovie"
                },
                "impressionTime" : "2022-10-01 04:27:28"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-01 04:27:30",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91257",
                  "name" : "#HocusPocus2",
                  "description" : "Original movie now streaming"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-10-01 14:13:22"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-01 14:13:23",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91257",
                  "name" : "#HocusPocus2",
                  "description" : "Original movie now streaming"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-10-01 21:44:29"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-01 21:44:30",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91257",
                  "name" : "#HocusPocus2",
                  "description" : "Original movie now streaming"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-10-01 21:09:33"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-01 21:09:34",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90016",
                  "name" : "#DONUTSHOPxSNICKERS",
                  "description" : "The Original Donut Shop Coffee® and SNICKERS™ collide"
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Original Donut Shop Coffee",
                  "screenName" : "@OrigDonutShop"
                },
                "impressionTime" : "2022-08-16 19:14:32"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-16 19:14:32",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90016",
                  "name" : "#DONUTSHOPxSNICKERS",
                  "description" : "The Original Donut Shop Coffee® and SNICKERS™ collide"
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Original Donut Shop Coffee",
                  "screenName" : "@OrigDonutShop"
                },
                "impressionTime" : "2022-08-16 23:10:53"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-16 23:10:54",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90016",
                  "name" : "#DONUTSHOPxSNICKERS",
                  "description" : "The Original Donut Shop Coffee® and SNICKERS™ collide"
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Original Donut Shop Coffee",
                  "screenName" : "@OrigDonutShop"
                },
                "impressionTime" : "2022-08-16 23:15:20"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-16 23:15:21",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91216",
                  "name" : "#IWTV",
                  "description" : "Your new vampire obsession"
                },
                "advertiserInfo" : {
                  "advertiserName" : "AMC+",
                  "screenName" : "@AMCPlus"
                },
                "impressionTime" : "2022-10-02 14:22:32"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-02 14:22:34",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91216",
                  "name" : "#IWTV",
                  "description" : "Your new vampire obsession"
                },
                "advertiserInfo" : {
                  "advertiserName" : "AMC+",
                  "screenName" : "@AMCPlus"
                },
                "impressionTime" : "2022-10-02 23:53:15"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-02 23:53:16",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91216",
                  "name" : "#IWTV",
                  "description" : "Your new vampire obsession"
                },
                "advertiserInfo" : {
                  "advertiserName" : "AMC+",
                  "screenName" : "@AMCPlus"
                },
                "impressionTime" : "2022-10-02 23:07:44"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-02 23:07:46",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91216",
                  "name" : "#IWTV",
                  "description" : "Your new vampire obsession"
                },
                "advertiserInfo" : {
                  "advertiserName" : "AMC+",
                  "screenName" : "@AMCPlus"
                },
                "impressionTime" : "2022-10-02 17:27:54"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-02 17:27:55",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91216",
                  "name" : "#IWTV",
                  "description" : "Your new vampire obsession"
                },
                "advertiserInfo" : {
                  "advertiserName" : "AMC+",
                  "screenName" : "@AMCPlus"
                },
                "impressionTime" : "2022-10-03 04:08:58"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-03 04:09:00",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91216",
                  "name" : "#IWTV",
                  "description" : "Your new vampire obsession"
                },
                "advertiserInfo" : {
                  "advertiserName" : "AMC+",
                  "screenName" : "@AMCPlus"
                },
                "impressionTime" : "2022-10-03 03:12:51"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-03 03:12:53",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91312",
                  "name" : "#AmsterdamMovie",
                  "description" : "This Friday, Who Can You Trust? Get Tickets."
                },
                "advertiserInfo" : {
                  "advertiserName" : "20th Century Studios",
                  "screenName" : "@20thcentury"
                },
                "impressionTime" : "2022-10-04 14:34:59"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-04 14:34:59",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91312",
                  "name" : "#AmsterdamMovie",
                  "description" : "This Friday, Who Can You Trust? Get Tickets."
                },
                "advertiserInfo" : {
                  "advertiserName" : "20th Century Studios",
                  "screenName" : "@20thcentury"
                },
                "impressionTime" : "2022-10-04 17:43:59"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-04 17:44:00",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91312",
                  "name" : "#AmsterdamMovie",
                  "description" : "This Friday, Who Can You Trust? Get Tickets."
                },
                "advertiserInfo" : {
                  "advertiserName" : "20th Century Studios",
                  "screenName" : "@20thcentury"
                },
                "impressionTime" : "2022-10-04 16:31:46"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-04 16:31:48",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91312",
                  "name" : "#AmsterdamMovie",
                  "description" : "This Friday, Who Can You Trust? Get Tickets."
                },
                "advertiserInfo" : {
                  "advertiserName" : "20th Century Studios",
                  "screenName" : "@20thcentury"
                },
                "impressionTime" : "2022-10-04 16:31:47"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-04 16:31:48",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91312",
                  "name" : "#AmsterdamMovie",
                  "description" : "This Friday, Who Can You Trust? Get Tickets."
                },
                "advertiserInfo" : {
                  "advertiserName" : "20th Century Studios",
                  "screenName" : "@20thcentury"
                },
                "impressionTime" : "2022-10-04 15:46:21"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-04 15:46:23",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91312",
                  "name" : "#AmsterdamMovie",
                  "description" : "This Friday, Who Can You Trust? Get Tickets."
                },
                "advertiserInfo" : {
                  "advertiserName" : "20th Century Studios",
                  "screenName" : "@20thcentury"
                },
                "impressionTime" : "2022-10-05 00:51:55"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-05 00:51:56",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91312",
                  "name" : "#AmsterdamMovie",
                  "description" : "This Friday, Who Can You Trust? Get Tickets."
                },
                "advertiserInfo" : {
                  "advertiserName" : "20th Century Studios",
                  "screenName" : "@20thcentury"
                },
                "impressionTime" : "2022-10-05 01:11:27"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-05 01:11:28",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91312",
                  "name" : "#AmsterdamMovie",
                  "description" : "This Friday, Who Can You Trust? Get Tickets."
                },
                "advertiserInfo" : {
                  "advertiserName" : "20th Century Studios",
                  "screenName" : "@20thcentury"
                },
                "impressionTime" : "2022-10-05 01:08:14"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-05 01:08:15",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91314",
                  "name" : "#AlaskaDaily",
                  "description" : "ABC TONIGHT and Stream on Hulu "
                },
                "advertiserInfo" : {
                  "advertiserName" : "Alaska Daily",
                  "screenName" : "@AlaskaDailyABC"
                },
                "impressionTime" : "2022-10-06 21:49:47"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-06 21:49:48",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91314",
                  "name" : "#AlaskaDaily",
                  "description" : "ABC TONIGHT and Stream on Hulu "
                },
                "advertiserInfo" : {
                  "advertiserName" : "Alaska Daily",
                  "screenName" : "@AlaskaDailyABC"
                },
                "impressionTime" : "2022-10-06 16:10:19"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-06 16:10:20",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91314",
                  "name" : "#AlaskaDaily",
                  "description" : "ABC TONIGHT and Stream on Hulu "
                },
                "advertiserInfo" : {
                  "advertiserName" : "Alaska Daily",
                  "screenName" : "@AlaskaDailyABC"
                },
                "impressionTime" : "2022-10-06 16:13:39"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-06 16:13:40",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91314",
                  "name" : "#AlaskaDaily",
                  "description" : "ABC TONIGHT and Stream on Hulu "
                },
                "advertiserInfo" : {
                  "advertiserName" : "Alaska Daily",
                  "screenName" : "@AlaskaDailyABC"
                },
                "impressionTime" : "2022-10-06 16:13:42"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-06 16:13:42",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91314",
                  "name" : "#AlaskaDaily",
                  "description" : "ABC TONIGHT and Stream on Hulu "
                },
                "advertiserInfo" : {
                  "advertiserName" : "Alaska Daily",
                  "screenName" : "@AlaskaDailyABC"
                },
                "impressionTime" : "2022-10-06 15:25:06"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-06 15:25:07",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91314",
                  "name" : "#AlaskaDaily",
                  "description" : "ABC TONIGHT and Stream on Hulu "
                },
                "advertiserInfo" : {
                  "advertiserName" : "Alaska Daily",
                  "screenName" : "@AlaskaDailyABC"
                },
                "impressionTime" : "2022-10-07 01:38:11"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-07 01:38:11",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91314",
                  "name" : "#AlaskaDaily",
                  "description" : "ABC TONIGHT and Stream on Hulu "
                },
                "advertiserInfo" : {
                  "advertiserName" : "Alaska Daily",
                  "screenName" : "@AlaskaDailyABC"
                },
                "impressionTime" : "2022-10-07 00:37:33"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-07 00:37:34",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91314",
                  "name" : "#AlaskaDaily",
                  "description" : "ABC TONIGHT and Stream on Hulu "
                },
                "advertiserInfo" : {
                  "advertiserName" : "Alaska Daily",
                  "screenName" : "@AlaskaDailyABC"
                },
                "impressionTime" : "2022-10-06 22:10:32"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-06 22:10:33",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91314",
                  "name" : "#AlaskaDaily",
                  "description" : "ABC TONIGHT and Stream on Hulu "
                },
                "advertiserInfo" : {
                  "advertiserName" : "Alaska Daily",
                  "screenName" : "@AlaskaDailyABC"
                },
                "impressionTime" : "2022-10-06 18:40:53"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-06 18:40:54",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91314",
                  "name" : "#AlaskaDaily",
                  "description" : "ABC TONIGHT and Stream on Hulu "
                },
                "advertiserInfo" : {
                  "advertiserName" : "Alaska Daily",
                  "screenName" : "@AlaskaDailyABC"
                },
                "impressionTime" : "2022-10-06 19:10:59"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-06 19:11:00",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Spotlight",
                "promotedTrendInfo" : {
                  "trendId" : "91314",
                  "name" : "#AlaskaDaily",
                  "description" : "ABC TONIGHT and Stream on Hulu "
                },
                "advertiserInfo" : {
                  "advertiserName" : "Alaska Daily",
                  "screenName" : "@AlaskaDailyABC"
                },
                "impressionTime" : "2022-10-06 19:31:40"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-06 19:31:41",
                  "engagementType" : "SpotlightView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1570827683482697729",
                  "tweetText" : "Wherever there’s ground, break it, so that others can build new paths through the rubble. #KeepWalking.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Johnnie Walker",
                  "screenName" : "@JohnnieWalkerUS"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Wine"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Whiskey"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  }
                ],
                "impressionTime" : "2022-10-07 17:21:43"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-07 17:21:45",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91409",
                  "name" : "#Postseason",
                  "description" : "Where stars become legends. MLB's #Postseason is here. Enjoy the show."
                },
                "advertiserInfo" : {
                  "advertiserName" : "MLB",
                  "screenName" : "@MLB"
                },
                "impressionTime" : "2022-10-08 15:16:03"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-08 15:16:03",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91409",
                  "name" : "#Postseason",
                  "description" : "Where stars become legends. MLB's #Postseason is here. Enjoy the show."
                },
                "advertiserInfo" : {
                  "advertiserName" : "MLB",
                  "screenName" : "@MLB"
                },
                "impressionTime" : "2022-10-08 18:59:24"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-08 18:59:25",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91409",
                  "name" : "#Postseason",
                  "description" : "Where stars become legends. MLB's #Postseason is here. Enjoy the show."
                },
                "advertiserInfo" : {
                  "advertiserName" : "MLB",
                  "screenName" : "@MLB"
                },
                "impressionTime" : "2022-10-09 06:16:20"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-09 06:16:21",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1560712541403197441",
                  "tweetText" : "House of the Dragon is now streaming on HBO Max. Plans start at $9.99/mo.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "HBO Max",
                  "screenName" : "@hbomax"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Movies and TV shows",
                    "targetingValue" : "Game of Thrones"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Game of Thrones"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "HMX_Retail_Wholesale_Suppression (email)"
                  },
                  {
                    "targetingType" : "List"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install HBO Max: Stream TV & Movies IOS All"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "HMX_Retail_Wholesale_Suppression (Device Id)"
                  },
                  {
                    "targetingType" : "Website Activity"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install HBO Max: Stream TV & Movies ANDROID All"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "HBO Max Subscription Start (No Free Trial)"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "HBO Max Account Created"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "HBO Max - All Site Traffic"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  }
                ],
                "impressionTime" : "2022-10-10 22:23:57"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-10 22:23:59",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90115",
                  "name" : "#SheHulk",
                  "description" : "Streaming Tomorrow on Disney+"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Marvel Studios",
                  "screenName" : "@MarvelStudios"
                },
                "impressionTime" : "2022-08-18 01:18:53"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-18 01:18:53",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90115",
                  "name" : "#SheHulk",
                  "description" : "Streaming Tomorrow on Disney+"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Marvel Studios",
                  "screenName" : "@MarvelStudios"
                },
                "impressionTime" : "2022-08-17 17:29:56"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-17 17:29:57",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90115",
                  "name" : "#SheHulk",
                  "description" : "Streaming Tomorrow on Disney+"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Marvel Studios",
                  "screenName" : "@MarvelStudios"
                },
                "impressionTime" : "2022-08-17 17:28:15"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-17 17:28:16",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91465",
                  "name" : "#HalloweenEnds",
                  "description" : "In Theaters & Peacock FRIDAY"
                },
                "advertiserInfo" : {
                  "advertiserName" : "#HalloweenEnds",
                  "screenName" : "@halloweenmovie"
                },
                "impressionTime" : "2022-10-13 01:13:48"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-13 01:13:49",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91465",
                  "name" : "#HalloweenEnds",
                  "description" : "In Theaters & Peacock FRIDAY"
                },
                "advertiserInfo" : {
                  "advertiserName" : "#HalloweenEnds",
                  "screenName" : "@halloweenmovie"
                },
                "impressionTime" : "2022-10-13 01:52:39"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-13 01:52:40",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91465",
                  "name" : "#HalloweenEnds",
                  "description" : "In Theaters & Peacock FRIDAY"
                },
                "advertiserInfo" : {
                  "advertiserName" : "#HalloweenEnds",
                  "screenName" : "@halloweenmovie"
                },
                "impressionTime" : "2022-10-12 21:34:46"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-12 21:34:46",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91465",
                  "name" : "#HalloweenEnds",
                  "description" : "In Theaters & Peacock FRIDAY"
                },
                "advertiserInfo" : {
                  "advertiserName" : "#HalloweenEnds",
                  "screenName" : "@halloweenmovie"
                },
                "impressionTime" : "2022-10-13 02:54:39"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-13 02:54:39",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91465",
                  "name" : "#HalloweenEnds",
                  "description" : "In Theaters & Peacock FRIDAY"
                },
                "advertiserInfo" : {
                  "advertiserName" : "#HalloweenEnds",
                  "screenName" : "@halloweenmovie"
                },
                "impressionTime" : "2022-10-13 02:22:28"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-13 02:22:29",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91466",
                  "name" : "#M3GAN",
                  "description" : "meet M3GAN. your new bff."
                },
                "advertiserInfo" : {
                  "advertiserName" : "M3GAN",
                  "screenName" : "@meetM3GAN"
                },
                "impressionTime" : "2022-10-13 16:18:04"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-13 16:18:05",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91466",
                  "name" : "#M3GAN",
                  "description" : "meet M3GAN. your new bff."
                },
                "advertiserInfo" : {
                  "advertiserName" : "M3GAN",
                  "screenName" : "@meetM3GAN"
                },
                "impressionTime" : "2022-10-14 02:43:25"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-14 02:43:26",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1580287341893238784",
                  "tweetText" : "#BeUnstoppable in the #metaverse, too. Check out @theupsstore in @decentraland \"The Helping You Be Unstoppable Store” delivers information, inspiration, and insights for #smallbusiness owners. #ad https://t.co/D9VwOeM2B9",
                  "urls" : [
                    "https://t.co/D9VwOeM2B9"
                  ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Inc.",
                  "screenName" : "@Inc"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Technology"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Desktop"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  }
                ],
                "impressionTime" : "2022-10-14 02:44:02"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-14 02:44:04",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91466",
                  "name" : "#M3GAN",
                  "description" : "meet M3GAN. your new bff."
                },
                "advertiserInfo" : {
                  "advertiserName" : "M3GAN",
                  "screenName" : "@meetM3GAN"
                },
                "impressionTime" : "2022-10-14 00:26:58"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-14 00:26:59",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91466",
                  "name" : "#M3GAN",
                  "description" : "meet M3GAN. your new bff."
                },
                "advertiserInfo" : {
                  "advertiserName" : "M3GAN",
                  "screenName" : "@meetM3GAN"
                },
                "impressionTime" : "2022-10-14 00:26:45"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-14 00:26:46",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91466",
                  "name" : "#M3GAN",
                  "description" : "meet M3GAN. your new bff."
                },
                "advertiserInfo" : {
                  "advertiserName" : "M3GAN",
                  "screenName" : "@meetM3GAN"
                },
                "impressionTime" : "2022-10-13 21:17:13"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-13 21:17:14",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91078",
                  "name" : "#TheRingsOfPower",
                  "description" : "Watch the Season Finale Now"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Prime Video",
                  "screenName" : "@PrimeVideo"
                },
                "impressionTime" : "2022-10-14 14:13:01"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-14 14:13:02",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91078",
                  "name" : "#TheRingsOfPower",
                  "description" : "Watch the Season Finale Now"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Prime Video",
                  "screenName" : "@PrimeVideo"
                },
                "impressionTime" : "2022-10-15 01:15:09"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-15 01:15:10",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91078",
                  "name" : "#TheRingsOfPower",
                  "description" : "Watch the Season Finale Now"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Prime Video",
                  "screenName" : "@PrimeVideo"
                },
                "impressionTime" : "2022-10-15 01:15:23"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-15 01:15:24",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1576959508601004035",
                  "tweetText" : "Tomorrow’s a new day, Carl. Start it off right with a balanced meal. belVita Breakfast Biscuits are baked with slow-release carbs and provide steady morning energy to help you #RiseAndThrive 😉",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "belVita",
                  "screenName" : "@belVita"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 to 54"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  }
                ],
                "impressionTime" : "2022-10-16 07:54:06"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-16 07:54:07",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1579554037199929347",
                  "tweetText" : "Thin, crispy, VERY cheesy. Now back off and get a bag for yourself this one’s ours. Cheez-It #Snapd",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "CHEEZ-IT",
                  "screenName" : "@cheezit"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "The Blacklist"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 49"
                  }
                ],
                "impressionTime" : "2022-10-16 07:54:10"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-16 07:54:11",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1558158593425539072",
                  "tweetText" : "$10 Weekends = Unlimited rides Sat + Sun.\n\nNo traffic on the way.\n\nNo parking when you get there.\n\nNo limit on the number of trips.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "MBTA Commuter Rail",
                  "screenName" : "@MBTA_CR"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Music festivals and concerts"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Technology"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "01742"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 34"
                  }
                ],
                "impressionTime" : "2022-10-19 13:47:59"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-19 13:48:02",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91489",
                  "name" : "#BlackAdam",
                  "description" : "Get Tickets Now!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Black Adam Movie",
                  "screenName" : "@blackadammovie"
                },
                "impressionTime" : "2022-10-22 00:37:05"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-22 00:37:06",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91674",
                  "name" : "#KendrickLivestream",
                  "description" : "Watch on Amazon"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Amazon Music",
                  "screenName" : "@amazonmusic"
                },
                "impressionTime" : "2022-10-22 23:05:11"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-22 23:05:12",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91645",
                  "name" : "#SouthwestHeart",
                  "description" : "Go with Heart."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Southwest Airlines",
                  "screenName" : "@SouthwestAir"
                },
                "impressionTime" : "2022-10-23 22:57:28"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-23 22:57:29",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91567",
                  "name" : "#GMCSierraEV",
                  "description" : "See why it is the Denali of EVs."
                },
                "advertiserInfo" : {
                  "advertiserName" : "GMC",
                  "screenName" : "@GMC"
                },
                "impressionTime" : "2022-10-25 02:12:50"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-25 02:12:51",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91567",
                  "name" : "#GMCSierraEV",
                  "description" : "See why it is the Denali of EVs."
                },
                "advertiserInfo" : {
                  "advertiserName" : "GMC",
                  "screenName" : "@GMC"
                },
                "impressionTime" : "2022-10-24 18:38:04"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-24 18:38:05",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91567",
                  "name" : "#GMCSierraEV",
                  "description" : "See why it is the Denali of EVs."
                },
                "advertiserInfo" : {
                  "advertiserName" : "GMC",
                  "screenName" : "@GMC"
                },
                "impressionTime" : "2022-10-24 17:29:04"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-24 17:29:05",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91567",
                  "name" : "#GMCSierraEV",
                  "description" : "See why it is the Denali of EVs."
                },
                "advertiserInfo" : {
                  "advertiserName" : "GMC",
                  "screenName" : "@GMC"
                },
                "impressionTime" : "2022-10-24 17:29:05"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-24 17:29:07",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91567",
                  "name" : "#GMCSierraEV",
                  "description" : "See why it is the Denali of EVs."
                },
                "advertiserInfo" : {
                  "advertiserName" : "GMC",
                  "screenName" : "@GMC"
                },
                "impressionTime" : "2022-10-24 17:29:07"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-24 17:29:08",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91567",
                  "name" : "#GMCSierraEV",
                  "description" : "See why it is the Denali of EVs."
                },
                "advertiserInfo" : {
                  "advertiserName" : "GMC",
                  "screenName" : "@GMC"
                },
                "impressionTime" : "2022-10-25 00:44:17"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-25 00:44:18",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1552712980021796870",
                  "tweetText" : "A delicious combination for the whole family. M&amp;M'S Ice Cream Cookie Sandwiches.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "M&M'S",
                  "screenName" : "@mmschocolate"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "13 to 49"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  }
                ],
                "impressionTime" : "2022-08-18 16:53:51"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-18 16:53:52",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "SearchTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1579917227561816064",
                  "tweetText" : "Get the updated protection you need to do what you love.​ #WeCanDoThis",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "HHS.gov",
                  "screenName" : "@HHSGov"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 to 49"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  }
                ],
                "impressionTime" : "2022-10-25 14:47:50"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-25 14:47:51",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1576059076408066048",
                  "tweetText" : "No time for trickshots with savings on the line. Switch &amp; you could save $652 with Liberty Mutual Insurance.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Liberty Mutual",
                  "screenName" : "@LibertyMutual"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "List",
                    "targetingValue" : "All Customers - Tealium"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Colorado"
                  }
                ],
                "impressionTime" : "2022-10-26 02:24:55"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-26 02:24:56",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91792",
                  "name" : "#TÁR",
                  "description" : "In Theaters Everywhere Tomorrow"
                },
                "advertiserInfo" : {
                  "advertiserName" : "TÁR",
                  "screenName" : "@tarmovie"
                },
                "impressionTime" : "2022-10-27 14:25:57"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-27 14:25:58",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91792",
                  "name" : "#TÁR",
                  "description" : "In Theaters Everywhere Tomorrow"
                },
                "advertiserInfo" : {
                  "advertiserName" : "TÁR",
                  "screenName" : "@tarmovie"
                },
                "impressionTime" : "2022-10-27 14:27:47"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-27 14:27:48",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91792",
                  "name" : "#TÁR",
                  "description" : "In Theaters Everywhere Tomorrow"
                },
                "advertiserInfo" : {
                  "advertiserName" : "TÁR",
                  "screenName" : "@tarmovie"
                },
                "impressionTime" : "2022-10-27 19:23:30"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-27 19:23:31",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91792",
                  "name" : "#TÁR",
                  "description" : "In Theaters Everywhere Tomorrow"
                },
                "advertiserInfo" : {
                  "advertiserName" : "TÁR",
                  "screenName" : "@tarmovie"
                },
                "impressionTime" : "2022-10-28 02:04:01"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-28 02:04:01",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91792",
                  "name" : "#TÁR",
                  "description" : "In Theaters Everywhere Tomorrow"
                },
                "advertiserInfo" : {
                  "advertiserName" : "TÁR",
                  "screenName" : "@tarmovie"
                },
                "impressionTime" : "2022-10-27 16:48:43"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-27 16:48:44",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91792",
                  "name" : "#TÁR",
                  "description" : "In Theaters Everywhere Tomorrow"
                },
                "advertiserInfo" : {
                  "advertiserName" : "TÁR",
                  "screenName" : "@tarmovie"
                },
                "impressionTime" : "2022-10-27 18:19:24"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-27 18:19:25",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91769",
                  "name" : "#ModernWarfare2",
                  "description" : "Call of Duty: Modern Warfare II is available now!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Call of Duty",
                  "screenName" : "@CallofDuty"
                },
                "impressionTime" : "2022-10-28 15:34:44"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-28 15:34:45",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1580590183334006785",
                  "tweetText" : "Sometimes, less is more. GitLab replaces patchwork point solutions with a single platform that streamlines software development, giving you full visibility and control. The best part? Security and compliance are built-in. Declutter your DevSecOps with GitLab.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "🦊 GitLab",
                  "screenName" : "@gitlab"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "GitHub"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 to 54"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  }
                ],
                "impressionTime" : "2022-10-28 23:47:27"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-28 23:47:29",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91769",
                  "name" : "#ModernWarfare2",
                  "description" : "Call of Duty: Modern Warfare II is available now!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Call of Duty",
                  "screenName" : "@CallofDuty"
                },
                "impressionTime" : "2022-10-28 23:10:46"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-28 23:10:47",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91769",
                  "name" : "#ModernWarfare2",
                  "description" : "Call of Duty: Modern Warfare II is available now!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Call of Duty",
                  "screenName" : "@CallofDuty"
                },
                "impressionTime" : "2022-10-28 23:10:53"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-28 23:10:54",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91769",
                  "name" : "#ModernWarfare2",
                  "description" : "Call of Duty: Modern Warfare II is available now!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Call of Duty",
                  "screenName" : "@CallofDuty"
                },
                "impressionTime" : "2022-10-28 18:32:08"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-28 18:32:09",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91705",
                  "name" : "#SpiritHallowMeme",
                  "description" : "Halloween Starts Now. Share your favorite Spirit Meme."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Spirit Halloween",
                  "screenName" : "@SpiritHalloween"
                },
                "impressionTime" : "2022-10-29 14:58:47"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-29 14:58:48",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91705",
                  "name" : "#SpiritHallowMeme",
                  "description" : "Halloween Starts Now. Share your favorite Spirit Meme."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Spirit Halloween",
                  "screenName" : "@SpiritHalloween"
                },
                "impressionTime" : "2022-10-29 14:48:25"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-29 14:48:25",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91705",
                  "name" : "#SpiritHallowMeme",
                  "description" : "Halloween Starts Now. Share your favorite Spirit Meme."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Spirit Halloween",
                  "screenName" : "@SpiritHalloween"
                },
                "impressionTime" : "2022-10-30 01:21:53"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-30 01:21:54",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91705",
                  "name" : "#SpiritHallowMeme",
                  "description" : "Halloween Starts Now. Share your favorite Spirit Meme."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Spirit Halloween",
                  "screenName" : "@SpiritHalloween"
                },
                "impressionTime" : "2022-10-30 01:56:49"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-30 01:56:50",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91705",
                  "name" : "#SpiritHallowMeme",
                  "description" : "Halloween Starts Now. Share your favorite Spirit Meme."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Spirit Halloween",
                  "screenName" : "@SpiritHalloween"
                },
                "impressionTime" : "2022-10-29 15:00:10"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-29 15:00:11",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91705",
                  "name" : "#SpiritHallowMeme",
                  "description" : "Halloween Starts Now. Share your favorite Spirit Meme."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Spirit Halloween",
                  "screenName" : "@SpiritHalloween"
                },
                "impressionTime" : "2022-10-29 21:42:32"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-29 21:42:33",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91705",
                  "name" : "#SpiritHallowMeme",
                  "description" : "Halloween Starts Now. Share your favorite Spirit Meme."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Spirit Halloween",
                  "screenName" : "@SpiritHalloween"
                },
                "impressionTime" : "2022-10-29 21:19:22"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-29 21:19:22",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91705",
                  "name" : "#SpiritHallowMeme",
                  "description" : "Halloween Starts Now. Share your favorite Spirit Meme."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Spirit Halloween",
                  "screenName" : "@SpiritHalloween"
                },
                "impressionTime" : "2022-10-30 03:02:09"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-30 03:02:10",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91490",
                  "name" : "#TheWhiteLotus",
                  "description" : "Streaming tonight at 9PM on HBO Max"
                },
                "advertiserInfo" : {
                  "advertiserName" : "HBO Max",
                  "screenName" : "@hbomax"
                },
                "impressionTime" : "2022-10-30 15:12:31"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-30 15:12:32",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91490",
                  "name" : "#TheWhiteLotus",
                  "description" : "Streaming tonight at 9PM on HBO Max"
                },
                "advertiserInfo" : {
                  "advertiserName" : "HBO Max",
                  "screenName" : "@hbomax"
                },
                "impressionTime" : "2022-10-30 17:23:29"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-30 17:23:29",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91490",
                  "name" : "#TheWhiteLotus",
                  "description" : "Streaming tonight at 9PM on HBO Max"
                },
                "advertiserInfo" : {
                  "advertiserName" : "HBO Max",
                  "screenName" : "@hbomax"
                },
                "impressionTime" : "2022-10-30 17:20:57"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-30 17:20:58",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91490",
                  "name" : "#TheWhiteLotus",
                  "description" : "Streaming tonight at 9PM on HBO Max"
                },
                "advertiserInfo" : {
                  "advertiserName" : "HBO Max",
                  "screenName" : "@hbomax"
                },
                "impressionTime" : "2022-10-31 02:57:35"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-31 02:57:35",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91490",
                  "name" : "#TheWhiteLotus",
                  "description" : "Streaming tonight at 9PM on HBO Max"
                },
                "advertiserInfo" : {
                  "advertiserName" : "HBO Max",
                  "screenName" : "@hbomax"
                },
                "impressionTime" : "2022-10-30 21:25:43"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-30 21:25:44",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91490",
                  "name" : "#TheWhiteLotus",
                  "description" : "Streaming tonight at 9PM on HBO Max"
                },
                "advertiserInfo" : {
                  "advertiserName" : "HBO Max",
                  "screenName" : "@hbomax"
                },
                "impressionTime" : "2022-10-31 03:01:33"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-31 03:01:33",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "89663",
                  "name" : "#HOTD",
                  "description" : "Streaming tonight at 9PM"
                },
                "advertiserInfo" : {
                  "advertiserName" : "HBO Max",
                  "screenName" : "@hbomax"
                },
                "impressionTime" : "2022-08-21 13:26:49"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-08-21 13:26:51",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "SearchTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1587051762396983297",
                  "tweetText" : "Underestimate Camille at your peril. #DangerousLiaisons premieres November 6 on STARZ. https://t.co/5oy5TYN5X5",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/5oy5TYN5X5"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Dangerous Liaisons",
                  "screenName" : "@DangerousSTARZ"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Outlander"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  }
                ],
                "impressionTime" : "2022-10-31 23:31:12"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-31 23:31:13",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1583205898872553472",
                  "tweetText" : "Enjoy unlimited travel on the Commuter Rail for just $10 every weekend.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "MBTA Commuter Rail",
                  "screenName" : "@MBTA_CR"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Sporting events"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "01742"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 34"
                  }
                ],
                "impressionTime" : "2022-10-31 18:50:26"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-31 18:50:28",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1585873385132810241",
                  "tweetText" : "We are happy to help propel small businesses to a brighter and more secure future.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Wells Fargo",
                  "screenName" : "@WellsFargo"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "New York"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2022-10-31 20:09:52"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-31 20:09:54",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1573142087146831872",
                  "tweetText" : "Don't pass on great coverage. Switch to Arbella and combine your home &amp; auto insurance to save 20% or more.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Arbella Insurance",
                  "screenName" : "@ArbellaIns"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "#financialservices"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "financial"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "financing"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "#financial"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "finance"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Massachusetts"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2022-11-02 19:45:33"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-02 19:45:35",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  }
]