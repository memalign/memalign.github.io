window.YTD.direct_messages.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "144119186-2444552670",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "144119186",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "If I'm allowed multiple:\nR(5,5)\n:P",
            "mediaUrls" : [ ],
            "senderId" : "2444552670",
            "id" : "692158825256845315",
            "createdAt" : "2016-01-27T01:34:58.346Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "144119186",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "π",
            "mediaUrls" : [ ],
            "senderId" : "2444552670",
            "id" : "692029127801638916",
            "createdAt" : "2016-01-26T16:59:36.101Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "763141069-2444552670",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "2444552670",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Emailed! :)",
            "mediaUrls" : [ ],
            "senderId" : "763141069",
            "id" : "1215265046571487236",
            "createdAt" : "2020-01-09T13:32:20.326Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "763141069",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hey there!\nMy email is jack.l.lance@gmail.com",
            "mediaUrls" : [ ],
            "senderId" : "2444552670",
            "id" : "1215047137291120650",
            "createdAt" : "2020-01-08T23:06:26.754Z"
          }
        }
      ]
    }
  }
]