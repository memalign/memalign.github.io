window.YTD.screen_name_change.part0 = [
  {
    "screenNameChange" : {
      "accountId" : "2444552670",
      "screenNameChange" : {
        "changedAt" : "2014-04-15T19:08:25.000Z",
        "changedFrom" : "A_lot_lance",
        "changedTo" : "Jack_L_Lance"
      }
    }
  }
]