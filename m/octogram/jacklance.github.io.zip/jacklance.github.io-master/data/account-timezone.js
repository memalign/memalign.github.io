window.YTD.account_timezone.part0 = [
  {
    "accountTimezone" : {
      "accountId" : "2444552670",
      "timeZone" : "Atlantic Time (Canada)"
    }
  }
]