window.YTD.block.part0 = [
  {
    "blocking" : {
      "accountId" : "316048083",
      "userLink" : "https://twitter.com/intent/user?user_id=316048083"
    }
  }
]