window.YTD.direct_message_headers.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "144119186-2444552670",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "692158825256845315",
            "senderId" : "2444552670",
            "recipientId" : "144119186",
            "createdAt" : "2016-01-27T01:34:58.346Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "692029127801638916",
            "senderId" : "2444552670",
            "recipientId" : "144119186",
            "createdAt" : "2016-01-26T16:59:36.101Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "763141069-2444552670",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "1215265046571487236",
            "senderId" : "763141069",
            "recipientId" : "2444552670",
            "createdAt" : "2020-01-09T13:32:20.326Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1215047137291120650",
            "senderId" : "2444552670",
            "recipientId" : "763141069",
            "createdAt" : "2020-01-08T23:06:26.754Z"
          }
        }
      ]
    }
  }
]