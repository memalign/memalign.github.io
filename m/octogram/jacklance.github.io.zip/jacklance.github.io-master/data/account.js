window.YTD.account.part0 = [
  {
    "account" : {
      "email" : "jack.l.lance@gmail.com",
      "createdVia" : "web",
      "username" : "Jack_L_Lance",
      "accountId" : "2444552670",
      "createdAt" : "2014-04-14T22:50:27.601Z",
      "accountDisplayName" : "Jack Lance"
    }
  }
]