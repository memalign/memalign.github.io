window.YTD.email_address_change.part0 = [
  {
    "emailAddressChange" : {
      "accountId" : "2444552670",
      "emailChange" : {
        "changedAt" : "2014-04-14T23:36:57.000Z",
        "changedFrom" : "",
        "changedTo" : "jack.l.lance@gmail.com"
      }
    }
  }
]