window.YTD.like.part0 = [
  {
    "like" : {
      "tweetId" : "1213746297171255298",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1213746297171255298"
    }
  },
  {
    "like" : {
      "tweetId" : "1182182050012581888",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1182182050012581888"
    }
  }
]