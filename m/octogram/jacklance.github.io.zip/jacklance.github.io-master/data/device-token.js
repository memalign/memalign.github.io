window.YTD.device_token.part0 = [
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "mu8XH647zdcfvRfvatiVY29HgRK99UoD96I3QSuD",
      "createdAt" : "2021-05-16T21:50:59.153Z",
      "lastSeenAt" : "2021-05-16T21:50:59.154Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "V1Oyk3y9uXnDx6nITasUXYCnktFuzjA1cgk2bOIN",
      "createdAt" : "2021-05-18T12:58:04.120Z",
      "lastSeenAt" : "2021-05-18T12:58:04.122Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "JnHYqC9X3u4KdU64zNVvpkZE61Vmp56XJfPXnfjk",
      "createdAt" : "2021-05-21T19:35:12.571Z",
      "lastSeenAt" : "2021-05-21T19:35:12.573Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "fXoEpbRljaAQzMZqha0lnWfQQhbicciXWpX8ONRh",
      "createdAt" : "2021-05-22T20:29:55.608Z",
      "lastSeenAt" : "2021-05-22T20:29:55.610Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "YRDKE2HjFIfSIkCN6bbfaxa5v2Pf6SBtN1JBGHTh",
      "createdAt" : "2021-05-23T18:58:28.060Z",
      "lastSeenAt" : "2021-05-23T18:58:28.061Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "7MKXLVNvwlXoyiJybalYHqPLI65ak2veE9hoZGoL",
      "createdAt" : "2021-05-26T20:43:08.566Z",
      "lastSeenAt" : "2021-05-26T20:43:08.567Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "9VzWA8Qz8HFmQEddfY6DAmr5MNL7dqJLeaufwcZa",
      "createdAt" : "2021-05-29T01:04:25.542Z",
      "lastSeenAt" : "2021-05-29T01:04:25.543Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "87q2OtdWqL8J0LVBRDo0LOxRvd9RcmiWSxRbkWX3",
      "createdAt" : "2021-06-02T20:26:21.754Z",
      "lastSeenAt" : "2021-06-02T20:26:21.756Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "GckbfIBGdc3RMRVRzOvm1ReqPCmUBmc2Ie9EzipN",
      "createdAt" : "2021-06-03T03:36:57.180Z",
      "lastSeenAt" : "2021-06-03T03:36:57.182Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "8UN8l0XS5tJQPWMtQQkThWSH29iXmMIOImH3wTLE",
      "createdAt" : "2021-06-04T01:37:54.848Z",
      "lastSeenAt" : "2021-06-04T01:37:54.849Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "c7uidf4YEPa8oWsUhL6aLmKq26kpt3wFHXLqb0m8",
      "createdAt" : "2021-06-04T16:19:42.017Z",
      "lastSeenAt" : "2021-06-04T16:19:42.020Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "A8LUQS4tSGtHhovEEXrEo4iDFZPQcyJXaRGkejIy",
      "createdAt" : "2021-06-07T17:39:52.438Z",
      "lastSeenAt" : "2021-06-07T17:39:52.440Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "pPD03UC6MfcXklsMD1YnQXHYPK1NbjM7of2Dajj4",
      "createdAt" : "2021-06-08T20:49:09.840Z",
      "lastSeenAt" : "2021-06-08T20:49:09.842Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "ckRwu4VpLiGq0jqlCC2fYInuNJB2IAyYbAOMerpb",
      "createdAt" : "2021-06-14T16:14:58.428Z",
      "lastSeenAt" : "2021-06-14T16:14:58.431Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "kbv3upCBvjrki4MM3Vmc2RqkIIX9hKyFkCz4Sjva",
      "createdAt" : "2021-06-17T20:54:05.946Z",
      "lastSeenAt" : "2021-06-17T20:54:05.948Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "Fp2ZutJvlaZDUipMzf6wkvXOerOH3yRoUYOeL6Sc",
      "createdAt" : "2021-06-23T14:12:39.123Z",
      "lastSeenAt" : "2021-06-23T14:12:39.124Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "SG8jUruwA0YEtAgm9QlQ0hVCKvFReCoohWaNsiU2",
      "createdAt" : "2021-06-24T19:23:35.085Z",
      "lastSeenAt" : "2021-06-24T19:23:35.087Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "R0ZtQNrtueUqecdmUg1CEYx4HadMclMWyuxvjfPJ",
      "createdAt" : "2021-06-25T02:51:55.436Z",
      "lastSeenAt" : "2021-06-25T02:51:55.438Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "puKS6U6KC1GNhmtFrGvNBAD3kD5u1jrlP90sP7mE",
      "createdAt" : "2021-06-27T04:03:13.137Z",
      "lastSeenAt" : "2021-06-27T04:03:13.140Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "5n1KlIutSogtRwi5o8CZCGH8CEU4NuCbA9uMS9UN",
      "createdAt" : "2021-06-29T15:25:39.615Z",
      "lastSeenAt" : "2021-06-29T15:25:39.618Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "mCiNw2Xo8I5Oda0R9dRyDHQsWZJ4lZNJgMTFwkql",
      "createdAt" : "2021-06-29T17:14:45.278Z",
      "lastSeenAt" : "2021-06-29T17:14:45.280Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "4zff3iTLBBth8KBh7RWLxOp6ZTyxt4RyCs8g6rwo",
      "createdAt" : "2021-06-29T23:46:39.253Z",
      "lastSeenAt" : "2021-06-29T23:46:39.255Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "1TEfS7lhW4jfCA4a0ulhilDaqq5pirY3kzKlahZw",
      "createdAt" : "2021-07-01T19:00:53.815Z",
      "lastSeenAt" : "2021-07-01T19:00:53.816Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "9r31rrPBQg2BurzQHXZpf6EPtFXullON0Gp6jwpL",
      "createdAt" : "2021-07-06T14:15:03.924Z",
      "lastSeenAt" : "2021-07-06T14:15:03.926Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "9W74j53bC2YNT4yLDLRAYW9CSKalNCWf8Vb3Rrqr",
      "createdAt" : "2021-07-07T18:19:38.855Z",
      "lastSeenAt" : "2021-07-07T18:19:38.857Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "sODxSdLiNuzO6XfyIweA6zFuBHbH1TV5aE3yADPm",
      "createdAt" : "2021-07-08T14:43:38.711Z",
      "lastSeenAt" : "2021-07-08T14:43:38.713Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "yrokXbH96nVMnubzv29t0xxPqrzAmWJQT47eWttg",
      "createdAt" : "2021-07-09T17:40:20.746Z",
      "lastSeenAt" : "2021-07-09T17:40:20.748Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "uBKpeXOglhY4aKsrFcA5ZVpZ1JBXJ92w0shDJBIo",
      "createdAt" : "2021-07-10T02:06:40.080Z",
      "lastSeenAt" : "2021-07-10T02:06:40.082Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "jt0fgPv61SgS8ttmsBPWDJNuxr7CPugmYxo42jik",
      "createdAt" : "2021-07-11T03:39:41.936Z",
      "lastSeenAt" : "2021-07-11T03:39:41.938Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "49152",
      "token" : "2eXzmFNoXX7rE493QVq0h2bGVMKE8f2cfizSbOEL",
      "createdAt" : "2021-07-12T23:37:17.804Z",
      "lastSeenAt" : "2021-07-12T23:37:17.805Z",
      "clientApplicationName" : "Mobile Web (Twitter)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "qTQ0rSvqJq2aUTupvEEoUdiqFwabUNWdIvNlyMjt",
      "createdAt" : "2021-07-13T17:46:52.934Z",
      "lastSeenAt" : "2021-07-13T17:46:52.936Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "gqKtzHlqlCWocBbek8EuOMcTLAiIf1LfLMjQ8RWj",
      "createdAt" : "2021-07-13T19:03:11.143Z",
      "lastSeenAt" : "2021-07-13T19:03:11.145Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "LOyKWl8fj0fFFI4A7IvuEjdmWFDDGaVLfDFZGifd",
      "createdAt" : "2021-07-15T18:29:18.113Z",
      "lastSeenAt" : "2021-07-15T18:29:18.117Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "Z5Jc6dvwCcRzbBHMV58Nby7ewlvj4Uc2j98ec2ma",
      "createdAt" : "2021-07-15T19:53:51.585Z",
      "lastSeenAt" : "2021-07-15T19:53:51.586Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "zqwAh8JDklcCCicqArRw5vxSMqXTs5UUlpIBVNA1",
      "createdAt" : "2021-07-16T13:07:58.139Z",
      "lastSeenAt" : "2021-07-16T13:07:58.141Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "Fimjw2OTjrgpyEka93Iy0hu9SNEXUBU1xA59nyfC",
      "createdAt" : "2021-07-19T20:09:45.241Z",
      "lastSeenAt" : "2021-07-19T20:09:45.244Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "eVedJfSCltRUGn7cZ6d08EEqVSgg6fjgqvLiZpid",
      "createdAt" : "2021-07-21T12:14:37.178Z",
      "lastSeenAt" : "2021-07-21T12:14:37.180Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "1gu4oJ4XXpcwU1yRV1VBi5Hron6uLCjusWt9XPdL",
      "createdAt" : "2021-07-21T21:16:37.741Z",
      "lastSeenAt" : "2021-07-21T21:16:37.742Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "fft8kwugXM4lLVLmn9Uye3g2YGRy4aESj85oUGDE",
      "createdAt" : "2021-07-25T16:23:43.170Z",
      "lastSeenAt" : "2021-07-25T16:23:43.173Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "6ZqRi5obZ2dwJJfM2OVkC4gnkiwIPdG7G2orXNc1",
      "createdAt" : "2021-07-25T23:01:02.944Z",
      "lastSeenAt" : "2021-07-25T23:01:02.947Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "Atp3knCC6RMh8ngkvw8vINXL3rQkvt5NASamTlJQ",
      "createdAt" : "2021-07-26T03:02:12.152Z",
      "lastSeenAt" : "2021-07-26T03:02:12.154Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "gai7kObUAU3VanwfNUm6nsRo4ZmPnvQHWPpIXR0M",
      "createdAt" : "2021-07-28T23:06:28.354Z",
      "lastSeenAt" : "2021-07-28T23:06:28.356Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "ICVo1K0BV1yTmQ3pivkBYPFD26jtiT1S2dYfsEro",
      "createdAt" : "2021-07-30T15:07:33.576Z",
      "lastSeenAt" : "2021-07-30T15:07:33.578Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "8GEQ1gbFhTXpFpohIkTfYdn8rKzTv2Qs5TvTlpk3",
      "createdAt" : "2021-08-07T01:57:47.987Z",
      "lastSeenAt" : "2021-08-07T01:57:47.988Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "0WaHGSIaMGYeADaWZfHS16vLqv3Gs2Jsij8Q8w6w",
      "createdAt" : "2021-08-08T03:28:10.785Z",
      "lastSeenAt" : "2021-08-08T03:28:10.787Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "P3pa6vfCmkqsRoasCp8OY1p5q3al8NzOuDCUXw82",
      "createdAt" : "2021-08-11T20:54:17.380Z",
      "lastSeenAt" : "2021-08-11T20:54:17.382Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "IlvllCae1rTRvdaAltF2wePuRcpx5ce0FJWWj8pR",
      "createdAt" : "2021-08-15T22:09:40.467Z",
      "lastSeenAt" : "2021-08-15T22:09:40.469Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "iWlNNZ5d5xJjMuaoAP5aWVLFJ45MWfIW2DAhhlul",
      "createdAt" : "2021-08-16T02:37:51.580Z",
      "lastSeenAt" : "2021-08-16T02:37:51.581Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "hJazCJZPa7GdAOyk8riiVjDIEFwRg84SxGukVJTy",
      "createdAt" : "2021-08-17T02:27:38.753Z",
      "lastSeenAt" : "2021-08-17T02:27:38.755Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "09l4D2AENuX8PcflWxMOGQZsifSXXBQubRbrTeoL",
      "createdAt" : "2021-08-17T03:23:03.390Z",
      "lastSeenAt" : "2021-08-17T03:23:03.392Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "VQtFIhs5eUc5Z1q6AJb5SbFiMrr7kf7aHDzSpip5",
      "createdAt" : "2021-08-17T17:32:35.440Z",
      "lastSeenAt" : "2021-08-17T17:32:35.442Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "DeHbXPba0wR5TMt7hBB1YbRDTBJIqfJBm0hrnjY0",
      "createdAt" : "2021-08-18T18:47:39.540Z",
      "lastSeenAt" : "2021-08-18T18:47:39.543Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "RSoYRlo1IX9Edvy6J0jSKNVVwt24awUM8t2CmB0q",
      "createdAt" : "2021-08-19T20:49:35.006Z",
      "lastSeenAt" : "2021-08-19T20:49:35.008Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "DxroNpDLbrjMkNzJHuEcJ2ikaLkVREONijOYF4f5",
      "createdAt" : "2021-08-28T21:08:56.989Z",
      "lastSeenAt" : "2021-08-28T21:08:56.991Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "0POG2FJPkvgyHilRYJBAYuBqySeFquRd1jvhNVnn",
      "createdAt" : "2021-08-30T00:30:46.517Z",
      "lastSeenAt" : "2021-08-30T00:30:46.519Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "KNRg4FAGfkBY3gyFpHJZrFZOWXRHHLaU8t2ERpwu",
      "createdAt" : "2021-08-30T01:28:56.726Z",
      "lastSeenAt" : "2021-08-30T01:28:56.728Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "gJzW7mFvKzKOBbLk5RSM7ePaHHferzfX4uEzlXXL",
      "createdAt" : "2021-09-01T02:31:16.870Z",
      "lastSeenAt" : "2021-09-01T02:31:16.872Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "BB3irHsBbrU63G9wXdBZkKUPK6MypNIza5GpgcCa",
      "createdAt" : "2021-09-02T12:53:04.046Z",
      "lastSeenAt" : "2021-09-02T12:53:04.048Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "ahGqqpu2kR97U7lLudfj4mqBffenxIanOpfc7d7z",
      "createdAt" : "2021-09-05T02:14:50.349Z",
      "lastSeenAt" : "2021-09-05T02:14:50.350Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "MHPSS0lhwDrwr6q6Oz223Rx2P9EDSJ8aePT7MD8D",
      "createdAt" : "2021-09-08T03:12:10.647Z",
      "lastSeenAt" : "2021-09-08T03:12:10.649Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "ZV3nxEjv10mAcm0D2NR03K4YOrtV6KfagVyL05WJ",
      "createdAt" : "2021-09-10T04:09:33.342Z",
      "lastSeenAt" : "2021-09-10T04:09:33.344Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "x3SjVqnsVTLxpLRs26YKoW5RmWE3yTXVSTcKWtiP",
      "createdAt" : "2021-09-11T03:21:49.964Z",
      "lastSeenAt" : "2021-09-11T03:21:49.965Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "KPWBAYjYxa9oImG25wxpWywBchUeibgxUm6nNVjD",
      "createdAt" : "2021-09-11T05:56:57.324Z",
      "lastSeenAt" : "2021-09-11T05:56:57.326Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "mRSBkyG9QqUWxQGCwUKqQLuJDtAk250Ei780VNft",
      "createdAt" : "2021-09-12T12:54:44.905Z",
      "lastSeenAt" : "2021-09-12T12:54:44.906Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "JiMxjJxCSsoMtSft8qEnY6P0nlCCg45BQljDX0F3",
      "createdAt" : "2021-09-12T13:31:24.168Z",
      "lastSeenAt" : "2021-09-12T13:31:24.170Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "nS6D3KXQm9b7ao6E8f8UHv7sMnDAFVyKRDxpU7PL",
      "createdAt" : "2021-09-12T15:56:10.421Z",
      "lastSeenAt" : "2021-09-12T15:56:10.423Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "1J6RFapWMBnqkxc2RTBnmfUnBD8psONQjKibGVYp",
      "createdAt" : "2021-09-13T02:55:14.022Z",
      "lastSeenAt" : "2021-09-13T02:55:14.038Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "fp7vT0gFCSxu3kvC126nwaE19Yi8Z7oZQPsSmSzK",
      "createdAt" : "2021-09-16T13:19:10.437Z",
      "lastSeenAt" : "2021-09-16T13:19:10.456Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "O5sBaujmzj39T0gVZeHrfQgBlmIxcILSmAVp9y2e",
      "createdAt" : "2021-09-19T19:30:32.806Z",
      "lastSeenAt" : "2021-09-19T19:30:32.808Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "B2wjyLUAZrmX48UOqT5EvsHCsT8s6xWRy0N5Ud7d",
      "createdAt" : "2021-09-21T12:35:57.917Z",
      "lastSeenAt" : "2021-09-21T12:35:57.920Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "0Z6D9WG1r2xGMe2uc6q6nS1Pm9JSRg3BtOe1zD2I",
      "createdAt" : "2021-09-23T02:58:14.190Z",
      "lastSeenAt" : "2021-09-23T02:58:14.192Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "w9RcRVXEy35omvjIYPG46UIOkApkAeGqQvlyefe7",
      "createdAt" : "2021-09-26T03:29:10.914Z",
      "lastSeenAt" : "2021-09-26T03:29:10.917Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "i7L8pLSX7pkP9jlHf57zQrtaXYRbvawBRTXsBl7t",
      "createdAt" : "2021-09-30T01:23:48.176Z",
      "lastSeenAt" : "2021-09-30T01:23:48.178Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "j8JV0BrL3pB0YSQTd46qWski4a1oAGXxvtHJdnZW",
      "createdAt" : "2021-10-02T03:37:03.943Z",
      "lastSeenAt" : "2021-10-02T03:37:03.944Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "EpGMPlu0or6aRFUWZeE2hD2XUiYSZtN8OFnkWPBG",
      "createdAt" : "2022-04-04T00:33:22.135Z",
      "lastSeenAt" : "2022-04-04T00:33:22.137Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "49152",
      "token" : "tmA880K9QdqFOpUsLmDxhXOly14skYPGoFArZCgT",
      "createdAt" : "2021-07-12T23:37:17.809Z",
      "lastSeenAt" : "2022-07-11T18:02:19.169Z",
      "clientApplicationName" : "Mobile Web (Twitter)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "7czcFxboTw3EecUf2SaXaGsBJZcuibeTV6UD64hc",
      "createdAt" : "2021-08-25T00:42:10.527Z",
      "lastSeenAt" : "2022-07-12T02:46:06.618Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "kepPoYrjmxaJDMHQ4Z3x50ullrTWEYN97T51MKYQ",
      "createdAt" : "2022-10-06T03:50:16.983Z",
      "lastSeenAt" : "2022-10-06T12:35:57.522Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "FHoXPrE6558eqiydLRjIgBxdTsr3wTuLcxvencet",
      "createdAt" : "2022-10-18T03:23:31.408Z",
      "lastSeenAt" : "2022-10-18T03:23:31.410Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  }
]