window.YTD.tweets.part0 = [
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1578140301146918914"
          ],
          "editableUntil" : "2022-10-06T22:19:02.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "280"
      ],
      "favorite_count" : "7",
      "id_str" : "1578140301146918914",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1578140301146918914",
      "created_at" : "Thu Oct 06 21:49:02 +0000 2022",
      "favorited" : false,
      "full_text" : "They might be found (showing inclination?) in a college math class (??????/??? ?.?.?)\n\nAn angry reaction (???/\"? ??!\")\n\nGrad schools get many applications, and generally accept the ________ (????????/??? (? ????))\n\nMRW someone makes a sexual joke about me (???????/\"??, ?'? ???.\")",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1571521051921629184"
          ],
          "editableUntil" : "2022-09-18T15:56:30.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1571521051921629184/photo/1",
            "indices" : [
              "0",
              "23"
            ],
            "url" : "https://t.co/cbVNR9XiBc",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/Fc8qDcBXwAEhLJT.jpg",
            "id_str" : "1571521033525510145",
            "id" : "1571521033525510145",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/Fc8qDcBXwAEhLJT.jpg",
            "sizes" : {
              "large" : {
                "w" : "614",
                "h" : "366",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "614",
                "h" : "366",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "614",
                "h" : "366",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/cbVNR9XiBc"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "72",
      "id_str" : "1571521051921629184",
      "truncated" : false,
      "retweet_count" : "21",
      "id" : "1571521051921629184",
      "possibly_sensitive" : false,
      "created_at" : "Sun Sep 18 15:26:30 +0000 2022",
      "favorited" : false,
      "full_text" : "https://t.co/cbVNR9XiBc",
      "lang" : "zxx",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1571521051921629184/photo/1",
            "indices" : [
              "0",
              "23"
            ],
            "url" : "https://t.co/cbVNR9XiBc",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/Fc8qDcBXwAEhLJT.jpg",
            "id_str" : "1571521033525510145",
            "video_info" : {
              "aspect_ratio" : [
                "307",
                "183"
              ],
              "variants" : [
                {
                  "bitrate" : "0",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/tweet_video/Fc8qDcBXwAEhLJT.mp4"
                }
              ]
            },
            "id" : "1571521033525510145",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/Fc8qDcBXwAEhLJT.jpg",
            "sizes" : {
              "large" : {
                "w" : "614",
                "h" : "366",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "614",
                "h" : "366",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "614",
                "h" : "366",
                "resize" : "fit"
              }
            },
            "type" : "animated_gif",
            "display_url" : "pic.twitter.com/cbVNR9XiBc"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1570088413931491330"
          ],
          "editableUntil" : "2022-09-14T17:03:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1570088413931491330/photo/1",
            "indices" : [
              "22",
              "45"
            ],
            "url" : "https://t.co/CPA1oO9ViL",
            "media_url" : "http://pbs.twimg.com/media/FcoS01IWAAUKXgn.png",
            "id_str" : "1570088118916612101",
            "id" : "1570088118916612101",
            "media_url_https" : "https://pbs.twimg.com/media/FcoS01IWAAUKXgn.png",
            "sizes" : {
              "small" : {
                "w" : "453",
                "h" : "471",
                "resize" : "fit"
              },
              "large" : {
                "w" : "453",
                "h" : "471",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "453",
                "h" : "471",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/CPA1oO9ViL"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "45"
      ],
      "favorite_count" : "27",
      "id_str" : "1570088413931491330",
      "truncated" : false,
      "retweet_count" : "5",
      "id" : "1570088413931491330",
      "possibly_sensitive" : false,
      "created_at" : "Wed Sep 14 16:33:43 +0000 2022",
      "favorited" : false,
      "full_text" : "Here's a star battle. https://t.co/CPA1oO9ViL",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1570088413931491330/photo/1",
            "indices" : [
              "22",
              "45"
            ],
            "url" : "https://t.co/CPA1oO9ViL",
            "media_url" : "http://pbs.twimg.com/media/FcoS01IWAAUKXgn.png",
            "id_str" : "1570088118916612101",
            "id" : "1570088118916612101",
            "media_url_https" : "https://pbs.twimg.com/media/FcoS01IWAAUKXgn.png",
            "sizes" : {
              "small" : {
                "w" : "453",
                "h" : "471",
                "resize" : "fit"
              },
              "large" : {
                "w" : "453",
                "h" : "471",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "453",
                "h" : "471",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/CPA1oO9ViL"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1568038379576516608"
          ],
          "editableUntil" : "2022-09-09T01:17:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "55"
      ],
      "favorite_count" : "18",
      "id_str" : "1568038379576516608",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1568038379576516608",
      "created_at" : "Fri Sep 09 00:47:37 +0000 2022",
      "favorited" : false,
      "full_text" : "LGBTQ'S \"P\" (\"I'D FUCK W/ ANY\") + J OVER 1000(M X HZ)^2",
      "lang" : "pl"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1567957705784184834"
          ],
          "editableUntil" : "2022-09-08T19:57:02.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "12",
      "id_str" : "1567957705784184834",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1567957705784184834",
      "created_at" : "Thu Sep 08 19:27:02 +0000 2022",
      "favorited" : false,
      "full_text" : "Poe &amp; T.S. = POETS!",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1546556193358987269"
          ],
          "editableUntil" : "2022-07-11T18:35:04.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "88"
      ],
      "favorite_count" : "32",
      "id_str" : "1546556193358987269",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1546556193358987269",
      "created_at" : "Mon Jul 11 18:05:04 +0000 2022",
      "favorited" : false,
      "full_text" : "Caesar shift the first four roman numerals forward by their value's largest odd divisor.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1543067249065459713"
          ],
          "editableUntil" : "2022-07-02T03:31:15.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "97"
      ],
      "favorite_count" : "62",
      "id_str" : "1543067249065459713",
      "truncated" : false,
      "retweet_count" : "9",
      "id" : "1543067249065459713",
      "created_at" : "Sat Jul 02 03:01:15 +0000 2022",
      "favorited" : false,
      "full_text" : "The word ANTICLOCKWISE contains each of the four compass points once, and in anticlockwise order!",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1541063921309814784"
          ],
          "editableUntil" : "2022-06-26T14:50:45.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "84"
      ],
      "favorite_count" : "21",
      "id_str" : "1541063921309814784",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1541063921309814784",
      "created_at" : "Sun Jun 26 14:20:45 +0000 2022",
      "favorited" : false,
      "full_text" : "You can swap the third and eighth letter of BUST A NUT to get BUTT ANUS, send tweet.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1540787713099460615"
          ],
          "editableUntil" : "2022-06-25T20:33:11.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1540787713099460615/photo/1",
            "indices" : [
              "0",
              "23"
            ],
            "url" : "https://t.co/gYYO9xDQLy",
            "media_url" : "http://pbs.twimg.com/media/FWH6NwiUsAw_Jj_.png",
            "id_str" : "1540787661811527692",
            "id" : "1540787661811527692",
            "media_url_https" : "https://pbs.twimg.com/media/FWH6NwiUsAw_Jj_.png",
            "sizes" : {
              "medium" : {
                "w" : "184",
                "h" : "496",
                "resize" : "fit"
              },
              "small" : {
                "w" : "184",
                "h" : "496",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "184",
                "h" : "496",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/gYYO9xDQLy"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "22",
      "id_str" : "1540787713099460615",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1540787713099460615",
      "possibly_sensitive" : false,
      "created_at" : "Sat Jun 25 20:03:11 +0000 2022",
      "favorited" : false,
      "full_text" : "https://t.co/gYYO9xDQLy",
      "lang" : "zxx",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1540787713099460615/photo/1",
            "indices" : [
              "0",
              "23"
            ],
            "url" : "https://t.co/gYYO9xDQLy",
            "media_url" : "http://pbs.twimg.com/media/FWH6NwiUsAw_Jj_.png",
            "id_str" : "1540787661811527692",
            "id" : "1540787661811527692",
            "media_url_https" : "https://pbs.twimg.com/media/FWH6NwiUsAw_Jj_.png",
            "sizes" : {
              "medium" : {
                "w" : "184",
                "h" : "496",
                "resize" : "fit"
              },
              "small" : {
                "w" : "184",
                "h" : "496",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "184",
                "h" : "496",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/gYYO9xDQLy"
          },
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1540787713099460615/photo/1",
            "indices" : [
              "0",
              "23"
            ],
            "url" : "https://t.co/gYYO9xDQLy",
            "media_url" : "http://pbs.twimg.com/media/FWH6Pb8WIAIU8AJ.png",
            "id_str" : "1540787690643267586",
            "id" : "1540787690643267586",
            "media_url_https" : "https://pbs.twimg.com/media/FWH6Pb8WIAIU8AJ.png",
            "sizes" : {
              "medium" : {
                "w" : "496",
                "h" : "184",
                "resize" : "fit"
              },
              "small" : {
                "w" : "496",
                "h" : "184",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "496",
                "h" : "184",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/gYYO9xDQLy"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1534305729749958658"
          ],
          "editableUntil" : "2022-06-07T23:16:06.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1534305729749958658/photo/1",
            "indices" : [
              "0",
              "23"
            ],
            "url" : "https://t.co/Pjuyw9coTp",
            "media_url" : "http://pbs.twimg.com/media/FUry4mqXsAEbYtP.png",
            "id_str" : "1534305677337931777",
            "id" : "1534305677337931777",
            "media_url_https" : "https://pbs.twimg.com/media/FUry4mqXsAEbYtP.png",
            "sizes" : {
              "small" : {
                "w" : "607",
                "h" : "329",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "607",
                "h" : "329",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "607",
                "h" : "329",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/Pjuyw9coTp"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "50",
      "id_str" : "1534305729749958658",
      "truncated" : false,
      "retweet_count" : "4",
      "id" : "1534305729749958658",
      "possibly_sensitive" : false,
      "created_at" : "Tue Jun 07 22:46:06 +0000 2022",
      "favorited" : false,
      "full_text" : "https://t.co/Pjuyw9coTp",
      "lang" : "zxx",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1534305729749958658/photo/1",
            "indices" : [
              "0",
              "23"
            ],
            "url" : "https://t.co/Pjuyw9coTp",
            "media_url" : "http://pbs.twimg.com/media/FUry4mqXsAEbYtP.png",
            "id_str" : "1534305677337931777",
            "id" : "1534305677337931777",
            "media_url_https" : "https://pbs.twimg.com/media/FUry4mqXsAEbYtP.png",
            "sizes" : {
              "small" : {
                "w" : "607",
                "h" : "329",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "607",
                "h" : "329",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "607",
                "h" : "329",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/Pjuyw9coTp"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1534213444253143041"
          ],
          "editableUntil" : "2022-06-07T17:09:24.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1534213444253143041/photo/1",
            "indices" : [
              "0",
              "23"
            ],
            "url" : "https://t.co/joAscI64Aw",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/FUqe-EmXoAIY9JZ.jpg",
            "id_str" : "1534213412296826882",
            "id" : "1534213412296826882",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/FUqe-EmXoAIY9JZ.jpg",
            "sizes" : {
              "large" : {
                "w" : "1024",
                "h" : "458",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "304",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1024",
                "h" : "458",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/joAscI64Aw"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "25",
      "id_str" : "1534213444253143041",
      "truncated" : false,
      "retweet_count" : "5",
      "id" : "1534213444253143041",
      "possibly_sensitive" : false,
      "created_at" : "Tue Jun 07 16:39:24 +0000 2022",
      "favorited" : false,
      "full_text" : "https://t.co/joAscI64Aw",
      "lang" : "zxx",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1534213444253143041/photo/1",
            "indices" : [
              "0",
              "23"
            ],
            "url" : "https://t.co/joAscI64Aw",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/FUqe-EmXoAIY9JZ.jpg",
            "id_str" : "1534213412296826882",
            "video_info" : {
              "aspect_ratio" : [
                "512",
                "229"
              ],
              "variants" : [
                {
                  "bitrate" : "0",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/tweet_video/FUqe-EmXoAIY9JZ.mp4"
                }
              ]
            },
            "id" : "1534213412296826882",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/FUqe-EmXoAIY9JZ.jpg",
            "sizes" : {
              "large" : {
                "w" : "1024",
                "h" : "458",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "304",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1024",
                "h" : "458",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "animated_gif",
            "display_url" : "pic.twitter.com/joAscI64Aw"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1521999102518702082"
          ],
          "editableUntil" : "2022-05-05T00:13:58.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "130"
      ],
      "favorite_count" : "18",
      "id_str" : "1521999102518702082",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1521999102518702082",
      "created_at" : "Wed May 04 23:43:58 +0000 2022",
      "favorited" : false,
      "full_text" : "Take evenly spaced letters from a very popular band from the past (without the \"the\") to get a very popular band from the present.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1503465472787947525"
          ],
          "editableUntil" : "2022-03-14T20:47:56.407Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/EexRNKtVqC",
            "expanded_url" : "https://jacoblance.wordpress.com/2022/03/14/p-i-hunt-8/",
            "display_url" : "jacoblance.wordpress.com/2022/03/14/p-i…",
            "indices" : [
              "114",
              "137"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1503465472787947525/photo/1",
            "indices" : [
              "202",
              "225"
            ],
            "url" : "https://t.co/aGADb1HDVA",
            "media_url" : "http://pbs.twimg.com/media/FN1hxrXXwAUZCm1.png",
            "id_str" : "1503465356693848069",
            "id" : "1503465356693848069",
            "media_url_https" : "https://pbs.twimg.com/media/FN1hxrXXwAUZCm1.png",
            "sizes" : {
              "medium" : {
                "w" : "711",
                "h" : "709",
                "resize" : "fit"
              },
              "large" : {
                "w" : "711",
                "h" : "709",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "678",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/aGADb1HDVA"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "225"
      ],
      "favorite_count" : "22",
      "id_str" : "1503465472787947525",
      "truncated" : false,
      "retweet_count" : "4",
      "id" : "1503465472787947525",
      "possibly_sensitive" : false,
      "created_at" : "Mon Mar 14 20:17:56 +0000 2022",
      "favorited" : false,
      "full_text" : "P.I.HUNT 8 is out now! I'm excited for people to finally see it as I think it's something really cool this year! \nhttps://t.co/EexRNKtVqC\n\nP.S. The gaps in the solution to the previous tweet spell PI 8 https://t.co/aGADb1HDVA",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1503465472787947525/photo/1",
            "indices" : [
              "202",
              "225"
            ],
            "url" : "https://t.co/aGADb1HDVA",
            "media_url" : "http://pbs.twimg.com/media/FN1hxrXXwAUZCm1.png",
            "id_str" : "1503465356693848069",
            "id" : "1503465356693848069",
            "media_url_https" : "https://pbs.twimg.com/media/FN1hxrXXwAUZCm1.png",
            "sizes" : {
              "medium" : {
                "w" : "711",
                "h" : "709",
                "resize" : "fit"
              },
              "large" : {
                "w" : "711",
                "h" : "709",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "678",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/aGADb1HDVA"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1493274518282031107"
          ],
          "editableUntil" : "2022-02-14T17:52:43.514Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Jamie is a sleepy nut",
            "screen_name" : "InfinitNutshell",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "397029100",
            "id" : "397029100"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "106"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1493272933271281666",
      "id_str" : "1493274518282031107",
      "in_reply_to_user_id" : "397029100",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1493274518282031107",
      "in_reply_to_status_id" : "1493272933271281666",
      "created_at" : "Mon Feb 14 17:22:43 +0000 2022",
      "favorited" : false,
      "full_text" : "@InfinitNutshell You should try drawing it out and taking a look at the solution (or a rotation of it). ;)",
      "lang" : "en",
      "in_reply_to_screen_name" : "InfinitNutshell",
      "in_reply_to_user_id_str" : "397029100"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1493255520970547203"
          ],
          "editableUntil" : "2022-02-14T16:37:14.202Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1493255520970547203/photo/1",
            "indices" : [
              "216",
              "239"
            ],
            "url" : "https://t.co/P7Oc1jXZ6m",
            "media_url" : "http://pbs.twimg.com/media/FLkbaZTWUAA9P2T.png",
            "id_str" : "1493254891732619264",
            "id" : "1493254891732619264",
            "media_url_https" : "https://pbs.twimg.com/media/FLkbaZTWUAA9P2T.png",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "315",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "947",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "555",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/P7Oc1jXZ6m"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "239"
      ],
      "favorite_count" : "17",
      "id_str" : "1493255520970547203",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1493255520970547203",
      "possibly_sensitive" : false,
      "created_at" : "Mon Feb 14 16:07:14 +0000 2022",
      "favorited" : false,
      "full_text" : "P.I.HUNT 8 is coming in one month! (assuming I finish it by then aaaah)\n\nTo celebrate, here's a warm-up puzzle:\nPlace all the white pieces on the right onto the black square on the left so the outer edge matches up. https://t.co/P7Oc1jXZ6m",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1493255520970547203/photo/1",
            "indices" : [
              "216",
              "239"
            ],
            "url" : "https://t.co/P7Oc1jXZ6m",
            "media_url" : "http://pbs.twimg.com/media/FLkbaZTWUAA9P2T.png",
            "id_str" : "1493254891732619264",
            "id" : "1493254891732619264",
            "media_url_https" : "https://pbs.twimg.com/media/FLkbaZTWUAA9P2T.png",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "315",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "947",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "555",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/P7Oc1jXZ6m"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1485975800952332291"
          ],
          "editableUntil" : "2022-01-25T14:30:13.699Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "100"
      ],
      "favorite_count" : "24",
      "id_str" : "1485975800952332291",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1485975800952332291",
      "created_at" : "Tue Jan 25 14:00:13 +0000 2022",
      "favorited" : false,
      "full_text" : "Three of the most common nouns that begin with a double letter all surprisingly are in one category.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1460062503136866304"
          ],
          "editableUntil" : "2021-11-15T02:20:02.054Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "99"
      ],
      "favorite_count" : "35",
      "id_str" : "1460062503136866304",
      "truncated" : false,
      "retweet_count" : "6",
      "id" : "1460062503136866304",
      "created_at" : "Mon Nov 15 01:50:02 +0000 2021",
      "favorited" : false,
      "full_text" : "Shifting the first and last letters of A VILLAIN forward 4 letters in the alphabet gives EVIL LAIR.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1453361815199666179"
          ],
          "editableUntil" : "2021-10-27T14:33:53.557Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1453361815199666179/photo/1",
            "indices" : [
              "17",
              "40"
            ],
            "url" : "https://t.co/fmukVCDynO",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/FCtglLZWEA4vhFX.jpg",
            "id_str" : "1453361496587636750",
            "id" : "1453361496587636750",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/FCtglLZWEA4vhFX.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1136",
                "h" : "524",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1136",
                "h" : "524",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "314",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/fmukVCDynO"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "35",
      "id_str" : "1453361815199666179",
      "truncated" : false,
      "retweet_count" : "5",
      "id" : "1453361815199666179",
      "possibly_sensitive" : false,
      "created_at" : "Wed Oct 27 14:03:53 +0000 2021",
      "favorited" : false,
      "full_text" : "It is Wednesday. https://t.co/fmukVCDynO",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1453361815199666179/photo/1",
            "indices" : [
              "17",
              "40"
            ],
            "url" : "https://t.co/fmukVCDynO",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/FCtglLZWEA4vhFX.jpg",
            "id_str" : "1453361496587636750",
            "video_info" : {
              "aspect_ratio" : [
                "284",
                "131"
              ],
              "variants" : [
                {
                  "bitrate" : "0",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/tweet_video/FCtglLZWEA4vhFX.mp4"
                }
              ]
            },
            "id" : "1453361496587636750",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/FCtglLZWEA4vhFX.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1136",
                "h" : "524",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1136",
                "h" : "524",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "314",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "animated_gif",
            "display_url" : "pic.twitter.com/fmukVCDynO"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1449874170003836934"
          ],
          "editableUntil" : "2021-10-17T23:35:14.145Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "42"
      ],
      "favorite_count" : "80",
      "id_str" : "1449874170003836934",
      "truncated" : false,
      "retweet_count" : "10",
      "id" : "1449874170003836934",
      "created_at" : "Sun Oct 17 23:05:14 +0000 2021",
      "favorited" : false,
      "full_text" : "PESCETARIAN\nis an anagram of\nCARP IS EATEN",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1432721013205258248"
          ],
          "editableUntil" : "2021-08-31T15:34:42.874Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/o6pimFovtk",
            "expanded_url" : "https://pedropsi.github.io/unequal-length-mazes.html?W=9&L=f17s18b59&A=Jack_Lance",
            "display_url" : "pedropsi.github.io/unequal-length…",
            "indices" : [
              "153",
              "176"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "176"
      ],
      "favorite_count" : "7",
      "id_str" : "1432721013205258248",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1432721013205258248",
      "possibly_sensitive" : false,
      "created_at" : "Tue Aug 31 15:04:42 +0000 2021",
      "favorited" : false,
      "full_text" : "Here's an Unequal Length Maze puzzle I made. (It's logically solvable, with no bifurcation needed.)\n\nGenre by Erich Friedman, and interface by Pedropsi\n\nhttps://t.co/o6pimFovtk",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1429868524651036672"
          ],
          "editableUntil" : "2021-08-23T18:39:56.606Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "65"
      ],
      "favorite_count" : "2",
      "id_str" : "1429868524651036672",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1429868524651036672",
      "created_at" : "Mon Aug 23 18:09:56 +0000 2021",
      "favorited" : false,
      "full_text" : "The Spanish \"soso\" can be a rough synonym of the English \"so-so\"!",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1423110808154906628"
          ],
          "editableUntil" : "2021-08-05T03:07:11.441Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1423110808154906628/photo/1",
            "indices" : [
              "0",
              "23"
            ],
            "url" : "https://t.co/xEPXQ65o1V",
            "media_url" : "http://pbs.twimg.com/media/E7_nmB_WYAg8iX0.png",
            "id_str" : "1423110647827554312",
            "id" : "1423110647827554312",
            "media_url_https" : "https://pbs.twimg.com/media/E7_nmB_WYAg8iX0.png",
            "sizes" : {
              "medium" : {
                "w" : "378",
                "h" : "441",
                "resize" : "fit"
              },
              "large" : {
                "w" : "378",
                "h" : "441",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "378",
                "h" : "441",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/xEPXQ65o1V"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "34",
      "id_str" : "1423110808154906628",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1423110808154906628",
      "possibly_sensitive" : false,
      "created_at" : "Thu Aug 05 02:37:11 +0000 2021",
      "favorited" : false,
      "full_text" : "https://t.co/xEPXQ65o1V",
      "lang" : "zxx",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1423110808154906628/photo/1",
            "indices" : [
              "0",
              "23"
            ],
            "url" : "https://t.co/xEPXQ65o1V",
            "media_url" : "http://pbs.twimg.com/media/E7_nmB_WYAg8iX0.png",
            "id_str" : "1423110647827554312",
            "id" : "1423110647827554312",
            "media_url_https" : "https://pbs.twimg.com/media/E7_nmB_WYAg8iX0.png",
            "sizes" : {
              "medium" : {
                "w" : "378",
                "h" : "441",
                "resize" : "fit"
              },
              "large" : {
                "w" : "378",
                "h" : "441",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "378",
                "h" : "441",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/xEPXQ65o1V"
          },
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1423110808154906628/photo/1",
            "indices" : [
              "0",
              "23"
            ],
            "url" : "https://t.co/xEPXQ65o1V",
            "media_url" : "http://pbs.twimg.com/media/E7_noSoWUAkJacu.png",
            "id_str" : "1423110686654222345",
            "id" : "1423110686654222345",
            "media_url_https" : "https://pbs.twimg.com/media/E7_noSoWUAkJacu.png",
            "sizes" : {
              "small" : {
                "w" : "368",
                "h" : "435",
                "resize" : "fit"
              },
              "large" : {
                "w" : "368",
                "h" : "435",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "368",
                "h" : "435",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/xEPXQ65o1V"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1420811099415351302"
          ],
          "editableUntil" : "2021-07-29T18:48:58.151Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "100"
      ],
      "favorite_count" : "38",
      "id_str" : "1420811099415351302",
      "truncated" : false,
      "retweet_count" : "6",
      "id" : "1420811099415351302",
      "created_at" : "Thu Jul 29 18:18:58 +0000 2021",
      "favorited" : false,
      "full_text" : "ONE, TWO, THREE,\nUNO, DOS, TRES, and\nUN, DEUX, TROIS \nall have the appropriate amount of consonants.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1414672762497650693"
          ],
          "editableUntil" : "2021-07-12T20:17:24.585Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "187"
      ],
      "favorite_count" : "19",
      "id_str" : "1414672762497650693",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1414672762497650693",
      "created_at" : "Mon Jul 12 19:47:24 +0000 2021",
      "favorited" : false,
      "full_text" : "If you say negative things about someone else, that's roasting.\nIf you say positive things about someone else, that's toasting.\nIf you say positive things about yourself, that's boasting.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1413222109220941835"
          ],
          "editableUntil" : "2021-07-08T20:13:01.892Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "70"
      ],
      "favorite_count" : "15",
      "id_str" : "1413222109220941835",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1413222109220941835",
      "created_at" : "Thu Jul 08 19:43:01 +0000 2021",
      "favorited" : false,
      "full_text" : "Undertones are subtle implicit messages, but overtones are overt ones.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1410967778891292672"
          ],
          "editableUntil" : "2021-07-02T14:55:07.658Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1410967778891292672/photo/1",
            "indices" : [
              "29",
              "52"
            ],
            "url" : "https://t.co/QNI8KdtguC",
            "media_url" : "http://pbs.twimg.com/media/E5TDd6JXIAQJIqj.png",
            "id_str" : "1410967501865951236",
            "id" : "1410967501865951236",
            "media_url_https" : "https://pbs.twimg.com/media/E5TDd6JXIAQJIqj.png",
            "sizes" : {
              "medium" : {
                "w" : "894",
                "h" : "648",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "493",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "894",
                "h" : "648",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/QNI8KdtguC"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "52"
      ],
      "favorite_count" : "17",
      "id_str" : "1410967778891292672",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1410967778891292672",
      "possibly_sensitive" : false,
      "created_at" : "Fri Jul 02 14:25:07 +0000 2021",
      "favorited" : false,
      "full_text" : "Here's a Statue Park puzzle. https://t.co/QNI8KdtguC",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1410967778891292672/photo/1",
            "indices" : [
              "29",
              "52"
            ],
            "url" : "https://t.co/QNI8KdtguC",
            "media_url" : "http://pbs.twimg.com/media/E5TDd6JXIAQJIqj.png",
            "id_str" : "1410967501865951236",
            "id" : "1410967501865951236",
            "media_url_https" : "https://pbs.twimg.com/media/E5TDd6JXIAQJIqj.png",
            "sizes" : {
              "medium" : {
                "w" : "894",
                "h" : "648",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "493",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "894",
                "h" : "648",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/QNI8KdtguC"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1406620127135682561"
          ],
          "editableUntil" : "2021-06-20T14:59:06.704Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "90"
      ],
      "favorite_count" : "9",
      "id_str" : "1406620127135682561",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1406620127135682561",
      "created_at" : "Sun Jun 20 14:29:06 +0000 2021",
      "favorited" : false,
      "full_text" : "It seems backwards that AD (Anno Domini) is in Latin and BC (Before Christ) is in English.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1401719057129353218"
          ],
          "editableUntil" : "2021-06-07T02:24:00.557Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "80"
      ],
      "favorite_count" : "21",
      "id_str" : "1401719057129353218",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1401719057129353218",
      "created_at" : "Mon Jun 07 01:54:00 +0000 2021",
      "favorited" : false,
      "full_text" : "They're called storm drains because when d' rain drops come down, they stor' 'm.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1401150578085052416"
          ],
          "editableUntil" : "2021-06-05T12:45:04.591Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "91"
      ],
      "favorite_count" : "35",
      "id_str" : "1401150578085052416",
      "truncated" : false,
      "retweet_count" : "6",
      "id" : "1401150578085052416",
      "created_at" : "Sat Jun 05 12:15:04 +0000 2021",
      "favorited" : false,
      "full_text" : "BREV, the root morpheme of BREVITY, is the reverse of VERB, the root morpheme of VERBOSITY.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1399825771351396352"
          ],
          "editableUntil" : "2021-06-01T21:00:46.052Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "47"
      ],
      "favorite_count" : "17",
      "id_str" : "1399825771351396352",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1399825771351396352",
      "created_at" : "Tue Jun 01 20:30:46 +0000 2021",
      "favorited" : false,
      "full_text" : "A TRIG RELATION\nis an anagram of\nTRIANGLE RATIO",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1399442715184599041"
          ],
          "editableUntil" : "2021-05-31T19:38:38.345Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "195"
      ],
      "favorite_count" : "21",
      "id_str" : "1399442715184599041",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1399442715184599041",
      "created_at" : "Mon May 31 19:08:38 +0000 2021",
      "favorited" : false,
      "full_text" : "The Spanish word for \"mask\", which is \"máscara\", can be split into \"más\" and \"cara\", which are the Spanish words for \"more\" and \"face\".\n(This appears to be a complete coincidence etymologically!)",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1391830609945894914"
          ],
          "editableUntil" : "2021-05-10T19:30:51.030Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "194"
      ],
      "favorite_count" : "8",
      "id_str" : "1391830609945894914",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1391830609945894914",
      "created_at" : "Mon May 10 19:00:51 +0000 2021",
      "favorited" : false,
      "full_text" : "I said \n\"If you detail a car, that means you remove from it, but if you detail a painting, that means you add to it.\"\nand my dad replied\n\"But if you detail a dog, that means you remove from it.\"",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1391800349015617542"
          ],
          "editableUntil" : "2021-05-10T17:30:36.262Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/rjNpIUA3YO",
            "expanded_url" : "https://ldjam.com/events/ludum-dare/48/ludophile",
            "display_url" : "ldjam.com/events/ludum-d…",
            "indices" : [
              "40",
              "63"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "63"
      ],
      "favorite_count" : "4",
      "id_str" : "1391800349015617542",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1391800349015617542",
      "possibly_sensitive" : false,
      "created_at" : "Mon May 10 17:00:36 +0000 2021",
      "favorited" : false,
      "full_text" : "For Ludum Dare 48, I made... something. https://t.co/rjNpIUA3YO",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1387841488034336769"
          ],
          "editableUntil" : "2021-04-29T19:19:30.252Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "53"
      ],
      "favorite_count" : "18",
      "id_str" : "1387841488034336769",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1387841488034336769",
      "created_at" : "Thu Apr 29 18:49:30 +0000 2021",
      "favorited" : false,
      "full_text" : "NONPARTISANIST\nis an anagram of\nANTI \"PROS 'N' ANTIS\"",
      "lang" : "tl"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1382043848952709125"
          ],
          "editableUntil" : "2021-04-13T19:21:45.380Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/FciqrJUMLI",
            "expanded_url" : "https://www.puzzlescript.net/play.html?p=2fe3172d2b9fe684977d184f1b6226d5",
            "display_url" : "puzzlescript.net/play.html?p=2f…",
            "indices" : [
              "33",
              "56"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "56"
      ],
      "favorite_count" : "86",
      "id_str" : "1382043848952709125",
      "truncated" : false,
      "retweet_count" : "17",
      "id" : "1382043848952709125",
      "possibly_sensitive" : false,
      "created_at" : "Tue Apr 13 18:51:45 +0000 2021",
      "favorited" : false,
      "full_text" : "Here's my new game \"Pushing It\":\nhttps://t.co/FciqrJUMLI",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1381726151199051781"
          ],
          "editableUntil" : "2021-04-12T22:19:20.333Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1381726151199051781/photo/1",
            "indices" : [
              "86",
              "109"
            ],
            "url" : "https://t.co/Ow1ZuRBveI",
            "media_url" : "http://pbs.twimg.com/media/Eyzge7nXIAAvRXd.jpg",
            "id_str" : "1381726007699382272",
            "id" : "1381726007699382272",
            "media_url_https" : "https://pbs.twimg.com/media/Eyzge7nXIAAvRXd.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1070",
                "h" : "382",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "243",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1070",
                "h" : "382",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/Ow1ZuRBveI"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "109"
      ],
      "favorite_count" : "8",
      "id_str" : "1381726151199051781",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1381726151199051781",
      "possibly_sensitive" : false,
      "created_at" : "Mon Apr 12 21:49:20 +0000 2021",
      "favorited" : false,
      "full_text" : "Speaking of Google and orders of magnitude, something seems off about this formula... https://t.co/Ow1ZuRBveI",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1381726151199051781/photo/1",
            "indices" : [
              "86",
              "109"
            ],
            "url" : "https://t.co/Ow1ZuRBveI",
            "media_url" : "http://pbs.twimg.com/media/Eyzge7nXIAAvRXd.jpg",
            "id_str" : "1381726007699382272",
            "id" : "1381726007699382272",
            "media_url_https" : "https://pbs.twimg.com/media/Eyzge7nXIAAvRXd.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1070",
                "h" : "382",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "243",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1070",
                "h" : "382",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/Ow1ZuRBveI"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1381725722197307394"
          ],
          "editableUntil" : "2021-04-12T22:17:38.051Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "106"
      ],
      "favorite_count" : "5",
      "id_str" : "1381725722197307394",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1381725722197307394",
      "created_at" : "Mon Apr 12 21:47:38 +0000 2021",
      "favorited" : false,
      "full_text" : "Not sure how Baidu manages to compete with Google considering the latter is 98 orders of magnitude larger.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1371168022996660231"
          ],
          "editableUntil" : "2021-03-14T19:05:06.409Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/vFoas9N0gw",
            "expanded_url" : "https://jacoblance.wordpress.com/2021/03/14/p-i-hunt-7/",
            "display_url" : "jacoblance.wordpress.com/2021/03/14/p-i…",
            "indices" : [
              "26",
              "49"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "16",
      "id_str" : "1371168022996660231",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1371168022996660231",
      "possibly_sensitive" : false,
      "created_at" : "Sun Mar 14 18:35:06 +0000 2021",
      "favorited" : false,
      "full_text" : "Happy Pi Day!\nP.I.HUNT 7:\nhttps://t.co/vFoas9N0gw",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1356636067122806784"
          ],
          "editableUntil" : "2021-02-02T16:40:18.138Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "68"
      ],
      "favorite_count" : "19",
      "id_str" : "1356636067122806784",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1356636067122806784",
      "created_at" : "Tue Feb 02 16:10:18 +0000 2021",
      "favorited" : false,
      "full_text" : "Finances are a lot like tic-tac-toe: One either has excess, or owes.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1354467963714342920"
          ],
          "editableUntil" : "2021-01-27T17:05:02.004Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "205"
      ],
      "favorite_count" : "25",
      "id_str" : "1354467963714342920",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1354467963714342920",
      "created_at" : "Wed Jan 27 16:35:02 +0000 2021",
      "favorited" : false,
      "full_text" : "Many superheroes wear masks to conceal their identities.\n\nHowever, the Teenage Mutant Ninja Turtles have masks for the exact opposite reason! Without their masks it would be *harder* to identify who's who.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "693311651450376192"
          ],
          "editableUntil" : "2016-01-30T06:25:53.470Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "693295187313954816",
      "id_str" : "693311651450376192",
      "in_reply_to_user_id" : "144119186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "693311651450376192",
      "in_reply_to_status_id" : "693295187313954816",
      "created_at" : "Sat Jan 30 05:55:53 +0000 2016",
      "favorited" : false,
      "full_text" : "@chaotic_iak + and - are translations. * and / are rotations and dilations. It's impossible to make reflection, which is what conjugate is.",
      "lang" : "en",
      "in_reply_to_screen_name" : "chaotic_iak",
      "in_reply_to_user_id_str" : "144119186"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "692571520934264832"
          ],
          "editableUntil" : "2016-01-28T05:24:52.604Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Tom Yue",
            "screen_name" : "yuethomas",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "15171866",
            "id" : "15171866"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "692571088203681792",
      "id_str" : "692571520934264832",
      "in_reply_to_user_id" : "2444552670",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "692571520934264832",
      "in_reply_to_status_id" : "692571088203681792",
      "created_at" : "Thu Jan 28 04:54:52 +0000 2016",
      "favorited" : false,
      "full_text" : "@yuethomas IDing 19th century women? Boxes with letters? Cursed phone numbers? I don't remember these, but seems like they could be puzzles.",
      "lang" : "en",
      "in_reply_to_screen_name" : "Jack_L_Lance",
      "in_reply_to_user_id_str" : "2444552670"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "692571088203681792"
          ],
          "editableUntil" : "2016-01-28T05:23:09.433Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "mysteryhunt",
            "indices" : [
              "60",
              "72"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Tom Yue",
            "screen_name" : "yuethomas",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "15171866",
            "id" : "15171866"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "96"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "692527768429527040",
      "id_str" : "692571088203681792",
      "in_reply_to_user_id" : "15171866",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "692571088203681792",
      "in_reply_to_status_id" : "692527768429527040",
      "created_at" : "Thu Jan 28 04:53:09 +0000 2016",
      "favorited" : false,
      "full_text" : "@yuethomas I just pretend they're all obscure references to #mysteryhunt puzzles I didn't solve.",
      "lang" : "en",
      "in_reply_to_screen_name" : "yuethomas",
      "in_reply_to_user_id_str" : "15171866"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "692535545445093376"
          ],
          "editableUntil" : "2016-01-28T03:01:55.379Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "54"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "692534913611010049",
      "id_str" : "692535545445093376",
      "in_reply_to_user_id" : "144119186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "692535545445093376",
      "in_reply_to_status_id" : "692534913611010049",
      "created_at" : "Thu Jan 28 02:31:55 +0000 2016",
      "favorited" : false,
      "full_text" : "@chaotic_iak \nYeah, I know the pronunciation is wrong.",
      "lang" : "en",
      "in_reply_to_screen_name" : "chaotic_iak",
      "in_reply_to_user_id_str" : "144119186"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "692534913812271104"
          ],
          "editableUntil" : "2016-01-28T02:59:24.786Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "136"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "692533472875929613",
      "id_str" : "692534913812271104",
      "in_reply_to_user_id" : "2444552670",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "692534913812271104",
      "in_reply_to_status_id" : "692533472875929613",
      "created_at" : "Thu Jan 28 02:29:24 +0000 2016",
      "favorited" : false,
      "full_text" : "@edderiofer Google announced today an AI for go named \"Alphago\". It has beaten masters, and is going to play grandmaster Lee Sedol soon.",
      "lang" : "en",
      "in_reply_to_screen_name" : "Jack_L_Lance",
      "in_reply_to_user_id_str" : "2444552670"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "692534751136202755"
          ],
          "editableUntil" : "2016-01-28T02:58:46.001Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Jack Lance",
            "screen_name" : "Jack_L_Lance",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "2444552670",
            "id" : "2444552670"
          },
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "14",
              "26"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/tFxVm1dLEQ",
            "expanded_url" : "https://googleblog.blogspot.com/2016/01/alphago-machine-learning-game-go.html",
            "display_url" : "googleblog.blogspot.com/2016/01/alphag…",
            "indices" : [
              "27",
              "50"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "116"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "692534593057071104",
      "id_str" : "692534751136202755",
      "in_reply_to_user_id" : "2444552670",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "692534751136202755",
      "in_reply_to_status_id" : "692534593057071104",
      "possibly_sensitive" : false,
      "created_at" : "Thu Jan 28 02:28:46 +0000 2016",
      "favorited" : false,
      "full_text" : "@Jack_L_Lance @chaotic_iak https://t.co/tFxVm1dLEQ\n\n(Sorry, this pun was rather involved. I still like it though...)",
      "lang" : "en",
      "in_reply_to_screen_name" : "Jack_L_Lance",
      "in_reply_to_user_id_str" : "2444552670"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "692534593057071104"
          ],
          "editableUntil" : "2016-01-28T02:58:08.312Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "138"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "692533987286388736",
      "id_str" : "692534593057071104",
      "in_reply_to_user_id" : "144119186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "692534593057071104",
      "in_reply_to_status_id" : "692533987286388736",
      "created_at" : "Thu Jan 28 02:28:08 +0000 2016",
      "favorited" : false,
      "full_text" : "@chaotic_iak \nGoogle announced today an AI for go named \"Alphago\". It has beaten masters, and is going to play grandmaster Lee Sedol soon.",
      "lang" : "en",
      "in_reply_to_screen_name" : "chaotic_iak",
      "in_reply_to_user_id_str" : "144119186"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "692533629206073346"
          ],
          "editableUntil" : "2016-01-28T02:54:18.512Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "51"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "692532581808640001",
      "id_str" : "692533629206073346",
      "in_reply_to_user_id" : "144119186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "692533629206073346",
      "in_reply_to_status_id" : "692532581808640001",
      "created_at" : "Thu Jan 28 02:24:18 +0000 2016",
      "favorited" : false,
      "full_text" : "@chaotic_iak \n\nAigo = AI + Go was the intended pun.",
      "lang" : "en",
      "in_reply_to_screen_name" : "chaotic_iak",
      "in_reply_to_user_id_str" : "144119186"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "692533472875929613"
          ],
          "editableUntil" : "2016-01-28T02:53:41.240Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "28"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "692523464662605828",
      "id_str" : "692533472875929613",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "692533472875929613",
      "in_reply_to_status_id" : "692523464662605828",
      "created_at" : "Thu Jan 28 02:23:41 +0000 2016",
      "favorited" : false,
      "full_text" : "@edderiofer \n\nAigo = AI + Go",
      "lang" : "eu",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "692512363338186752"
          ],
          "editableUntil" : "2016-01-28T01:29:48.334Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "68"
      ],
      "favorite_count" : "0",
      "id_str" : "692512363338186752",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "692512363338186752",
      "created_at" : "Thu Jan 28 00:59:48 +0000 2016",
      "favorited" : false,
      "full_text" : "Lee Sedol is Korean. If he loses to Alphago, I bet he'll say \"aigo!\"",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "690377725949927424"
          ],
          "editableUntil" : "2016-01-22T04:07:31.121Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "106"
      ],
      "favorite_count" : "1",
      "id_str" : "690377725949927424",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "690377725949927424",
      "created_at" : "Fri Jan 22 03:37:31 +0000 2016",
      "favorited" : false,
      "full_text" : "I just realized the 3DS seems like it was dedicated to a character found in one of its games, King Dedede.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "690281324679135233"
          ],
          "editableUntil" : "2016-01-21T21:44:27.267Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "60"
      ],
      "favorite_count" : "0",
      "id_str" : "690281324679135233",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "690281324679135233",
      "created_at" : "Thu Jan 21 21:14:27 +0000 2016",
      "favorited" : false,
      "full_text" : "A radon detector is a tocsin which talks in case of a toxin.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "689300192802287617"
          ],
          "editableUntil" : "2016-01-19T04:45:47.199Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "58"
      ],
      "favorite_count" : "1",
      "id_str" : "689300192802287617",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "689300192802287617",
      "created_at" : "Tue Jan 19 04:15:47 +0000 2016",
      "favorited" : false,
      "full_text" : "People who gamble there a lot should call it \"Loss Vegas\".",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "689300121880756224"
          ],
          "editableUntil" : "2016-01-19T04:45:30.290Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "mysteryhunt",
            "indices" : [
              "3",
              "15"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "689300121880756224",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "689300121880756224",
      "created_at" : "Tue Jan 19 04:15:30 +0000 2016",
      "favorited" : false,
      "full_text" : "My #mysteryhunt souvenir this year, a \"Top Dog\" coin and Google cardboard, is much cooler than last year, a piece of string with morse code.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "685975898256982016"
          ],
          "editableUntil" : "2016-01-10T00:36:13.617Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "105"
      ],
      "favorite_count" : "0",
      "id_str" : "685975898256982016",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "685975898256982016",
      "created_at" : "Sun Jan 10 00:06:13 +0000 2016",
      "favorited" : false,
      "full_text" : "A machine which plays different music depending on what number the user chooses would be a rad io system.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "685670546642698241"
          ],
          "editableUntil" : "2016-01-09T04:22:52.119Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "64"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "685669988120698880",
      "id_str" : "685670546642698241",
      "in_reply_to_user_id" : "144119186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "685670546642698241",
      "in_reply_to_status_id" : "685669988120698880",
      "created_at" : "Sat Jan 09 03:52:52 +0000 2016",
      "favorited" : false,
      "full_text" : "@chaotic_iak I assume by \"chat\" you mean the French word \"chat\".",
      "lang" : "en",
      "in_reply_to_screen_name" : "chaotic_iak",
      "in_reply_to_user_id_str" : "144119186"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "684840184727363586"
          ],
          "editableUntil" : "2016-01-06T21:23:18.411Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "137"
      ],
      "favorite_count" : "0",
      "id_str" : "684840184727363586",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "684840184727363586",
      "created_at" : "Wed Jan 06 20:53:18 +0000 2016",
      "favorited" : false,
      "full_text" : "(Cont.) I don't know if I was able to convey what I meant in 140 chars, so here's the answer ROT13ed:\nYHPNEVB\nYHPN(E-&gt;F)\n(Y-&gt;Z)NEVB",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "684839829901815808"
          ],
          "editableUntil" : "2016-01-06T21:21:53.814Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "684839829901815808",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "684839829901815808",
      "created_at" : "Wed Jan 06 20:51:53 +0000 2016",
      "favorited" : false,
      "full_text" : "A Super Smash Bros character can have its first or last trigram changed to the trigram's beginning shifted by one to make another character.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "683768621856874496"
          ],
          "editableUntil" : "2016-01-03T22:25:17.914Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/FqHGFYlciQ",
            "expanded_url" : "https://i.gyazo.com/d8db1499b76c2530b43fcf3749551d80.png",
            "display_url" : "i.gyazo.com/d8db1499b76c25…",
            "indices" : [
              "55",
              "78"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "132"
      ],
      "favorite_count" : "0",
      "id_str" : "683768621856874496",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "683768621856874496",
      "possibly_sensitive" : false,
      "created_at" : "Sun Jan 03 21:55:17 +0000 2016",
      "favorited" : false,
      "full_text" : "Guess what type of puzzle this is, and then solve it.\n\nhttps://t.co/FqHGFYlciQ\n\n(Note: black cell means shaded, dot means unshaded.)",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "682390272307806209"
          ],
          "editableUntil" : "2015-12-31T03:08:13.773Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/6UK0dduAFW",
            "expanded_url" : "https://i.gyazo.com/8a8401314cca90811fe8a25b578acb7f.png",
            "display_url" : "i.gyazo.com/8a8401314cca90…",
            "indices" : [
              "49",
              "72"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "72"
      ],
      "favorite_count" : "0",
      "id_str" : "682390272307806209",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "682390272307806209",
      "possibly_sensitive" : false,
      "created_at" : "Thu Dec 31 02:38:13 +0000 2015",
      "favorited" : false,
      "full_text" : "(cont.)\nEveeeen cloooooser.(99.928% covered -_-)\nhttps://t.co/6UK0dduAFW",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "682311981626425344"
          ],
          "editableUntil" : "2015-12-30T21:57:07.820Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/zDA6H7JG7F",
            "expanded_url" : "https://gyazo.com/949dc7b167321979d9866a7b3fe4c532",
            "display_url" : "gyazo.com/949dc7b1673219…",
            "indices" : [
              "26",
              "49"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "0",
      "id_str" : "682311981626425344",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "682311981626425344",
      "possibly_sensitive" : false,
      "created_at" : "Wed Dec 30 21:27:07 +0000 2015",
      "favorited" : false,
      "full_text" : "(cont.)\nSoooooo cloooose:\nhttps://t.co/zDA6H7JG7F",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "682303748740386816"
          ],
          "editableUntil" : "2015-12-30T21:24:24.947Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/JKvrcragWo",
            "expanded_url" : "https://i.gyazo.com/827e63869c8a8eb489c67a4d97aa8740.png",
            "display_url" : "i.gyazo.com/827e63869c8a8e…",
            "indices" : [
              "117",
              "140"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "682303748740386816",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "682303748740386816",
      "possibly_sensitive" : false,
      "created_at" : "Wed Dec 30 20:54:24 +0000 2015",
      "favorited" : false,
      "full_text" : "Can you 3-color a 1-ε by 1-ε square so points 1 away aren't same color? I always get some left but I can't prove it. https://t.co/JKvrcragWo",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "677903610844463104"
          ],
          "editableUntil" : "2015-12-18T17:59:50.322Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "131"
      ],
      "favorite_count" : "0",
      "id_str" : "677903610844463104",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "677903610844463104",
      "created_at" : "Fri Dec 18 17:29:50 +0000 2015",
      "favorited" : false,
      "full_text" : "If I can cheat with 'X' a little, then:\n\nYou'll never forget pentominos' letters upon x-amining these very zealous words' initials.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "677881055446044674"
          ],
          "editableUntil" : "2015-12-18T16:30:12.696Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "131"
      ],
      "favorite_count" : "0",
      "id_str" : "677881055446044674",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "677881055446044674",
      "created_at" : "Fri Dec 18 16:00:12 +0000 2015",
      "favorited" : false,
      "full_text" : "Yo, initial letters unveil zones where two-d volume x = five, namely pentominos. This is similar, only littler. I tried. Dang. Meh.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "674787648171548672"
          ],
          "editableUntil" : "2015-12-10T03:38:06.929Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ben Smith",
            "screen_name" : "BenMSmith",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "36894019",
            "id" : "36894019"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "113"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "674787348471746561",
      "id_str" : "674787648171548672",
      "in_reply_to_user_id" : "2444552670",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "674787648171548672",
      "in_reply_to_status_id" : "674787348471746561",
      "created_at" : "Thu Dec 10 03:08:06 +0000 2015",
      "favorited" : false,
      "full_text" : "@BenMSmith Also, out of curiosity, is there a place to see all the past Palindrome names, and nametags, gate-man?",
      "lang" : "en",
      "in_reply_to_screen_name" : "Jack_L_Lance",
      "in_reply_to_user_id_str" : "2444552670"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "674787348471746561"
          ],
          "editableUntil" : "2015-12-10T03:36:55.475Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ben Smith",
            "screen_name" : "BenMSmith",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "36894019",
            "id" : "36894019"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "66"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "674724928801869825",
      "id_str" : "674787348471746561",
      "in_reply_to_user_id" : "36894019",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "674787348471746561",
      "in_reply_to_status_id" : "674724928801869825",
      "created_at" : "Thu Dec 10 03:06:55 +0000 2015",
      "favorited" : false,
      "full_text" : "@BenMSmith SLEEPY PEELS? FACE DECAF? TOO HOT TO HOOT? YO JAVA JOY?",
      "lang" : "en",
      "in_reply_to_screen_name" : "BenMSmith",
      "in_reply_to_user_id_str" : "36894019"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "673610611834523648"
          ],
          "editableUntil" : "2015-12-06T21:40:59.598Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "138"
      ],
      "favorite_count" : "0",
      "id_str" : "673610611834523648",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "673610611834523648",
      "created_at" : "Sun Dec 06 21:10:59 +0000 2015",
      "favorited" : false,
      "full_text" : "(cont.) Unless \"that\" refers to talking about which topic you're talking about, then it'd be true, but I doubt that comes up too often. :P",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "673610087391346692"
          ],
          "editableUntil" : "2015-12-06T21:38:54.561Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "138"
      ],
      "favorite_count" : "0",
      "id_str" : "673610087391346692",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "673610087391346692",
      "created_at" : "Sun Dec 06 21:08:54 +0000 2015",
      "favorited" : false,
      "full_text" : "(cont.) Although you could say it's always false, as at that point you're talking about what you're talking about, and not \"that\" anymore.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "673607036190330880"
          ],
          "editableUntil" : "2015-12-06T21:26:47.098Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "71"
      ],
      "favorite_count" : "0",
      "id_str" : "673607036190330880",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "673607036190330880",
      "created_at" : "Sun Dec 06 20:56:47 +0000 2015",
      "favorited" : false,
      "full_text" : "The phrase \"That's what I'm talking about!\" is very oddly tautological.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "671892097461547008"
          ],
          "editableUntil" : "2015-12-02T03:52:13.843Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "137"
      ],
      "favorite_count" : "0",
      "id_str" : "671892097461547008",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "671892097461547008",
      "created_at" : "Wed Dec 02 03:22:13 +0000 2015",
      "favorited" : false,
      "full_text" : "Although the words \"humans\" and \"people\" mean the same thing in most scenarios, swapping them tends to get you some *really* weird looks.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "669349661195407360"
          ],
          "editableUntil" : "2015-11-25T03:29:29.801Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "96"
      ],
      "favorite_count" : "0",
      "id_str" : "669349661195407360",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "669349661195407360",
      "created_at" : "Wed Nov 25 02:59:29 +0000 2015",
      "favorited" : false,
      "full_text" : "I can be an introvert or an extrovert. It depends, per the situation. So I guess I'm a per-vert.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "668905176728805381"
          ],
          "editableUntil" : "2015-11-23T22:03:16.446Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "58"
      ],
      "favorite_count" : "0",
      "id_str" : "668905176728805381",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "668905176728805381",
      "created_at" : "Mon Nov 23 21:33:16 +0000 2015",
      "favorited" : false,
      "full_text" : "[Thanks] for nothing.\nNothing's forever.\nEver-for[giving].",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "666716352162471937"
          ],
          "editableUntil" : "2015-11-17T21:05:40.003Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "97"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "666578779590889473",
      "id_str" : "666716352162471937",
      "in_reply_to_user_id" : "144119186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "666716352162471937",
      "in_reply_to_status_id" : "666578779590889473",
      "created_at" : "Tue Nov 17 20:35:40 +0000 2015",
      "favorited" : false,
      "full_text" : "@chaotic_iak A for Slitherlink. B for Fillomino. Considering it's a puzzle made by you, I vote B.",
      "lang" : "en",
      "in_reply_to_screen_name" : "chaotic_iak",
      "in_reply_to_user_id_str" : "144119186"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "664519092016013312"
          ],
          "editableUntil" : "2015-11-11T19:34:32.361Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "67"
      ],
      "favorite_count" : "1",
      "id_str" : "664519092016013312",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "664519092016013312",
      "created_at" : "Wed Nov 11 19:04:32 +0000 2015",
      "favorited" : false,
      "full_text" : "Every letter besides some four exist within this quite good puzzle.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "663791395585589249"
          ],
          "editableUntil" : "2015-11-09T19:22:56.012Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "P&A Puzzle Magazine",
            "screen_name" : "pandamagazine",
            "indices" : [
              "1",
              "15"
            ],
            "id_str" : "69607902",
            "id" : "69607902"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "122"
      ],
      "favorite_count" : "1",
      "id_str" : "663791395585589249",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "663791395585589249",
      "created_at" : "Mon Nov 09 18:52:56 +0000 2015",
      "favorited" : false,
      "full_text" : ".@pandamagazine \nI can't always get the answers to the puzzles. \nPerhaps you should consider renaming it Pandora magazine?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "659800073488961537"
          ],
          "editableUntil" : "2015-10-29T19:02:50.669Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Jack Lance",
            "screen_name" : "Jack_L_Lance",
            "indices" : [
              "1",
              "14"
            ],
            "id_str" : "2444552670",
            "id" : "2444552670"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "64"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "558438386957307906",
      "id_str" : "659800073488961537",
      "in_reply_to_user_id" : "2444552670",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "659800073488961537",
      "in_reply_to_status_id" : "558438386957307906",
      "created_at" : "Thu Oct 29 18:32:50 +0000 2015",
      "favorited" : false,
      "full_text" : ".@Jack_L_Lance If anyone didn't get this one, I can ex-pound it.",
      "lang" : "en",
      "in_reply_to_screen_name" : "Jack_L_Lance",
      "in_reply_to_user_id_str" : "2444552670"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "650796557730643969"
          ],
          "editableUntil" : "2015-10-04T22:46:05.235Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "anagramagamename",
            "indices" : [
              "79",
              "96"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "96"
      ],
      "favorite_count" : "0",
      "id_str" : "650796557730643969",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "650796557730643969",
      "created_at" : "Sun Oct 04 22:16:05 +0000 2015",
      "favorited" : false,
      "full_text" : "Any player that normally takes their time, when playing this game, ALTERS PACE #anagramagamename",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "650792759419379712"
          ],
          "editableUntil" : "2015-10-04T22:30:59.647Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "anagramagamename",
            "indices" : [
              "100",
              "117"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "117"
      ],
      "favorite_count" : "1",
      "id_str" : "650792759419379712",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "650792759419379712",
      "created_at" : "Sun Oct 04 22:00:59 +0000 2015",
      "favorited" : false,
      "full_text" : "The amount of cities and settlements I have around lumber producing hexes is the LANCE FOREST STAT.\n#anagramagamename",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "649027089652412416"
          ],
          "editableUntil" : "2015-09-30T01:34:51.170Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "William Chyr",
            "screen_name" : "WilliamChyr",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "191977580",
            "id" : "191977580"
          },
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "13",
              "24"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "100"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "649004167772663808",
      "id_str" : "649027089652412416",
      "in_reply_to_user_id" : "191977580",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "649027089652412416",
      "in_reply_to_status_id" : "649004167772663808",
      "created_at" : "Wed Sep 30 01:04:51 +0000 2015",
      "favorited" : false,
      "full_text" : "@WilliamChyr @edderiofer Old versions of the game were too easy. They were interesting, YƎT TRIVIAL.",
      "lang" : "en",
      "in_reply_to_screen_name" : "WilliamChyr",
      "in_reply_to_user_id_str" : "191977580"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "648834083842334721"
          ],
          "editableUntil" : "2015-09-29T12:47:54.999Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/kShgDwdfEh",
            "expanded_url" : "http://www.puzzlescript.net/play.html?p=cb0c2b8c9a91c750aa37",
            "display_url" : "puzzlescript.net/play.html?p=cb…",
            "indices" : [
              "39",
              "61"
            ]
          },
          {
            "url" : "http://t.co/QY4IDEtvz3",
            "expanded_url" : "http://www.puzzlescript.net/play.html?p=3d5b33c58f446056be8b",
            "display_url" : "puzzlescript.net/play.html?p=3d…",
            "indices" : [
              "93",
              "115"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "115"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "648826110705164288",
      "id_str" : "648834083842334721",
      "in_reply_to_user_id" : "144119186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "648834083842334721",
      "in_reply_to_status_id" : "648826110705164288",
      "possibly_sensitive" : false,
      "created_at" : "Tue Sep 29 12:17:54 +0000 2015",
      "favorited" : false,
      "full_text" : "@chaotic_iak Here's the most recent 2: http://t.co/kShgDwdfEh\nand here's the full set of 22:\nhttp://t.co/QY4IDEtvz3",
      "lang" : "en",
      "in_reply_to_screen_name" : "chaotic_iak",
      "in_reply_to_user_id_str" : "144119186"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "648195195771748352"
          ],
          "editableUntil" : "2015-09-27T18:29:12.213Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "http://t.co/eoRnOp1lpV",
            "expanded_url" : "http://www.puzzlescript.net/play.html?p=e120eac07f65a43cc64d",
            "display_url" : "puzzlescript.net/play.html?p=e1…",
            "indices" : [
              "26",
              "48"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "136"
      ],
      "favorite_count" : "0",
      "id_str" : "648195195771748352",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "648195195771748352",
      "possibly_sensitive" : false,
      "created_at" : "Sun Sep 27 17:59:12 +0000 2015",
      "favorited" : false,
      "full_text" : "Another Snakeoban level!\n\nhttp://t.co/eoRnOp1lpV\n\nI like yesterday's more, but this one's more snake-y. They're both pretty hard. &gt;:D",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "647884983844139008"
          ],
          "editableUntil" : "2015-09-26T21:56:31.926Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "http://t.co/JTRrvoifkC",
            "expanded_url" : "http://www.puzzlescript.net/play.html?p=243487583be3ae606ca8",
            "display_url" : "puzzlescript.net/play.html?p=24…",
            "indices" : [
              "18",
              "40"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "0",
      "id_str" : "647884983844139008",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "647884983844139008",
      "possibly_sensitive" : false,
      "created_at" : "Sat Sep 26 21:26:31 +0000 2015",
      "favorited" : false,
      "full_text" : "Snakeoban level:\n\nhttp://t.co/JTRrvoifkC",
      "lang" : "no"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "646851880816148480"
          ],
          "editableUntil" : "2015-09-24T01:31:20.970Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/RaGuzNyu92",
            "expanded_url" : "https://i.gyazo.com/ac413d4e309f452dc04938ea5be1620b.png",
            "display_url" : "i.gyazo.com/ac413d4e309f45…",
            "indices" : [
              "56",
              "79"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "79"
      ],
      "favorite_count" : "0",
      "id_str" : "646851880816148480",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "646851880816148480",
      "possibly_sensitive" : false,
      "created_at" : "Thu Sep 24 01:01:20 +0000 2015",
      "favorited" : false,
      "full_text" : "WAIT WHAT.\n\nApparently I was fated to go to Rochester.\n\nhttps://t.co/RaGuzNyu92",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "645748244799180800"
          ],
          "editableUntil" : "2015-09-21T00:25:53.639Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "138"
      ],
      "favorite_count" : "0",
      "id_str" : "645748244799180800",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "645748244799180800",
      "created_at" : "Sun Sep 20 23:55:53 +0000 2015",
      "favorited" : false,
      "full_text" : "My friend set up the game wrong, so apparently it was Mr. Green with the rope while in Miss Scarlet... I thought this was a kid's game!?!?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "642141297181073412"
          ],
          "editableUntil" : "2015-09-11T01:33:10.313Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "119"
      ],
      "favorite_count" : "1",
      "id_str" : "642141297181073412",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "642141297181073412",
      "created_at" : "Fri Sep 11 01:03:10 +0000 2015",
      "favorited" : false,
      "full_text" : "Moving one unit at a time, and turning left at a vowel and right at a consonant, what is the phrase \"It's a plus sign\"?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "640896221687713792"
          ],
          "editableUntil" : "2015-09-07T15:05:41.183Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "84"
      ],
      "favorite_count" : "1",
      "id_str" : "640896221687713792",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "640896221687713792",
      "created_at" : "Mon Sep 07 14:35:41 +0000 2015",
      "favorited" : false,
      "full_text" : "LABOR U_ _ _ _. U _ _ _ _ J _ _ _.\n\nDAY C _ _ _. C _ _ _ F _ _ _. F _ _ _ L _ _ _ _.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "638783208604200960"
          ],
          "editableUntil" : "2015-09-01T19:09:19.606Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "http://t.co/CRoGzAvvsy",
            "expanded_url" : "http://www.puzzlescript.net/play.html?p=a0b8021cf42acc89306c",
            "display_url" : "puzzlescript.net/play.html?p=a0…",
            "indices" : [
              "104",
              "126"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "126"
      ],
      "favorite_count" : "0",
      "id_str" : "638783208604200960",
      "in_reply_to_user_id" : "75783213",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "638783208604200960",
      "possibly_sensitive" : false,
      "created_at" : "Tue Sep 01 18:39:19 +0000 2015",
      "favorited" : false,
      "full_text" : "@increpare Could I ask for Snakeoban to be in the Puzzlescript gallery please? (Or, if not, then why?)\n\nhttp://t.co/CRoGzAvvsy",
      "lang" : "en",
      "in_reply_to_user_id_str" : "75783213"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "638446772893941760"
          ],
          "editableUntil" : "2015-08-31T20:52:27.082Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "108"
      ],
      "favorite_count" : "0",
      "id_str" : "638446772893941760",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "638446772893941760",
      "created_at" : "Mon Aug 31 20:22:27 +0000 2015",
      "favorited" : false,
      "full_text" : "Highlight every single J, A, C, O and the Bs I used. Enclose in rectangle-y box. Observe the grid next then.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "636377886908358656"
          ],
          "editableUntil" : "2015-08-26T03:51:26.225Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "116"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "636361437187735556",
      "id_str" : "636377886908358656",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "636377886908358656",
      "in_reply_to_status_id" : "636361437187735556",
      "created_at" : "Wed Aug 26 03:21:26 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer \nWow! I made a pun in a conversation less than two hours ago about musical gangs and violins (violence).",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "634063962519179264"
          ],
          "editableUntil" : "2015-08-19T18:36:43.660Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "28"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "634054765509390336",
      "id_str" : "634063962519179264",
      "in_reply_to_user_id" : "144119186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "634063962519179264",
      "in_reply_to_status_id" : "634054765509390336",
      "created_at" : "Wed Aug 19 18:06:43 +0000 2015",
      "favorited" : false,
      "full_text" : "@chaotic_iak That's correct.",
      "lang" : "en",
      "in_reply_to_screen_name" : "chaotic_iak",
      "in_reply_to_user_id_str" : "144119186"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "634029714638815232"
          ],
          "editableUntil" : "2015-08-19T16:20:38.329Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/S9RIKbj9TZ",
            "expanded_url" : "https://i.gyazo.com/e8efe9c77aaa5cdd2f81484f404a67ae.png",
            "display_url" : "i.gyazo.com/e8efe9c77aaa5c…",
            "indices" : [
              "46",
              "69"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "69"
      ],
      "favorite_count" : "0",
      "id_str" : "634029714638815232",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "634029714638815232",
      "possibly_sensitive" : false,
      "created_at" : "Wed Aug 19 15:50:38 +0000 2015",
      "favorited" : false,
      "full_text" : "(2/2) \nHere is my opinion of making a Futari:\nhttps://t.co/S9RIKbj9TZ",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "634029485323632640"
          ],
          "editableUntil" : "2015-08-19T16:19:43.656Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "136"
      ],
      "favorite_count" : "0",
      "id_str" : "634029485323632640",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "634029485323632640",
      "created_at" : "Wed Aug 19 15:49:43 +0000 2015",
      "favorited" : false,
      "full_text" : "(1/2)\nFutari, a variant of Hitori by edderiofer, is like Hitori but allows for two unshaded copies of each letter in each row of column.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "633730370245160961"
          ],
          "editableUntil" : "2015-08-18T20:31:09.064Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "102"
      ],
      "favorite_count" : "1",
      "id_str" : "633730370245160961",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "633730370245160961",
      "created_at" : "Tue Aug 18 20:01:09 +0000 2015",
      "favorited" : false,
      "full_text" : "I haven't bold a strikethrough the course of this whole game! Compared to usual, I really underscored.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "632963062341980162"
          ],
          "editableUntil" : "2015-08-16T17:42:08.604Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "88"
      ],
      "favorite_count" : "0",
      "id_str" : "632963062341980162",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "632963062341980162",
      "created_at" : "Sun Aug 16 17:12:08 +0000 2015",
      "favorited" : false,
      "full_text" : "I just saw a \"Sports Clips\" store for haircuts.\n\nI wonder if they specialize in curling?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "628929249857138688"
          ],
          "editableUntil" : "2015-08-05T14:33:12.763Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "FitzgeraldTeller",
            "screen_name" : "Mathgrant",
            "indices" : [
              "1",
              "11"
            ],
            "id_str" : "1532161137927766016",
            "id" : "1532161137927766016"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/pZ2n2o7j6E",
            "expanded_url" : "http://i.gyazo.com/e6eba7869e186c3254cdb68ae1c10ecd.png",
            "display_url" : "i.gyazo.com/e6eba7869e186c…",
            "indices" : [
              "61",
              "83"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "83"
      ],
      "favorite_count" : "0",
      "id_str" : "628929249857138688",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "628929249857138688",
      "possibly_sensitive" : false,
      "created_at" : "Wed Aug 05 14:03:12 +0000 2015",
      "favorited" : false,
      "full_text" : ".@mathgrant \n\nNow I know the reason I couldn't solve WW58...\nhttp://t.co/pZ2n2o7j6E",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "628924236804001792"
          ],
          "editableUntil" : "2015-08-05T14:13:17.558Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "96"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "628912930143113216",
      "id_str" : "628924236804001792",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "628924236804001792",
      "in_reply_to_status_id" : "628912930143113216",
      "created_at" : "Wed Aug 05 13:43:17 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer Muahahahaha. That means I've emulated my experiences with the real game well enough.",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "626928163994632192"
          ],
          "editableUntil" : "2015-07-31T02:01:36.715Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/3wvJmmIY4X",
            "expanded_url" : "http://fillets.sourceforge.net/",
            "display_url" : "fillets.sourceforge.net",
            "indices" : [
              "118",
              "140"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "626928163994632192",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "626928163994632192",
      "possibly_sensitive" : false,
      "created_at" : "Fri Jul 31 01:31:36 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer Have you ever tried \"Fish Fillets NG\"?\nIt's one of my favorite games. It's a very fun free hard puzzler. \nhttp://t.co/3wvJmmIY4X",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "626876111616647168"
          ],
          "editableUntil" : "2015-07-30T22:34:46.461Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/ikD8J4nzow",
            "expanded_url" : "https://jacoblance.wordpress.com/2015/07/30/puzzle-103-dissection/",
            "display_url" : "jacoblance.wordpress.com/2015/07/30/puz…",
            "indices" : [
              "8",
              "31"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "31"
      ],
      "favorite_count" : "0",
      "id_str" : "626876111616647168",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "626876111616647168",
      "possibly_sensitive" : false,
      "created_at" : "Thu Jul 30 22:04:46 +0000 2015",
      "favorited" : false,
      "full_text" : "age++;\n\nhttps://t.co/ikD8J4nzow",
      "lang" : "und"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "625845807460282372"
          ],
          "editableUntil" : "2015-07-28T02:20:42.808Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Jacob Christian Munch-Andersen",
            "screen_name" : "NoHatCoder",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "2955518391",
            "id" : "2955518391"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/k6awOfWaxT",
            "expanded_url" : "http://ebusiness.hopto.org/snakebird.htm#Alb_rnwk4mQvIs6MtE2BVwE97f8EuEsEgD8hNlqH3RvhitwHuFgCkqpmAU-CR2hoViR1J8jcInioWpX9icoW2Y3xNsDuFe3A1HxMyWExGtp1gX06E9F44H1BW0FmKFgVuyo24NZ4GkiImNpVRgHXsRkIlgEv6EgvQynxE0IvOM3py-AvPv4X3HsgxoG5WsyH",
            "display_url" : "ebusiness.hopto.org/snakebird.htm#…",
            "indices" : [
              "41",
              "63"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "63"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "625247573041913856",
      "id_str" : "625845807460282372",
      "in_reply_to_user_id" : "2955518391",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "625845807460282372",
      "in_reply_to_status_id" : "625247573041913856",
      "possibly_sensitive" : false,
      "created_at" : "Tue Jul 28 01:50:42 +0000 2015",
      "favorited" : false,
      "full_text" : "@NoHatCoder Cool!\n\nMade a little level:\n\nhttp://t.co/k6awOfWaxT",
      "lang" : "en",
      "in_reply_to_screen_name" : "NoHatCoder",
      "in_reply_to_user_id_str" : "2955518391"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "624647086156476416"
          ],
          "editableUntil" : "2015-07-24T18:57:25.378Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "138"
      ],
      "favorite_count" : "1",
      "id_str" : "624647086156476416",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "624647086156476416",
      "created_at" : "Fri Jul 24 18:27:25 +0000 2015",
      "favorited" : false,
      "full_text" : "\"Spring\" and \"Fall\" are both seasons. \"Springs\" and \"Falls\" are both bodies of water. In fact, even the word \"seasons\" starts with \"seas\".",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "624319480470986753"
          ],
          "editableUntil" : "2015-07-23T21:15:38.096Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "60"
      ],
      "favorite_count" : "0",
      "id_str" : "624319480470986753",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "624319480470986753",
      "created_at" : "Thu Jul 23 20:45:38 +0000 2015",
      "favorited" : false,
      "full_text" : "Moe and Sideshow Bob from The Simpsons are both bart-enders.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "621015945608343553"
          ],
          "editableUntil" : "2015-07-14T18:28:34.008Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "620890515261665280",
      "id_str" : "621015945608343553",
      "in_reply_to_user_id" : "144119186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "621015945608343553",
      "in_reply_to_status_id" : "620890515261665280",
      "created_at" : "Tue Jul 14 17:58:34 +0000 2015",
      "favorited" : false,
      "full_text" : "@chaotic_iak\nFun game!\nI think this may be an unintended solution to 9\nUUULUURDRRURRRDRRUDDDLDDDLLLUURRDRULURURDDR\nStuck on 12's red for now",
      "lang" : "en",
      "in_reply_to_screen_name" : "chaotic_iak",
      "in_reply_to_user_id_str" : "144119186"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "620040388020047872"
          ],
          "editableUntil" : "2015-07-12T01:52:02.954Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "132"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "620038864824963072",
      "id_str" : "620040388020047872",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "620040388020047872",
      "in_reply_to_status_id" : "620038864824963072",
      "created_at" : "Sun Jul 12 01:22:02 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer \nBut 1+r3 doesn't equal (4+(1+r3)/(2+r3))/(6+(1+r3)/(2+r3)).\n1+r3 = 2.732\n2+(4+(1+r3)/(2+r3))/(6+(1+r3)/(2+r3)) =  2.702",
      "lang" : "cy",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "620037134154514432"
          ],
          "editableUntil" : "2015-07-12T01:39:07.172Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "620034103446913025",
      "id_str" : "620037134154514432",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "620037134154514432",
      "in_reply_to_status_id" : "620034103446913025",
      "created_at" : "Sun Jul 12 01:09:07 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer \nI'm not sure what you mean. Are you saying it is in fact rt(3)? If instead you're saying the proof doesn't work, then I agree.",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "620024484938919936"
          ],
          "editableUntil" : "2015-07-12T00:48:51.364Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "110"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "620023639191220228",
      "id_str" : "620024484938919936",
      "in_reply_to_user_id" : "2444552670",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "620024484938919936",
      "in_reply_to_status_id" : "620023639191220228",
      "created_at" : "Sun Jul 12 00:18:51 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer That logic implies that the numerator, 1+rt(3), should equal 2+(3+rt(3))/(5+rt(3)) and it doesn't.",
      "lang" : "en",
      "in_reply_to_screen_name" : "Jack_L_Lance",
      "in_reply_to_user_id_str" : "2444552670"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "620023639191220228"
          ],
          "editableUntil" : "2015-07-12T00:45:29.722Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "620021296294858752",
      "id_str" : "620023639191220228",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "620023639191220228",
      "in_reply_to_status_id" : "620021296294858752",
      "created_at" : "Sun Jul 12 00:15:29 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer I made it up. It seems to converge to rt(3) which kind of makes sense because rt(3)=1+(1+rt(3))/(2+rt(3)) but there's a problem:",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "619990918297460736"
          ],
          "editableUntil" : "2015-07-11T22:35:28.453Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "http://t.co/SpupwOIorq",
            "expanded_url" : "http://gyazo.com/9f5f9d8efa15076e699f96590d1b184b",
            "display_url" : "gyazo.com/9f5f9d8efa1507…",
            "indices" : [
              "93",
              "115"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "115"
      ],
      "favorite_count" : "0",
      "id_str" : "619990918297460736",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "619990918297460736",
      "possibly_sensitive" : false,
      "created_at" : "Sat Jul 11 22:05:28 +0000 2015",
      "favorited" : false,
      "full_text" : "Gaah.\n\nCan someone please tell me the value of this fraction. (Pretend it goes infinitely.)\n\nhttp://t.co/SpupwOIorq",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "618957062966497280"
          ],
          "editableUntil" : "2015-07-09T02:07:18.134Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "77"
      ],
      "favorite_count" : "1",
      "id_str" : "618957062966497280",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "618957062966497280",
      "created_at" : "Thu Jul 09 01:37:18 +0000 2015",
      "favorited" : false,
      "full_text" : "\"niched\" and \"cliched\" are, in some sense, very aesthetically nice opposites.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "617328166613422081"
          ],
          "editableUntil" : "2015-07-04T14:14:38.980Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "94"
      ],
      "favorite_count" : "2",
      "id_str" : "617328166613422081",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "617328166613422081",
      "created_at" : "Sat Jul 04 13:44:38 +0000 2015",
      "favorited" : false,
      "full_text" : "Adding a \"t\" to the front of the words \"rick\" and \"roll\" both accurately describe a rick-roll.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "617073908609626112"
          ],
          "editableUntil" : "2015-07-03T21:24:19.148Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Nick Bentley",
            "screen_name" : "Nick__Bentley",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "57118326",
            "id" : "57118326"
          },
          {
            "name" : "FoxMind",
            "screen_name" : "FoxMind",
            "indices" : [
              "15",
              "23"
            ],
            "id_str" : "38250916",
            "id" : "38250916"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "43"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "617036704852127744",
      "id_str" : "617073908609626112",
      "in_reply_to_user_id" : "57118326",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "617073908609626112",
      "in_reply_to_status_id" : "617036704852127744",
      "created_at" : "Fri Jul 03 20:54:19 +0000 2015",
      "favorited" : false,
      "full_text" : "@Nick__Bentley @FoxMind \nPRAISE cHRIST. OMg",
      "lang" : "et",
      "in_reply_to_screen_name" : "Nick__Bentley",
      "in_reply_to_user_id_str" : "57118326"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "617072985753657344"
          ],
          "editableUntil" : "2015-07-03T21:20:39.122Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Nick Bentley",
            "screen_name" : "Nick__Bentley",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "57118326",
            "id" : "57118326"
          },
          {
            "name" : "FoxMind",
            "screen_name" : "FoxMind",
            "indices" : [
              "15",
              "23"
            ],
            "id_str" : "38250916",
            "id" : "38250916"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "48"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "617036704852127744",
      "id_str" : "617072985753657344",
      "in_reply_to_user_id" : "57118326",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "617072985753657344",
      "in_reply_to_status_id" : "617036704852127744",
      "created_at" : "Fri Jul 03 20:50:39 +0000 2015",
      "favorited" : false,
      "full_text" : "@Nick__Bentley @FoxMind \nOuR MESSIAH'S A PROfIT!",
      "lang" : "en",
      "in_reply_to_screen_name" : "Nick__Bentley",
      "in_reply_to_user_id_str" : "57118326"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "617071670902263808"
          ],
          "editableUntil" : "2015-07-03T21:15:25.637Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Nick Bentley",
            "screen_name" : "Nick__Bentley",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "57118326",
            "id" : "57118326"
          },
          {
            "name" : "FoxMind",
            "screen_name" : "FoxMind",
            "indices" : [
              "15",
              "23"
            ],
            "id_str" : "38250916",
            "id" : "38250916"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "52"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "617036704852127744",
      "id_str" : "617071670902263808",
      "in_reply_to_user_id" : "57118326",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "617071670902263808",
      "in_reply_to_status_id" : "617036704852127744",
      "created_at" : "Fri Jul 03 20:45:25 +0000 2015",
      "favorited" : false,
      "full_text" : "@Nick__Bentley @FoxMind \nARMIES' MASS: HOly-SPEAR IT",
      "lang" : "en",
      "in_reply_to_screen_name" : "Nick__Bentley",
      "in_reply_to_user_id_str" : "57118326"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "616766051414601728"
          ],
          "editableUntil" : "2015-07-03T01:01:00.273Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "135"
      ],
      "favorite_count" : "0",
      "id_str" : "616766051414601728",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "616766051414601728",
      "created_at" : "Fri Jul 03 00:31:00 +0000 2015",
      "favorited" : false,
      "full_text" : "I was getting a lot of hits, but then the server crashed and the whole net went down. I guess I'll have to get a new ping-pong table...",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "616645915856740352"
          ],
          "editableUntil" : "2015-07-02T17:03:37.724Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "http://t.co/1r2l8vNkxU",
            "expanded_url" : "http://www.puzzlescript.net/play.html?p=8adae61697ca001a9e2f",
            "display_url" : "puzzlescript.net/play.html?p=8a…",
            "indices" : [
              "105",
              "127"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "127"
      ],
      "favorite_count" : "0",
      "id_str" : "616645915856740352",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "616645915856740352",
      "possibly_sensitive" : false,
      "created_at" : "Thu Jul 02 16:33:37 +0000 2015",
      "favorited" : false,
      "full_text" : "More snakeoban levels!\n(There are some hard levels here, so press 'X' twice if you want to skip a level)\nhttp://t.co/1r2l8vNkxU",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "615635793982451712"
          ],
          "editableUntil" : "2015-06-29T22:09:45.902Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "http://t.co/vqPqdMOVQ7",
            "expanded_url" : "http://www.puzzlescript.net/play.html?p=46f5f677943611267358",
            "display_url" : "puzzlescript.net/play.html?p=46…",
            "indices" : [
              "17",
              "39"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "615635793982451712",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "615635793982451712",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jun 29 21:39:45 +0000 2015",
      "favorited" : false,
      "full_text" : "Very hard level:\nhttp://t.co/vqPqdMOVQ7\n(In case you didn't see the first levels, you win by covering both purple squares with brown crates)",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "615157095827116032"
          ],
          "editableUntil" : "2015-06-28T14:27:35.368Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          },
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "13",
              "24"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "119"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "615149189912231936",
      "id_str" : "615157095827116032",
      "in_reply_to_user_id" : "144119186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "615157095827116032",
      "in_reply_to_status_id" : "615149189912231936",
      "created_at" : "Sun Jun 28 13:57:35 +0000 2015",
      "favorited" : false,
      "full_text" : "@chaotic_iak @edderiofer Oh right. I could have done that with my previous game too, as if it weren't confusing enough.",
      "lang" : "en",
      "in_reply_to_screen_name" : "chaotic_iak",
      "in_reply_to_user_id_str" : "144119186"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "615142489549348864"
          ],
          "editableUntil" : "2015-06-28T13:29:32.960Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "615142270799618048",
      "id_str" : "615142489549348864",
      "in_reply_to_user_id" : "2444552670",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "615142489549348864",
      "in_reply_to_status_id" : "615142270799618048",
      "created_at" : "Sun Jun 28 12:59:32 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer I believe that is the smallest that compiles without errors. (not quite a game without rules, levels, or win conditions though)",
      "lang" : "en",
      "in_reply_to_screen_name" : "Jack_L_Lance",
      "in_reply_to_user_id_str" : "2444552670"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "615142270799618048"
          ],
          "editableUntil" : "2015-06-28T13:28:40.806Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "111"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "614966094831423488",
      "id_str" : "615142270799618048",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "615142270799618048",
      "in_reply_to_status_id" : "614966094831423488",
      "created_at" : "Sun Jun 28 12:58:40 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer OBJECTS\nplayer a\nred\nbackground t\ngrey\nLEGEND\nSOUNDS\nCOLLISIONLAYERS\nt\na\nRULES\nWINCONDITIONS\nLEVELS",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "614936806967132160"
          ],
          "editableUntil" : "2015-06-27T23:52:14.411Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "138"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "614935080725839872",
      "id_str" : "614936806967132160",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "614936806967132160",
      "in_reply_to_status_id" : "614935080725839872",
      "created_at" : "Sat Jun 27 23:22:14 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer That was fast!\nThe smallest game is already 100 chars, so I could only make it hard by making it hard to know what's going on.",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "614936121080967168"
          ],
          "editableUntil" : "2015-06-27T23:49:30.883Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ben Porter",
            "screen_name" : "eigenbom",
            "indices" : [
              "1",
              "10"
            ],
            "id_str" : "42345318",
            "id" : "42345318"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "121"
      ],
      "favorite_count" : "1",
      "id_str" : "614936121080967168",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "614936121080967168",
      "created_at" : "Sat Jun 27 23:19:30 +0000 2015",
      "favorited" : false,
      "full_text" : ".@eigenbom My previous tweet is a Puzzlescript game. (I couldn't reply to you in the same tweet as it is 137 characters.)",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "614935865496891392"
          ],
          "editableUntil" : "2015-06-27T23:48:29.947Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "143"
      ],
      "favorite_count" : "1",
      "id_str" : "614935865496891392",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "614935865496891392",
      "created_at" : "Sat Jun 27 23:18:29 +0000 2015",
      "favorited" : false,
      "full_text" : "OBJECTS\nplayer a\nred\nbackground t\ngrey\nLEGEND\nSOUNDS\nCOLLISIONLAYERS\nt\na\nRULES\n[]-&gt;[a]\n[^ a|a]-&gt;[|]\nWINCONDITIONS\nno a\nLEVELS\naatta\nttata",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "614637837598748676"
          ],
          "editableUntil" : "2015-06-27T04:04:14.559Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "16"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "614553181662613504",
      "id_str" : "614637837598748676",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "614637837598748676",
      "in_reply_to_status_id" : "614553181662613504",
      "created_at" : "Sat Jun 27 03:34:14 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer Yup!",
      "lang" : "und",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "614637780468109312"
          ],
          "editableUntil" : "2015-06-27T04:04:00.938Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "132"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "614545396866678785",
      "id_str" : "614637780468109312",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "614637780468109312",
      "in_reply_to_status_id" : "614545396866678785",
      "created_at" : "Sat Jun 27 03:34:00 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer \nI figured that it didn't matter to solve the binary star, and then when you got to the masyu, it is easy to figure out.",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "614538124467830784"
          ],
          "editableUntil" : "2015-06-26T21:28:01.096Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "81"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "614525863128793088",
      "id_str" : "614538124467830784",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "614538124467830784",
      "in_reply_to_status_id" : "614525863128793088",
      "created_at" : "Fri Jun 26 20:58:01 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer For now, assume R5C3 is 7 while I fix it, and thanks for alerting me.",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "614538049859493888"
          ],
          "editableUntil" : "2015-06-26T21:27:43.308Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "105"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "614525863128793088",
      "id_str" : "614538049859493888",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "614538049859493888",
      "in_reply_to_status_id" : "614525863128793088",
      "created_at" : "Fri Jun 26 20:57:43 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer Daaaaaarn it.\nI checked that a surprisingly high amount of times to have missed it each time.",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "614537014063562752"
          ],
          "editableUntil" : "2015-06-26T21:23:36.355Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/Fhu3GrZjn4",
            "expanded_url" : "http://gyazo.com/8c1e97b1e890efff1ac8a9276459ea21",
            "display_url" : "gyazo.com/8c1e97b1e890ef…",
            "indices" : [
              "65",
              "87"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "87"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "614531159557455872",
      "id_str" : "614537014063562752",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "614537014063562752",
      "in_reply_to_status_id" : "614531159557455872",
      "possibly_sensitive" : false,
      "created_at" : "Fri Jun 26 20:53:36 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer The entire contents of that were all for one puzzle:\nhttp://t.co/Fhu3GrZjn4",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "614106747674996736"
          ],
          "editableUntil" : "2015-06-25T16:53:52.854Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "50"
      ],
      "favorite_count" : "1",
      "id_str" : "614106747674996736",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "614106747674996736",
      "created_at" : "Thu Jun 25 16:23:52 +0000 2015",
      "favorited" : false,
      "full_text" : "This is a sentence with two unusual par(enthe)ses.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "614084066699288576"
          ],
          "editableUntil" : "2015-06-25T15:23:45.288Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "http://t.co/u8tmgn9bRi",
            "expanded_url" : "http://www.puzzlescript.net/play.html?p=914939f531ea5f1930d4",
            "display_url" : "puzzlescript.net/play.html?p=91…",
            "indices" : [
              "15",
              "37"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "61"
      ],
      "favorite_count" : "0",
      "id_str" : "614084066699288576",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "614084066699288576",
      "possibly_sensitive" : false,
      "created_at" : "Thu Jun 25 14:53:45 +0000 2015",
      "favorited" : false,
      "full_text" : "5 more levels:\nhttp://t.co/u8tmgn9bRi\nMore snakes = more fun!",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "613011868676964352"
          ],
          "editableUntil" : "2015-06-22T16:23:13.359Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "http://t.co/Pb9nzzwKjy",
            "expanded_url" : "http://www.puzzlescript.net/play.html?p=e5561ef165d87310166e",
            "display_url" : "puzzlescript.net/play.html?p=e5…",
            "indices" : [
              "63",
              "85"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "85"
      ],
      "favorite_count" : "0",
      "id_str" : "613011868676964352",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "613011868676964352",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jun 22 15:53:13 +0000 2015",
      "favorited" : false,
      "full_text" : "I'm working on a new game. This version has 10 levels so far:\n\nhttp://t.co/Pb9nzzwKjy",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "612750590087720960"
          ],
          "editableUntil" : "2015-06-21T23:04:59.689Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "612740679098343424",
      "id_str" : "612750590087720960",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "612750590087720960",
      "in_reply_to_status_id" : "612740679098343424",
      "created_at" : "Sun Jun 21 22:34:59 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer Each puzzle is solvable individually.",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "612736425004433408"
          ],
          "editableUntil" : "2015-06-21T22:08:42.470Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/GBFODNsikX",
            "expanded_url" : "https://jacoblance.wordpress.com/2015/06/21/puzzle-102-fillomino/",
            "display_url" : "jacoblance.wordpress.com/2015/06/21/puz…",
            "indices" : [
              "42",
              "65"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "65"
      ],
      "favorite_count" : "0",
      "id_str" : "612736425004433408",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "612736425004433408",
      "possibly_sensitive" : false,
      "created_at" : "Sun Jun 21 21:38:42 +0000 2015",
      "favorited" : false,
      "full_text" : "Puzzle marathon extravaganza thingamabob:\nhttps://t.co/GBFODNsikX",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "612321412817104896"
          ],
          "editableUntil" : "2015-06-20T18:39:35.854Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "98"
      ],
      "favorite_count" : "0",
      "id_str" : "612321412817104896",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "612321412817104896",
      "created_at" : "Sat Jun 20 18:09:35 +0000 2015",
      "favorited" : false,
      "full_text" : "In English, beheading \"none\" leaves \"one\"\nIn Spanish, beheading \"one\" (\"uno\") leaves \"none\" (\"no\")",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "611197829462278145"
          ],
          "editableUntil" : "2015-06-17T16:14:52.707Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Sergio Cornaga",
            "screen_name" : "corneaga",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "91806656",
            "id" : "91806656"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "132"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "611114870633660416",
      "id_str" : "611197829462278145",
      "in_reply_to_user_id" : "91806656",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "611197829462278145",
      "in_reply_to_status_id" : "611114870633660416",
      "created_at" : "Wed Jun 17 15:44:52 +0000 2015",
      "favorited" : false,
      "full_text" : "@corneaga @increpare @terrytheplatypu\nThink out of the box-office. ;)\nAlso, I didn't use a program for 3 either, just Wolfram Alpha.",
      "lang" : "en",
      "in_reply_to_screen_name" : "corneaga",
      "in_reply_to_user_id_str" : "91806656"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "611001659012071424"
          ],
          "editableUntil" : "2015-06-17T03:15:22.027Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "PUNctuation",
            "indices" : [
              "98",
              "110"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "110"
      ],
      "favorite_count" : "0",
      "id_str" : "611001659012071424",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "611001659012071424",
      "created_at" : "Wed Jun 17 02:45:22 +0000 2015",
      "favorited" : false,
      "full_text" : "Regrettably, I didn't have enough space to include the appropriate hashtag in my previous tweet:\n\n#PUNctuation",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "611001242526056449"
          ],
          "editableUntil" : "2015-06-17T03:13:42.729Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "141"
      ],
      "favorite_count" : "0",
      "id_str" : "611001242526056449",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "611001242526056449",
      "created_at" : "Wed Jun 17 02:43:42 +0000 2015",
      "favorited" : false,
      "full_text" : "@ the 100 metre ―, sprinters • ~ finish\nthen do other events, * of losing gets &gt; they get less hope. trying, don't ^ all, and don't ,gain.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "610793186009546752"
          ],
          "editableUntil" : "2015-06-16T13:26:58.190Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "130"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "610769478956253184",
      "id_str" : "610793186009546752",
      "in_reply_to_user_id" : "75783213",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "610793186009546752",
      "in_reply_to_status_id" : "610769478956253184",
      "created_at" : "Tue Jun 16 12:56:58 +0000 2015",
      "favorited" : false,
      "full_text" : "@increpare Loved office 5, although it took a very painful amount of time writing down inputs and outputs for me to figure it out!",
      "lang" : "en",
      "in_reply_to_user_id_str" : "75783213"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "609764140593344512"
          ],
          "editableUntil" : "2015-06-13T17:17:54.644Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Brian Chen",
            "screen_name" : "betaveros",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "531087134",
            "id" : "531087134"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "67"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "609762284190105600",
      "id_str" : "609764140593344512",
      "in_reply_to_user_id" : "531087134",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "609764140593344512",
      "in_reply_to_status_id" : "609762284190105600",
      "created_at" : "Sat Jun 13 16:47:54 +0000 2015",
      "favorited" : false,
      "full_text" : "@betaveros Incredible! Congratulations and good luck in the finals!",
      "lang" : "en",
      "in_reply_to_screen_name" : "betaveros",
      "in_reply_to_user_id_str" : "531087134"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "608426888718094338"
          ],
          "editableUntil" : "2015-06-10T00:44:08.952Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/TW1OaKeEgi",
            "expanded_url" : "https://jacoblance.wordpress.com/2015/06/10/puzzle-96-sierpinski-fillomino/",
            "display_url" : "jacoblance.wordpress.com/2015/06/10/puz…",
            "indices" : [
              "22",
              "45"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "45"
      ],
      "favorite_count" : "0",
      "id_str" : "608426888718094338",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "608426888718094338",
      "possibly_sensitive" : false,
      "created_at" : "Wed Jun 10 00:14:08 +0000 2015",
      "favorited" : false,
      "full_text" : "Sierpinski Fillomino!\nhttps://t.co/TW1OaKeEgi",
      "lang" : "es"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "608419133961723904"
          ],
          "editableUntil" : "2015-06-10T00:13:20.074Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/608419133961723904/photo/1",
            "indices" : [
              "78",
              "100"
            ],
            "url" : "http://t.co/Jn7xfze5eL",
            "media_url" : "http://pbs.twimg.com/media/CHGJ29gWgAAdr11.png",
            "id_str" : "608419001987923968",
            "id" : "608419001987923968",
            "media_url_https" : "https://pbs.twimg.com/media/CHGJ29gWgAAdr11.png",
            "sizes" : {
              "medium" : {
                "w" : "249",
                "h" : "164",
                "resize" : "fit"
              },
              "large" : {
                "w" : "249",
                "h" : "164",
                "resize" : "fit"
              },
              "small" : {
                "w" : "249",
                "h" : "164",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/Jn7xfze5eL"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "100"
      ],
      "favorite_count" : "0",
      "id_str" : "608419133961723904",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "608419133961723904",
      "possibly_sensitive" : false,
      "created_at" : "Tue Jun 09 23:43:20 +0000 2015",
      "favorited" : false,
      "full_text" : "Some more language picture crossword thingies, now with correct stroke order! http://t.co/Jn7xfze5eL",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/608419133961723904/photo/1",
            "indices" : [
              "78",
              "100"
            ],
            "url" : "http://t.co/Jn7xfze5eL",
            "media_url" : "http://pbs.twimg.com/media/CHGJ29gWgAAdr11.png",
            "id_str" : "608419001987923968",
            "id" : "608419001987923968",
            "media_url_https" : "https://pbs.twimg.com/media/CHGJ29gWgAAdr11.png",
            "sizes" : {
              "medium" : {
                "w" : "249",
                "h" : "164",
                "resize" : "fit"
              },
              "large" : {
                "w" : "249",
                "h" : "164",
                "resize" : "fit"
              },
              "small" : {
                "w" : "249",
                "h" : "164",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/Jn7xfze5eL"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "607922738607456256"
          ],
          "editableUntil" : "2015-06-08T15:20:50.199Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "133"
      ],
      "favorite_count" : "0",
      "id_str" : "607922738607456256",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "607922738607456256",
      "created_at" : "Mon Jun 08 14:50:50 +0000 2015",
      "favorited" : false,
      "full_text" : "A study measuring how much time parents spend with their children would be the only permissible use of the second-person in a report.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "607357832699117568"
          ],
          "editableUntil" : "2015-06-07T01:56:06.135Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "17"
      ],
      "favorite_count" : "0",
      "id_str" : "607357832699117568",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "607357832699117568",
      "created_at" : "Sun Jun 07 01:26:06 +0000 2015",
      "favorited" : false,
      "full_text" : "Mohawks, mowings.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "606593477909061632"
          ],
          "editableUntil" : "2015-06-04T23:18:49.752Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "1",
      "id_str" : "606593477909061632",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "606593477909061632",
      "created_at" : "Thu Jun 04 22:48:49 +0000 2015",
      "favorited" : false,
      "full_text" : "A trap in chess should be called a pawnsy scheme.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "605816555788582912"
          ],
          "editableUntil" : "2015-06-02T19:51:37.084Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "115"
      ],
      "favorite_count" : "1",
      "id_str" : "605816555788582912",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "605816555788582912",
      "created_at" : "Tue Jun 02 19:21:37 +0000 2015",
      "favorited" : false,
      "full_text" : "\"It's your word against mine\" would be an excellent slogan for Scrabble. (Currently it is \"Every word's a winner.\")",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "605478105445068802"
          ],
          "editableUntil" : "2015-06-01T21:26:44.234Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "FitzgeraldTeller",
            "screen_name" : "Mathgrant",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1532161137927766016",
            "id" : "1532161137927766016"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "115"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "605476736873029632",
      "id_str" : "605478105445068802",
      "in_reply_to_user_id" : "2444552670",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "605478105445068802",
      "in_reply_to_status_id" : "605476736873029632",
      "created_at" : "Mon Jun 01 20:56:44 +0000 2015",
      "favorited" : false,
      "full_text" : "@mathgrant Also, they win an average of $1061.18 over all the times that they win, so an expected $644.282 overall.",
      "lang" : "en",
      "in_reply_to_screen_name" : "Jack_L_Lance",
      "in_reply_to_user_id_str" : "2444552670"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "605476736873029632"
          ],
          "editableUntil" : "2015-06-01T21:21:17.941Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "FitzgeraldTeller",
            "screen_name" : "Mathgrant",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1532161137927766016",
            "id" : "1532161137927766016"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "62"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "605470895520530432",
      "id_str" : "605476736873029632",
      "in_reply_to_user_id" : "816686946",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "605476736873029632",
      "in_reply_to_status_id" : "605470895520530432",
      "created_at" : "Mon Jun 01 20:51:17 +0000 2015",
      "favorited" : false,
      "full_text" : "@mathgrant Using a program, I got 220319/362880, or about 61%.",
      "lang" : "en",
      "in_reply_to_user_id_str" : "816686946"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "601944264529031168"
          ],
          "editableUntil" : "2015-05-23T03:24:30.904Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "115"
      ],
      "favorite_count" : "0",
      "id_str" : "601944264529031168",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "601944264529031168",
      "created_at" : "Sat May 23 02:54:30 +0000 2015",
      "favorited" : false,
      "full_text" : "After switching yellow and violet, pick one letter from each color of the rainbow in order to make a 7-letter word.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "599702346105548800"
          ],
          "editableUntil" : "2015-05-16T22:55:55.899Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "http://t.co/4x1CnRVNrD",
            "expanded_url" : "http://gyazo.com/e4e2dc13ec00f9c73dd5562251e85f35",
            "display_url" : "gyazo.com/e4e2dc13ec00f9…",
            "indices" : [
              "114",
              "136"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "136"
      ],
      "favorite_count" : "0",
      "id_str" : "599702346105548800",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "599702346105548800",
      "possibly_sensitive" : false,
      "created_at" : "Sat May 16 22:25:55 +0000 2015",
      "favorited" : false,
      "full_text" : "The letters in this word were folded and rotated, but not rearranged. What word was it originally? Are you sure?\n\nhttp://t.co/4x1CnRVNrD",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "599270898189864960"
          ],
          "editableUntil" : "2015-05-15T18:21:30.700Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "58"
      ],
      "favorite_count" : "1",
      "id_str" : "599270898189864960",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "599270898189864960",
      "created_at" : "Fri May 15 17:51:30 +0000 2015",
      "favorited" : false,
      "full_text" : "\"Do money calculations well\"\n=\n\"Economically sound wallet\"",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "599021055504613376"
          ],
          "editableUntil" : "2015-05-15T01:48:43.562Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/X9LDi9ZPet",
            "expanded_url" : "https://jacoblance.wordpress.com/2015/05/15/puzzle-94-word-puzzle/",
            "display_url" : "jacoblance.wordpress.com/2015/05/15/puz…",
            "indices" : [
              "11",
              "34"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "34"
      ],
      "favorite_count" : "0",
      "id_str" : "599021055504613376",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "599021055504613376",
      "possibly_sensitive" : false,
      "created_at" : "Fri May 15 01:18:43 +0000 2015",
      "favorited" : false,
      "full_text" : "Key-words: https://t.co/X9LDi9ZPet",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "598300274323791872"
          ],
          "editableUntil" : "2015-05-13T02:04:35.937Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "87"
      ],
      "favorite_count" : "0",
      "id_str" : "598300274323791872",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "598300274323791872",
      "created_at" : "Wed May 13 01:34:35 +0000 2015",
      "favorited" : false,
      "full_text" : "Oh dang it. I completely didn't notice 5/10/2015...\nnow I have to wait for 6/10/2016 :(",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "597905102675038209"
          ],
          "editableUntil" : "2015-05-11T23:54:19.674Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "118"
      ],
      "favorite_count" : "0",
      "id_str" : "597905102675038209",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "597905102675038209",
      "created_at" : "Mon May 11 23:24:19 +0000 2015",
      "favorited" : false,
      "full_text" : "28 hours per week = pi/3 radians\n\nAlthough the weirdest unit conversion I have ever done, this is technically correct.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "597499631463960576"
          ],
          "editableUntil" : "2015-05-10T21:03:07.804Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "http://t.co/ku4zNNHDvu",
            "expanded_url" : "http://www.puzzlescript.net/play.html?p=9f314fdb60407dc3ee60",
            "display_url" : "puzzlescript.net/play.html?p=9f…",
            "indices" : [
              "39",
              "61"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "61"
      ],
      "favorite_count" : "0",
      "id_str" : "597499631463960576",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "597499631463960576",
      "possibly_sensitive" : false,
      "created_at" : "Sun May 10 20:33:07 +0000 2015",
      "favorited" : false,
      "full_text" : "Two more tricky 7x7 levels for Duplex:\nhttp://t.co/ku4zNNHDvu",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "595392376304205824"
          ],
          "editableUntil" : "2015-05-05T01:29:39.023Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "http://t.co/6vnM99JCpG",
            "expanded_url" : "http://www.puzzlescript.net/play.html?p=be9cfd160d22904b8316",
            "display_url" : "puzzlescript.net/play.html?p=be…",
            "indices" : [
              "15",
              "37"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "53"
      ],
      "favorite_count" : "0",
      "id_str" : "595392376304205824",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "595392376304205824",
      "possibly_sensitive" : false,
      "created_at" : "Tue May 05 00:59:39 +0000 2015",
      "favorited" : false,
      "full_text" : "New game idea:\nhttp://t.co/6vnM99JCpG\nOnly two rules!",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "595360329695125504"
          ],
          "editableUntil" : "2015-05-04T23:22:18.516Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "138"
      ],
      "favorite_count" : "0",
      "id_str" : "595360329695125504",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "595360329695125504",
      "created_at" : "Mon May 04 22:52:18 +0000 2015",
      "favorited" : false,
      "full_text" : "\"I would have not given you all of the candy that there is.\" makes sense but \"I'd haven't given y'all of the candy that there's.\" doesn't.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "594929874185355265"
          ],
          "editableUntil" : "2015-05-03T18:51:49.925Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "84"
      ],
      "favorite_count" : "0",
      "id_str" : "594929874185355265",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "594929874185355265",
      "created_at" : "Sun May 03 18:21:49 +0000 2015",
      "favorited" : false,
      "full_text" : "I would not recommend for anyone with the last name \"Park\" to run a family business.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "593046181929967618"
          ],
          "editableUntil" : "2015-04-28T14:06:42.694Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "99"
      ],
      "favorite_count" : "1",
      "id_str" : "593046181929967618",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "593046181929967618",
      "created_at" : "Tue Apr 28 13:36:42 +0000 2015",
      "favorited" : false,
      "full_text" : "Divide letters in half, line up in monospace type where 'I's all fall to read the solution plainly.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "592680988490276864"
          ],
          "editableUntil" : "2015-04-27T13:55:33.793Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "108"
      ],
      "favorite_count" : "0",
      "id_str" : "592680988490276864",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "592680988490276864",
      "created_at" : "Mon Apr 27 13:25:33 +0000 2015",
      "favorited" : false,
      "full_text" : "Scrabble (puzzle): 7x8, wordlist NIL,ONE,TWO,THREE,FIVE,SIX,SEVEN,EIGHT,NINE,TEN,ELEVEN \n\n(unique solution!)",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "592477721885835264"
          ],
          "editableUntil" : "2015-04-27T00:27:51.258Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/q5c7mHX829",
            "expanded_url" : "http://gyazo.com/d15dbfd3371b12b822fe7bb3a484b551",
            "display_url" : "gyazo.com/d15dbfd3371b12…",
            "indices" : [
              "112",
              "134"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "134"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "592476367121416192",
      "id_str" : "592477721885835264",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "592477721885835264",
      "in_reply_to_status_id" : "592476367121416192",
      "possibly_sensitive" : false,
      "created_at" : "Sun Apr 26 23:57:51 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer I used finite differences, but I don't remember how to get the polynomial from it.\nHere is my work: http://t.co/q5c7mHX829",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "592474456154484736"
          ],
          "editableUntil" : "2015-04-27T00:14:52.647Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "89"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "592472788893626369",
      "id_str" : "592474456154484736",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "592474456154484736",
      "in_reply_to_status_id" : "592472788893626369",
      "created_at" : "Sun Apr 26 23:44:52 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer You get (10,-3532)....\nStarting from \"EDD\", you get the last name \"EGJNSY\"...",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "592471828527996928"
          ],
          "editableUntil" : "2015-04-27T00:04:26.172Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "592463942275997697",
      "id_str" : "592471828527996928",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "592471828527996928",
      "in_reply_to_status_id" : "592463942275997697",
      "created_at" : "Sun Apr 26 23:34:26 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer If (1,10), (2,1), (3,3), (4,11) is a cubic, the values stays within 1 and 26 longer than expected and is somewhat pronounceable.",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "592447209481744384"
          ],
          "editableUntil" : "2015-04-26T22:26:36.534Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "120"
      ],
      "favorite_count" : "0",
      "id_str" : "592447209481744384",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "592447209481744384",
      "created_at" : "Sun Apr 26 21:56:36 +0000 2015",
      "favorited" : false,
      "full_text" : "Assuming that \"JACK\" is a cubic, my full name is Jack T. Yuc. It manages to stay between 1 and 26 for surprisingly long.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "591675324582240256"
          ],
          "editableUntil" : "2015-04-24T19:19:24.833Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/591675324582240256/photo/1",
            "indices" : [
              "83",
              "105"
            ],
            "url" : "http://t.co/I8APxHdK3n",
            "media_url" : "http://pbs.twimg.com/media/CDYNkoVVEAAOz-c.png",
            "id_str" : "591675323999129600",
            "id" : "591675323999129600",
            "media_url_https" : "https://pbs.twimg.com/media/CDYNkoVVEAAOz-c.png",
            "sizes" : {
              "large" : {
                "w" : "259",
                "h" : "158",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "259",
                "h" : "158",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "259",
                "h" : "158",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/I8APxHdK3n"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "105"
      ],
      "favorite_count" : "0",
      "id_str" : "591675324582240256",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "591675324582240256",
      "possibly_sensitive" : false,
      "created_at" : "Fri Apr 24 18:49:24 +0000 2015",
      "favorited" : false,
      "full_text" : "This is the \"Chinese symbol meaning 'hands'.\" and a \"picture that denotes 'tree'.\" http://t.co/I8APxHdK3n",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/591675324582240256/photo/1",
            "indices" : [
              "83",
              "105"
            ],
            "url" : "http://t.co/I8APxHdK3n",
            "media_url" : "http://pbs.twimg.com/media/CDYNkoVVEAAOz-c.png",
            "id_str" : "591675323999129600",
            "id" : "591675323999129600",
            "media_url_https" : "https://pbs.twimg.com/media/CDYNkoVVEAAOz-c.png",
            "sizes" : {
              "large" : {
                "w" : "259",
                "h" : "158",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "259",
                "h" : "158",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "259",
                "h" : "158",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/I8APxHdK3n"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "591636829381734400"
          ],
          "editableUntil" : "2015-04-24T16:46:26.862Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "120"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "591513720993361920",
      "id_str" : "591636829381734400",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "591636829381734400",
      "in_reply_to_status_id" : "591513720993361920",
      "created_at" : "Fri Apr 24 16:16:26 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer Noooooooooooo. Fudge.\nTwitter has no \"Edit Tweet\".\n\nYou're right, it was supposed to be \"ever\", not \"never\".",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "591451967572078592"
          ],
          "editableUntil" : "2015-04-24T04:31:52.372Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "111"
      ],
      "favorite_count" : "0",
      "id_str" : "591451967572078592",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "591451967572078592",
      "created_at" : "Fri Apr 24 04:01:52 +0000 2015",
      "favorited" : false,
      "full_text" : "(2/2)\nIncrement\n     and we can find\nthe dividend\n     when we divide\nis not whole then\n    that means we lied.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "591451777490386944"
          ],
          "editableUntil" : "2015-04-24T04:31:07.053Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "115"
      ],
      "favorite_count" : "0",
      "id_str" : "591451777490386944",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "591451777490386944",
      "created_at" : "Fri Apr 24 04:01:07 +0000 2015",
      "favorited" : false,
      "full_text" : "(1/2)\nIf we pretend\n     the set of primes\nwill never end,\n     then we define\nthe number N\n     just multiply 'em.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "590517659214737408"
          ],
          "editableUntil" : "2015-04-21T14:39:15.901Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "120"
      ],
      "favorite_count" : "1",
      "id_str" : "590517659214737408",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "590517659214737408",
      "created_at" : "Tue Apr 21 14:09:15 +0000 2015",
      "favorited" : false,
      "full_text" : "(2/2) and the frequency I normally say them within a current period. Especially when I force it; it mega-hurts his ears.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "590517462824783873"
          ],
          "editableUntil" : "2015-04-21T14:38:29.078Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "94"
      ],
      "favorite_count" : "1",
      "id_str" : "590517462824783873",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "590517462824783873",
      "created_at" : "Tue Apr 21 14:08:29 +0000 2015",
      "favorited" : false,
      "full_text" : "(1/2) My lab partner hates me because of the mass of physics terms that work as potential puns",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "590179039345770496"
          ],
          "editableUntil" : "2015-04-20T16:13:42.633Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "FitzgeraldTeller",
            "screen_name" : "Mathgrant",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1532161137927766016",
            "id" : "1532161137927766016"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "128"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "590015156224155648",
      "id_str" : "590179039345770496",
      "in_reply_to_user_id" : "816686946",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "590179039345770496",
      "in_reply_to_status_id" : "590015156224155648",
      "created_at" : "Mon Apr 20 15:43:42 +0000 2015",
      "favorited" : false,
      "full_text" : "@mathgrant With 2 sides, the expected is 1/p+1/q-1/(p+q).\nWith 3 sides, it is 1/p+1/q+1/r-1/(p+q)-1/(q+r)-1/(p+s)+1/(p+q+r) etc.",
      "lang" : "en",
      "in_reply_to_user_id_str" : "816686946"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "589516701386969089"
          ],
          "editableUntil" : "2015-04-18T20:21:48.958Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "138"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "589270321330462720",
      "id_str" : "589516701386969089",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "589516701386969089",
      "in_reply_to_status_id" : "589270321330462720",
      "created_at" : "Sat Apr 18 19:51:48 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer First one is right (although you might want to rot13 that). Looking back, word relations of the 2nd one might be a bit tricky.",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "589171364042567681"
          ],
          "editableUntil" : "2015-04-17T21:29:34.119Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "133"
      ],
      "favorite_count" : "0",
      "id_str" : "589171364042567681",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "589171364042567681",
      "created_at" : "Fri Apr 17 20:59:34 +0000 2015",
      "favorited" : false,
      "full_text" : "extra-layer metaphors:\nlarge:big::begin:end:::month:december::president:??????????\ncolor:blew::hairy:bawled:::animal:flow::piece:????",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "588132109853790209"
          ],
          "editableUntil" : "2015-04-15T00:39:56.612Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          },
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "12",
              "24"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/ujVYVtGAfW",
            "expanded_url" : "http://gyazo.com/4cef4172d23ebabadc43f7493bb5c83b",
            "display_url" : "gyazo.com/4cef4172d23eba…",
            "indices" : [
              "74",
              "96"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "138"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "588120793999142913",
      "id_str" : "588132109853790209",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "588132109853790209",
      "in_reply_to_status_id" : "588120793999142913",
      "possibly_sensitive" : false,
      "created_at" : "Wed Apr 15 00:09:56 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer @chaotic_iak I agree the second seems wrong. Here's my logic: http://t.co/ujVYVtGAfW. I haven't formally proven either though.",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "588038376575602688"
          ],
          "editableUntil" : "2015-04-14T18:27:28.857Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "588038376575602688",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "588038376575602688",
      "created_at" : "Tue Apr 14 17:57:28 +0000 2015",
      "favorited" : false,
      "full_text" : "The maximum shaded squares of a hitori of area A approaches A/3 (!)\nThe maximum shaded squares of a yajilin of area A approaches A/3 (!!!!!)",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "587688156813795331"
          ],
          "editableUntil" : "2015-04-13T19:15:49.959Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/ZuDhrMmqi6",
            "expanded_url" : "https://jacoblance.files.wordpress.com/2015/04/jllogo.png?w=400",
            "display_url" : "jacoblance.files.wordpress.com/2015/04/jllogo…",
            "indices" : [
              "0",
              "23"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "0",
      "id_str" : "587688156813795331",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "587688156813795331",
      "possibly_sensitive" : false,
      "created_at" : "Mon Apr 13 18:45:49 +0000 2015",
      "favorited" : false,
      "full_text" : "https://t.co/ZuDhrMmqi6",
      "lang" : "zxx"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "587443509604540416"
          ],
          "editableUntil" : "2015-04-13T03:03:41.519Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "129"
      ],
      "favorite_count" : "0",
      "id_str" : "587443509604540416",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "587443509604540416",
      "created_at" : "Mon Apr 13 02:33:41 +0000 2015",
      "favorited" : false,
      "full_text" : "Interestingly, exactly five of {\"do\", \"re\", \"mi\", \"fa\", \"sol\", \"la\", \"ti\"} appear in the full names of the singers in Pentatonix.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "587278526967078912"
          ],
          "editableUntil" : "2015-04-12T16:08:06.593Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/6MGwqiehtd",
            "expanded_url" : "http://gyazo.com/3c7532a959ffe301b89db3f87f1f7428",
            "display_url" : "gyazo.com/3c7532a959ffe3…",
            "indices" : [
              "59",
              "81"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "81"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "587275489418416130",
      "id_str" : "587278526967078912",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "587278526967078912",
      "in_reply_to_status_id" : "587275489418416130",
      "possibly_sensitive" : false,
      "created_at" : "Sun Apr 12 15:38:06 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer Alright, I retroactively filled in some words: http://t.co/6MGwqiehtd",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "587274641183481856"
          ],
          "editableUntil" : "2015-04-12T15:52:40.150Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "134"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "587144061208793089",
      "id_str" : "587274641183481856",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "587274641183481856",
      "in_reply_to_status_id" : "587144061208793089",
      "created_at" : "Sun Apr 12 15:22:40 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer Nothing. It would be weird to write words just to remove them, so I just wrote random (syntactically correct) punctuation.",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "586639989175427073"
          ],
          "editableUntil" : "2015-04-10T21:50:47.320Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "1",
      "id_str" : "586639989175427073",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "586639989175427073",
      "created_at" : "Fri Apr 10 21:20:47 +0000 2015",
      "favorited" : false,
      "full_text" : "TWo hundrEd EighTh. //This could have worked on \"Twenty eighth\", or \"Twentieth\" (!) if I had thought of it, but this is the 3rd possibility.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "585891149279264768"
          ],
          "editableUntil" : "2015-04-08T20:15:09.976Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "28"
      ],
      "favorite_count" : "0",
      "id_str" : "585891149279264768",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "585891149279264768",
      "created_at" : "Wed Apr 08 19:45:09 +0000 2015",
      "favorited" : false,
      "full_text" : "The past has passed past us.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "585217154234081282"
          ],
          "editableUntil" : "2015-04-06T23:36:57.035Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "138"
      ],
      "favorite_count" : "0",
      "id_str" : "585217154234081282",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "585217154234081282",
      "created_at" : "Mon Apr 06 23:06:57 +0000 2015",
      "favorited" : false,
      "full_text" : "I don't get why teachers always tell students to put phones away. I thought they were supposed to like when their students brought apples?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "584554550947946496"
          ],
          "editableUntil" : "2015-04-05T03:44:00.101Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "57"
      ],
      "favorite_count" : "0",
      "id_str" : "584554550947946496",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "584554550947946496",
      "created_at" : "Sun Apr 05 03:14:00 +0000 2015",
      "favorited" : false,
      "full_text" : "I try to type pretty witty top row twitter quote I wrote.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "584531988046082048"
          ],
          "editableUntil" : "2015-04-05T02:14:20.686Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "119"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "584497784688095233",
      "id_str" : "584531988046082048",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "584531988046082048",
      "in_reply_to_status_id" : "584497784688095233",
      "created_at" : "Sun Apr 05 01:44:20 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer Yeah. I wasn't sure if that would be impossible or not. It's supposed to be \"Removing consonants is worse.\"",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "584180511737778176"
          ],
          "editableUntil" : "2015-04-04T02:57:42.204Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "136"
      ],
      "favorite_count" : "0",
      "id_str" : "584180511737778176",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "584180511737778176",
      "created_at" : "Sat Apr 04 02:27:42 +0000 2015",
      "favorited" : false,
      "full_text" : "cn cmmnct mch mr nfrmtn n m twts whn  rmv ll th vwls, lthgh  spps t mks t mch mr frstrtng nd dffclt fr m fllwrs t cmprhnd. eoi ooa i oe.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "583454158419861504"
          ],
          "editableUntil" : "2015-04-02T02:51:26.078Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "125"
      ],
      "favorite_count" : "0",
      "id_str" : "583454158419861504",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "583454158419861504",
      "created_at" : "Thu Apr 02 02:21:26 +0000 2015",
      "favorited" : false,
      "full_text" : "\"I don't watch horror movies anymore because of the sh*ing.\"\n\"I have to take care of some err*s before I start coding again.\"",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "583453361535590400"
          ],
          "editableUntil" : "2015-04-02T02:48:16.086Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "137"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "583077816012554240",
      "id_str" : "583453361535590400",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "583453361535590400",
      "in_reply_to_status_id" : "583077816012554240",
      "created_at" : "Thu Apr 02 02:18:16 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer \"Off\" and \"on\" do this a surprising amount.\n\"The fire alarm went * \"\n\"It was built * the foundation\"\n\"She survives * welfare\"",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "583072589934915584"
          ],
          "editableUntil" : "2015-04-01T01:35:13.062Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "73"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "583065373995585538",
      "id_str" : "583072589934915584",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "583072589934915584",
      "in_reply_to_status_id" : "583065373995585538",
      "created_at" : "Wed Apr 01 01:05:13 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer Consider what happens when happiness is positive or negative.",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "582863577645768704"
          ],
          "editableUntil" : "2015-03-31T11:44:40.649Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "54"
      ],
      "favorite_count" : "0",
      "id_str" : "582863577645768704",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "582863577645768704",
      "created_at" : "Tue Mar 31 11:14:40 +0000 2015",
      "favorited" : false,
      "full_text" : "The second derivative of your mouth is your happiness.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "582640155779080192"
          ],
          "editableUntil" : "2015-03-30T20:56:52.725Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "62"
      ],
      "favorite_count" : "0",
      "id_str" : "582640155779080192",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "582640155779080192",
      "created_at" : "Mon Mar 30 20:26:52 +0000 2015",
      "favorited" : false,
      "full_text" : "I just found out there's someone at my school named Jack Lang.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "582361416209985536"
          ],
          "editableUntil" : "2015-03-30T02:29:16.033Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "138"
      ],
      "favorite_count" : "0",
      "id_str" : "582361416209985536",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "582361416209985536",
      "created_at" : "Mon Mar 30 01:59:16 +0000 2015",
      "favorited" : false,
      "full_text" : "If LHS+HIGH+SCHOOL=SOCOOL and {L,O,G,I,C,M,A,T,H,S}={0,1,2,3,4,5,6,7,8,9}, what is the ordered pair (M+A+T+H,floor(T+e+A+M))?\n(e=2.718...)",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "582331017912020992"
          ],
          "editableUntil" : "2015-03-30T00:28:28.514Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "582331017912020992",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "582331017912020992",
      "created_at" : "Sun Mar 29 23:58:28 +0000 2015",
      "favorited" : false,
      "full_text" : "The word \"indevout\" is very indecisive. \nIt means \"not totally committed to a cause or belief.\" and has both the words \"in\" and \"out\" in it.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "581050410242326529"
          ],
          "editableUntil" : "2015-03-26T11:39:47.853Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "111"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "581050121577697280",
      "id_str" : "581050410242326529",
      "in_reply_to_user_id" : "2444552670",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "581050410242326529",
      "in_reply_to_status_id" : "581050121577697280",
      "created_at" : "Thu Mar 26 11:09:47 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer It stood out to me, because before then I assumed your name was Ed DeRiofer or something like that.",
      "lang" : "en",
      "in_reply_to_screen_name" : "Jack_L_Lance",
      "in_reply_to_user_id_str" : "2444552670"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "581050121577697280"
          ],
          "editableUntil" : "2015-03-26T11:38:39.030Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "580964718090801153",
      "id_str" : "581050121577697280",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "581050121577697280",
      "in_reply_to_status_id" : "580964718090801153",
      "created_at" : "Thu Mar 26 11:08:39 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer You said it out loud in your chess solo speed-run in your previous tweet 6 days ago and it's in the description of that as well.",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "580856118341197825"
          ],
          "editableUntil" : "2015-03-25T22:47:45.054Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Jack Lance",
            "screen_name" : "Jack_L_Lance",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "2444552670",
            "id" : "2444552670"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "143"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "580854508512808960",
      "id_str" : "580856118341197825",
      "in_reply_to_user_id" : "2444552670",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "580856118341197825",
      "in_reply_to_status_id" : "580854508512808960",
      "created_at" : "Wed Mar 25 22:17:45 +0000 2015",
      "favorited" : false,
      "full_text" : "@Jack_L_Lance If you change mine to devjoe's then you can add Brian Chen. This is pretty darn coincidental considering I have &lt;10 followers.",
      "lang" : "en",
      "in_reply_to_screen_name" : "Jack_L_Lance",
      "in_reply_to_user_id_str" : "2444552670"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "580854508512808960"
          ],
          "editableUntil" : "2015-03-25T22:41:21.241Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Jack Lance",
            "screen_name" : "Jack_L_Lance",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "2444552670",
            "id" : "2444552670"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "132"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "580853991275425792",
      "id_str" : "580854508512808960",
      "in_reply_to_user_id" : "2444552670",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "580854508512808960",
      "in_reply_to_status_id" : "580853991275425792",
      "created_at" : "Wed Mar 25 22:11:21 +0000 2015",
      "favorited" : false,
      "full_text" : "@Jack_L_Lance You could also replace my name with devjoe's, and it would still hold. I prefer to use my own name of course though :P",
      "lang" : "en",
      "in_reply_to_screen_name" : "Jack_L_Lance",
      "in_reply_to_user_id_str" : "2444552670"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "580541050080620544"
          ],
          "editableUntil" : "2015-03-25T01:55:46.927Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "128"
      ],
      "favorite_count" : "0",
      "id_str" : "580541050080620544",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "580541050080620544",
      "created_at" : "Wed Mar 25 01:25:46 +0000 2015",
      "favorited" : false,
      "full_text" : "This sentence has a quite fun property Jack calls non-alliteration. Each of its very many words uses distinct beginning letters.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "580443716126679040"
          ],
          "editableUntil" : "2015-03-24T19:29:00.704Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "44"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "580379493446995968",
      "id_str" : "580443716126679040",
      "in_reply_to_user_id" : "144119186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "580443716126679040",
      "in_reply_to_status_id" : "580379493446995968",
      "created_at" : "Tue Mar 24 18:59:00 +0000 2015",
      "favorited" : false,
      "full_text" : "@chaotic_iak Oh wow. That's insanely clever.",
      "lang" : "en",
      "in_reply_to_screen_name" : "chaotic_iak",
      "in_reply_to_user_id_str" : "144119186"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "580357511448027137"
          ],
          "editableUntil" : "2015-03-24T13:46:27.907Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "143"
      ],
      "favorite_count" : "0",
      "id_str" : "580357511448027137",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "580357511448027137",
      "created_at" : "Tue Mar 24 13:16:27 +0000 2015",
      "favorited" : false,
      "full_text" : "For arbitrarily small p&lt;1, is there some n such that you can shade floor(pn) cells in each row and column of an nxn grid that are connected?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "579645547230945280"
          ],
          "editableUntil" : "2015-03-22T14:37:22.410Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "1",
      "id_str" : "579645547230945280",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "579645547230945280",
      "created_at" : "Sun Mar 22 14:07:22 +0000 2015",
      "favorited" : false,
      "full_text" : "/aɪ/ in Spanish means /yoʊ/ in Chinese (hay,有)\n/aɪ/ in English  means /yoʊ/ in Spanish (I,yo)\n/aɪ/ in Chinese means /yoʊ/ in English (哎,yo)",
      "lang" : "et"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "579068172994678784"
          ],
          "editableUntil" : "2015-03-21T00:23:05.665Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "579068172994678784",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "579068172994678784",
      "created_at" : "Fri Mar 20 23:53:05 +0000 2015",
      "favorited" : false,
      "full_text" : "Rainbows are often gay pride colors. \nPink, the only (saturated) color not in the rainbow, is also often used for  a gay pride color.\nWhat.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "578734658344656896"
          ],
          "editableUntil" : "2015-03-20T02:17:49.576Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "578730390195601408",
      "id_str" : "578734658344656896",
      "in_reply_to_user_id" : "144119186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "578734658344656896",
      "in_reply_to_status_id" : "578730390195601408",
      "created_at" : "Fri Mar 20 01:47:49 +0000 2015",
      "favorited" : false,
      "full_text" : "@chaotic_iak That's what I thought, but it always seems to \"just miss\" and I have no idea why.\nI came up with this problem a year ago. Sigh.",
      "lang" : "en",
      "in_reply_to_screen_name" : "chaotic_iak",
      "in_reply_to_user_id_str" : "144119186"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "578724274996973568"
          ],
          "editableUntil" : "2015-03-20T01:36:33.993Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "138"
      ],
      "favorite_count" : "0",
      "id_str" : "578724274996973568",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "578724274996973568",
      "created_at" : "Fri Mar 20 01:06:33 +0000 2015",
      "favorited" : false,
      "full_text" : "Is it possible to shade n cells in every row and column of a 2n x 2n grid so that the shaded cells create one contnected region for any n?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "577566098704449536"
          ],
          "editableUntil" : "2015-03-16T20:54:23.247Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "138"
      ],
      "favorite_count" : "0",
      "id_str" : "577566098704449536",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "577566098704449536",
      "created_at" : "Mon Mar 16 20:24:23 +0000 2015",
      "favorited" : false,
      "full_text" : "(Cont.) \nFor example,\n\nB A P Q R _ Z\nC D O N S T Y\nF E _ M L U X\nG H I J K V W\n \nHas \"DONS\" in the second row. Now find a six letter word.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "577565172920938496"
          ],
          "editableUntil" : "2015-03-16T20:50:42.523Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "577565172920938496",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "577565172920938496",
      "created_at" : "Mon Mar 16 20:20:42 +0000 2015",
      "favorited" : false,
      "full_text" : "Start by writing A in a 4x7 grid, write B next to it, C, D, etc. leaving two cells blank. \nThe puzzle is to have a 6 letter word in a line.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "577544943159402497"
          ],
          "editableUntil" : "2015-03-16T19:30:19.372Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "0",
      "id_str" : "577544943159402497",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "577544943159402497",
      "created_at" : "Mon Mar 16 19:00:19 +0000 2015",
      "favorited" : false,
      "full_text" : "Every vowel is used in a same parity.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "576814717513138176"
          ],
          "editableUntil" : "2015-03-14T19:08:40.011Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "FitzgeraldTeller",
            "screen_name" : "Mathgrant",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1532161137927766016",
            "id" : "1532161137927766016"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/3pBWNbcHvl",
            "expanded_url" : "http://oeis.org/A015134",
            "display_url" : "oeis.org/A015134",
            "indices" : [
              "17",
              "39"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "80"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "576799920927145984",
      "id_str" : "576814717513138176",
      "in_reply_to_user_id" : "816686946",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "576814717513138176",
      "in_reply_to_status_id" : "576799920927145984",
      "possibly_sensitive" : false,
      "created_at" : "Sat Mar 14 18:38:40 +0000 2015",
      "favorited" : false,
      "full_text" : "@mathgrant Found http://t.co/3pBWNbcHvl, which gives the amount of cycles mod n.",
      "lang" : "en",
      "in_reply_to_user_id_str" : "816686946"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "576784304799350784"
          ],
          "editableUntil" : "2015-03-14T17:07:49.055Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/yj8fPUUChC",
            "expanded_url" : "https://jacoblance.wordpress.com/2015/03/14/p-i-hunt-1/",
            "display_url" : "jacoblance.wordpress.com/2015/03/14/p-i…",
            "indices" : [
              "10",
              "33"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "33"
      ],
      "favorite_count" : "0",
      "id_str" : "576784304799350784",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "576784304799350784",
      "possibly_sensitive" : false,
      "created_at" : "Sat Mar 14 16:37:49 +0000 2015",
      "favorited" : false,
      "full_text" : "P.I.HUNT!\nhttps://t.co/yj8fPUUChC",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "576749495402135553"
          ],
          "editableUntil" : "2015-03-14T14:49:29.848Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "120"
      ],
      "favorite_count" : "0",
      "id_str" : "576749495402135553",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "576749495402135553",
      "created_at" : "Sat Mar 14 14:19:29 +0000 2015",
      "favorited" : false,
      "full_text" : "Middleground Is Tough :\\ //I was planning on tweeting \"Meh, I Tried :(\" or \"Made It Through :)\". Sigh... more waiting...",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "576210962233044992"
          ],
          "editableUntil" : "2015-03-13T03:09:33.535Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "576210962233044992",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "576210962233044992",
      "created_at" : "Fri Mar 13 02:39:33 +0000 2015",
      "favorited" : false,
      "full_text" : "There are 3 thursdays between the 2nd Sunday of March (USA's DST) and the last one (France's DST). No more Can't Stop tourneys for a bit. :(",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1344666025980264448"
          ],
          "editableUntil" : "2020-12-31T15:55:37.937Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1344666025980264448/photo/1",
            "indices" : [
              "0",
              "23"
            ],
            "url" : "https://t.co/x5iDcLPITl",
            "media_url" : "http://pbs.twimg.com/media/Eqk2ALhXEAETCW8.png",
            "id_str" : "1344665340467417089",
            "id" : "1344665340467417089",
            "media_url_https" : "https://pbs.twimg.com/media/Eqk2ALhXEAETCW8.png",
            "sizes" : {
              "large" : {
                "w" : "514",
                "h" : "444",
                "resize" : "fit"
              },
              "small" : {
                "w" : "514",
                "h" : "444",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "514",
                "h" : "444",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/x5iDcLPITl"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "16",
      "id_str" : "1344666025980264448",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1344666025980264448",
      "possibly_sensitive" : false,
      "created_at" : "Thu Dec 31 15:25:37 +0000 2020",
      "favorited" : false,
      "full_text" : "https://t.co/x5iDcLPITl",
      "lang" : "zxx",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1344666025980264448/photo/1",
            "indices" : [
              "0",
              "23"
            ],
            "url" : "https://t.co/x5iDcLPITl",
            "media_url" : "http://pbs.twimg.com/media/Eqk2ALhXEAETCW8.png",
            "id_str" : "1344665340467417089",
            "id" : "1344665340467417089",
            "media_url_https" : "https://pbs.twimg.com/media/Eqk2ALhXEAETCW8.png",
            "sizes" : {
              "large" : {
                "w" : "514",
                "h" : "444",
                "resize" : "fit"
              },
              "small" : {
                "w" : "514",
                "h" : "444",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "514",
                "h" : "444",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/x5iDcLPITl"
          },
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1344666025980264448/photo/1",
            "indices" : [
              "0",
              "23"
            ],
            "url" : "https://t.co/x5iDcLPITl",
            "media_url" : "http://pbs.twimg.com/media/Eqk2CmRXIAEqcDI.png",
            "id_str" : "1344665382007808001",
            "id" : "1344665382007808001",
            "media_url_https" : "https://pbs.twimg.com/media/Eqk2CmRXIAEqcDI.png",
            "sizes" : {
              "large" : {
                "w" : "1217",
                "h" : "462",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "258",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "456",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/x5iDcLPITl"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1328807820997914628"
          ],
          "editableUntil" : "2020-11-17T21:40:47.238Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1328807820997914628/photo/1",
            "indices" : [
              "69",
              "92"
            ],
            "url" : "https://t.co/fGS4VCFk2Q",
            "media_url" : "http://pbs.twimg.com/media/EnDfiOeXYAAOpKK.png",
            "id_str" : "1328807669168300032",
            "id" : "1328807669168300032",
            "media_url_https" : "https://pbs.twimg.com/media/EnDfiOeXYAAOpKK.png",
            "sizes" : {
              "large" : {
                "w" : "111",
                "h" : "144",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "111",
                "h" : "111",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "111",
                "h" : "144",
                "resize" : "fit"
              },
              "small" : {
                "w" : "111",
                "h" : "144",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/fGS4VCFk2Q"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "92"
      ],
      "favorite_count" : "162",
      "id_str" : "1328807820997914628",
      "truncated" : false,
      "retweet_count" : "27",
      "id" : "1328807820997914628",
      "possibly_sensitive" : false,
      "created_at" : "Tue Nov 17 21:10:47 +0000 2020",
      "favorited" : false,
      "full_text" : "It's weirdly ambiguous what state a person wearing this shirt loves. https://t.co/fGS4VCFk2Q",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1328807820997914628/photo/1",
            "indices" : [
              "69",
              "92"
            ],
            "url" : "https://t.co/fGS4VCFk2Q",
            "media_url" : "http://pbs.twimg.com/media/EnDfiOeXYAAOpKK.png",
            "id_str" : "1328807669168300032",
            "id" : "1328807669168300032",
            "media_url_https" : "https://pbs.twimg.com/media/EnDfiOeXYAAOpKK.png",
            "sizes" : {
              "large" : {
                "w" : "111",
                "h" : "144",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "111",
                "h" : "111",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "111",
                "h" : "144",
                "resize" : "fit"
              },
              "small" : {
                "w" : "111",
                "h" : "144",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/fGS4VCFk2Q"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1322175916429221888"
          ],
          "editableUntil" : "2020-10-30T14:27:57.974Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "162"
      ],
      "favorite_count" : "14",
      "id_str" : "1322175916429221888",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1322175916429221888",
      "created_at" : "Fri Oct 30 13:57:57 +0000 2020",
      "favorited" : false,
      "full_text" : "There is a word that can be spelled from the names of 3 consecutive notes on a piano.\n(Note: The answer isn't BAG! Those notes are adjacent, but not consecutive!)",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1312929174064107521"
          ],
          "editableUntil" : "2020-10-05T02:04:42.798Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/kbQC6vdphl",
            "expanded_url" : "https://ldjam.com/events/ludum-dare/47/torus-tours",
            "display_url" : "ldjam.com/events/ludum-d…",
            "indices" : [
              "46",
              "69"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1312929174064107521/photo/1",
            "indices" : [
              "70",
              "93"
            ],
            "url" : "https://t.co/Dyksmm1ZrJ",
            "media_url" : "http://pbs.twimg.com/media/Ejh1G26WoAcNehq.jpg",
            "id_str" : "1312928052058431495",
            "id" : "1312928052058431495",
            "media_url_https" : "https://pbs.twimg.com/media/Ejh1G26WoAcNehq.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1113",
                "h" : "692",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1113",
                "h" : "692",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "423",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/Dyksmm1ZrJ"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "93"
      ],
      "favorite_count" : "12",
      "id_str" : "1312929174064107521",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1312929174064107521",
      "possibly_sensitive" : false,
      "created_at" : "Mon Oct 05 01:34:42 +0000 2020",
      "favorited" : false,
      "full_text" : "I just made Torus Tours for Ludum Dare 47 :)\n\nhttps://t.co/kbQC6vdphl https://t.co/Dyksmm1ZrJ",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1312929174064107521/photo/1",
            "indices" : [
              "70",
              "93"
            ],
            "url" : "https://t.co/Dyksmm1ZrJ",
            "media_url" : "http://pbs.twimg.com/media/Ejh1G26WoAcNehq.jpg",
            "id_str" : "1312928052058431495",
            "id" : "1312928052058431495",
            "media_url_https" : "https://pbs.twimg.com/media/Ejh1G26WoAcNehq.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1113",
                "h" : "692",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1113",
                "h" : "692",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "423",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/Dyksmm1ZrJ"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1311722710259634178"
          ],
          "editableUntil" : "2020-10-01T18:10:39.412Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "beekie",
            "screen_name" : "beekie18",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "1264236147141681152",
            "id" : "1264236147141681152"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "285"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1311719570693070848",
      "id_str" : "1311722710259634178",
      "in_reply_to_user_id" : "1264236147141681152",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1311722710259634178",
      "in_reply_to_status_id" : "1311719570693070848",
      "created_at" : "Thu Oct 01 17:40:39 +0000 2020",
      "favorited" : false,
      "full_text" : "@beekie18 Hmm I definitely could have worded it better (was hard to fit into one tweet because it's very contrived) but I was referring to 24 hour clocks that start at 0/12 and go to 11/23, instead of 1 to 12.\nI should have probably said something like military time vs. standard time?",
      "lang" : "en",
      "in_reply_to_screen_name" : "beekie18",
      "in_reply_to_user_id_str" : "1264236147141681152"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1311664627005059074"
          ],
          "editableUntil" : "2020-10-01T14:19:51.285Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "279"
      ],
      "favorite_count" : "4",
      "id_str" : "1311664627005059074",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1311664627005059074",
      "created_at" : "Thu Oct 01 13:49:51 +0000 2020",
      "favorited" : false,
      "full_text" : "Write a 6 letter word thematic to this puzzle, equally spaced on a clock, starting at 8 and going CCW\n\nThe 4 letters on the left in increasing order on a 24-hour clock, and the 4 letters on the right in increasing order on a 12-hour clock make a 2 word clue for the original word",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1306311846291558400"
          ],
          "editableUntil" : "2020-09-16T19:49:48.913Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "76"
      ],
      "favorite_count" : "9",
      "id_str" : "1306311846291558400",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1306311846291558400",
      "created_at" : "Wed Sep 16 19:19:48 +0000 2020",
      "favorited" : false,
      "full_text" : "I'm not sure this is how unit conversion works but \nANGSTROMS = GRAMS * TONS",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1291199302006706176"
          ],
          "editableUntil" : "2020-08-06T02:57:57.578Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "54"
      ],
      "favorite_count" : "14",
      "id_str" : "1291199302006706176",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1291199302006706176",
      "created_at" : "Thu Aug 06 02:27:57 +0000 2020",
      "favorited" : false,
      "full_text" : "\"Alphabetical order\" contains \"abcde\" as a subsequence",
      "lang" : "ca"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1290278325395419144"
          ],
          "editableUntil" : "2020-08-03T13:58:19.643Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/j5Cy4aXr1A",
            "expanded_url" : "https://jacklance.github.io/MacAndCHI/",
            "display_url" : "jacklance.github.io/MacAndCHI/",
            "indices" : [
              "39",
              "62"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "165"
      ],
      "favorite_count" : "39",
      "id_str" : "1290278325395419144",
      "truncated" : false,
      "retweet_count" : "11",
      "id" : "1290278325395419144",
      "possibly_sensitive" : false,
      "created_at" : "Mon Aug 03 13:28:19 +0000 2020",
      "favorited" : false,
      "full_text" : "Hi! We just finished making this game:\nhttps://t.co/j5Cy4aXr1A\nIt was a bit of an experiment. The game is a metaphor for itself. I think the puzzles ended up fun. :)",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1286014610240307205"
          ],
          "editableUntil" : "2020-07-22T19:35:50.734Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "276"
      ],
      "favorite_count" : "18",
      "in_reply_to_status_id_str" : "1286014553931812866",
      "id_str" : "1286014610240307205",
      "in_reply_to_user_id" : "2444552670",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1286014610240307205",
      "in_reply_to_status_id" : "1286014553931812866",
      "created_at" : "Wed Jul 22 19:05:50 +0000 2020",
      "favorited" : false,
      "full_text" : "Athos, Aramis, Porthos\nreuse, reduce, recycle\nBambi, Flower, Thumper\nincus, stapes, malleus\nbacon, tomato, lettuce\nPatty, Maxene, Laverne\nInigo, Fezzik, Vizzini\nbasic, acidic, neutral\nTorah, Nevi'im, Ketuvim\nAbdul, Cowell, Jackson\npower, wisdom, courage\nRicky, Julian, Bubbles",
      "lang" : "en",
      "in_reply_to_screen_name" : "Jack_L_Lance",
      "in_reply_to_user_id_str" : "2444552670"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1286014553931812866"
          ],
          "editableUntil" : "2020-07-22T19:35:37.309Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "207"
      ],
      "favorite_count" : "8",
      "id_str" : "1286014553931812866",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1286014553931812866",
      "created_at" : "Wed Jul 22 19:05:37 +0000 2020",
      "favorited" : false,
      "full_text" : "In case anyone wonders if I do anything remotely productive in my free time, here is a list of sets of three things in which one word has 5 letters, one has 6 letters, and one has 7, for literally no reason.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1283773259809521667"
          ],
          "editableUntil" : "2020-07-16T15:09:31.149Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "187"
      ],
      "favorite_count" : "12",
      "id_str" : "1283773259809521667",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1283773259809521667",
      "created_at" : "Thu Jul 16 14:39:31 +0000 2020",
      "favorited" : false,
      "full_text" : "CLAMBAKE is an eight-letter food spelled by inserting one four-letter food into another.\n\nAlso MEALTIME thematically becomes two four-letter foods words upon swapping its central letters.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1265376215634006018"
          ],
          "editableUntil" : "2020-05-26T20:46:14.017Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "148"
      ],
      "favorite_count" : "138",
      "id_str" : "1265376215634006018",
      "truncated" : false,
      "retweet_count" : "45",
      "id" : "1265376215634006018",
      "created_at" : "Tue May 26 20:16:14 +0000 2020",
      "favorited" : false,
      "full_text" : "\"AN EYEPATCHED PIRATE\"\nis an anagram of\n\"THE PAIRED-EYE CAPTAIN\"\n\nOh wait, hold on, nevermind.\nThe first one only has one I, but the second has two.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1265293058763087872"
          ],
          "editableUntil" : "2020-05-26T15:15:47.874Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "94"
      ],
      "favorite_count" : "6",
      "id_str" : "1265293058763087872",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1265293058763087872",
      "created_at" : "Tue May 26 14:45:47 +0000 2020",
      "favorited" : false,
      "full_text" : "div is a type of html element found on most websites.\nHowever, on websites, cdiv is not found.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1263599642756943872"
          ],
          "editableUntil" : "2020-05-21T23:06:46.036Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1263599642756943872/photo/1",
            "indices" : [
              "23",
              "46"
            ],
            "url" : "https://t.co/bmDzOMd8PO",
            "media_url" : "http://pbs.twimg.com/media/EYk1I_2X0AAMOv8.png",
            "id_str" : "1263599599148847104",
            "id" : "1263599599148847104",
            "media_url_https" : "https://pbs.twimg.com/media/EYk1I_2X0AAMOv8.png",
            "sizes" : {
              "small" : {
                "w" : "475",
                "h" : "342",
                "resize" : "fit"
              },
              "large" : {
                "w" : "475",
                "h" : "342",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "475",
                "h" : "342",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/bmDzOMd8PO"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "46"
      ],
      "favorite_count" : "61",
      "id_str" : "1263599642756943872",
      "truncated" : false,
      "retweet_count" : "16",
      "id" : "1263599642756943872",
      "possibly_sensitive" : false,
      "created_at" : "Thu May 21 22:36:46 +0000 2020",
      "favorited" : false,
      "full_text" : "strange tiny jigsaw... https://t.co/bmDzOMd8PO",
      "lang" : "ht",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1263599642756943872/photo/1",
            "indices" : [
              "23",
              "46"
            ],
            "url" : "https://t.co/bmDzOMd8PO",
            "media_url" : "http://pbs.twimg.com/media/EYk1I_2X0AAMOv8.png",
            "id_str" : "1263599599148847104",
            "id" : "1263599599148847104",
            "media_url_https" : "https://pbs.twimg.com/media/EYk1I_2X0AAMOv8.png",
            "sizes" : {
              "small" : {
                "w" : "475",
                "h" : "342",
                "resize" : "fit"
              },
              "large" : {
                "w" : "475",
                "h" : "342",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "475",
                "h" : "342",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/bmDzOMd8PO"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1247898878298357761"
          ],
          "editableUntil" : "2020-04-08T15:17:32.083Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1247898878298357761/photo/1",
            "indices" : [
              "249",
              "272"
            ],
            "url" : "https://t.co/QUhiwjHiaV",
            "media_url" : "http://pbs.twimg.com/media/EVFtD9CUcAE9u8c.png",
            "id_str" : "1247898486449664001",
            "id" : "1247898486449664001",
            "media_url_https" : "https://pbs.twimg.com/media/EVFtD9CUcAE9u8c.png",
            "sizes" : {
              "large" : {
                "w" : "202",
                "h" : "234",
                "resize" : "fit"
              },
              "small" : {
                "w" : "202",
                "h" : "234",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "202",
                "h" : "234",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/QUhiwjHiaV"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "272"
      ],
      "favorite_count" : "29",
      "id_str" : "1247898878298357761",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1247898878298357761",
      "possibly_sensitive" : false,
      "created_at" : "Wed Apr 08 14:47:32 +0000 2020",
      "favorited" : false,
      "full_text" : "This is an exceedingly random observation, but Stephen Jackson and Lance Stephenson are two famous basketball players who both played jersey 1 on the Indiana Pacers. Their names share \"Stephen\" and \"son\", and removing those gives \"Jack\" and \"Lance\" https://t.co/QUhiwjHiaV",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1247898878298357761/photo/1",
            "indices" : [
              "249",
              "272"
            ],
            "url" : "https://t.co/QUhiwjHiaV",
            "media_url" : "http://pbs.twimg.com/media/EVFtD9CUcAE9u8c.png",
            "id_str" : "1247898486449664001",
            "id" : "1247898486449664001",
            "media_url_https" : "https://pbs.twimg.com/media/EVFtD9CUcAE9u8c.png",
            "sizes" : {
              "large" : {
                "w" : "202",
                "h" : "234",
                "resize" : "fit"
              },
              "small" : {
                "w" : "202",
                "h" : "234",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "202",
                "h" : "234",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/QUhiwjHiaV"
          },
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1247898878298357761/photo/1",
            "indices" : [
              "249",
              "272"
            ],
            "url" : "https://t.co/QUhiwjHiaV",
            "media_url" : "http://pbs.twimg.com/media/EVFtE8wU8AkEsnw.png",
            "id_str" : "1247898503554068489",
            "id" : "1247898503554068489",
            "media_url_https" : "https://pbs.twimg.com/media/EVFtE8wU8AkEsnw.png",
            "sizes" : {
              "thumb" : {
                "w" : "116",
                "h" : "116",
                "resize" : "crop"
              },
              "small" : {
                "w" : "116",
                "h" : "200",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "116",
                "h" : "200",
                "resize" : "fit"
              },
              "large" : {
                "w" : "116",
                "h" : "200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/QUhiwjHiaV"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1243531704326905857"
          ],
          "editableUntil" : "2020-03-27T14:03:56.670Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/4tn1An1gOu",
            "expanded_url" : "https://www.puzzlescript.net/play.html?p=6f30db6b3c3011093f343006f1c8f12c",
            "display_url" : "puzzlescript.net/play.html?p=6f…",
            "indices" : [
              "24",
              "47"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "68"
      ],
      "favorite_count" : "23",
      "id_str" : "1243531704326905857",
      "truncated" : false,
      "retweet_count" : "8",
      "id" : "1243531704326905857",
      "possibly_sensitive" : false,
      "created_at" : "Fri Mar 27 13:33:56 +0000 2020",
      "favorited" : false,
      "full_text" : "Made a cute short game:\nhttps://t.co/4tn1An1gOu\n(pronounced \"vurps\")",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1241032941695897602"
          ],
          "editableUntil" : "2020-03-20T16:34:45.234Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/2uaD3drgz6",
            "expanded_url" : "https://ideone.com/rYof9i",
            "display_url" : "ideone.com/rYof9i",
            "indices" : [
              "43",
              "66"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "66"
      ],
      "favorite_count" : "5",
      "id_str" : "1241032941695897602",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1241032941695897602",
      "possibly_sensitive" : false,
      "created_at" : "Fri Mar 20 16:04:45 +0000 2020",
      "favorited" : false,
      "full_text" : "Can you find the ten \"bugs\" in this code?\n\nhttps://t.co/2uaD3drgz6",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1238858431945113607"
          ],
          "editableUntil" : "2020-03-14T16:34:01.709Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/Z4tpTcQRFQ",
            "expanded_url" : "https://jacoblance.wordpress.com/2020/03/14/p-i-hunt-6/",
            "display_url" : "jacoblance.wordpress.com/2020/03/14/p-i…",
            "indices" : [
              "14",
              "37"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "5",
      "id_str" : "1238858431945113607",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1238858431945113607",
      "possibly_sensitive" : false,
      "created_at" : "Sat Mar 14 16:04:01 +0000 2020",
      "favorited" : false,
      "full_text" : "P.I.HUNT 6 :D\nhttps://t.co/Z4tpTcQRFQ",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1228408991446896640"
          ],
          "editableUntil" : "2020-02-14T20:31:40.953Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/tERuytaxFu",
            "expanded_url" : "https://jacoblance.wordpress.com/2020/02/14/p-i-hunt-6-in-a-month/",
            "display_url" : "jacoblance.wordpress.com/2020/02/14/p-i…",
            "indices" : [
              "218",
              "241"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "241"
      ],
      "favorite_count" : "2",
      "id_str" : "1228408991446896640",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1228408991446896640",
      "possibly_sensitive" : false,
      "created_at" : "Fri Feb 14 20:01:40 +0000 2020",
      "favorited" : false,
      "full_text" : "Is it Valentine’s Day already? We’re getting EXTRA CLOSE TO NEW PI. There’s only a month until the 6th P.I. Hunt!\n\nSolve the anagram to learn what you should do to prepare:\n\nEXTRA CLOSE TO NEW PI = ????? ????????????\n\nhttps://t.co/tERuytaxFu",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "576191743302983680"
          ],
          "editableUntil" : "2015-03-13T01:53:11.385Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "25"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "576127401429700608",
      "id_str" : "576191743302983680",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "576191743302983680",
      "in_reply_to_status_id" : "576127401429700608",
      "created_at" : "Fri Mar 13 01:23:11 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer How cool! 好酷!",
      "lang" : "ja",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "576099862078451713"
          ],
          "editableUntil" : "2015-03-12T19:48:05.194Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "135"
      ],
      "favorite_count" : "0",
      "id_str" : "576099862078451713",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "576099862078451713",
      "created_at" : "Thu Mar 12 19:18:05 +0000 2015",
      "favorited" : false,
      "full_text" : "一 looks like 1 if you rotate it 90 degrees.\n七 looks like 7 if you rotate it 180 degrees.\n百looks like 100 if you rotate it 270 degrees .",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "575825363269476352"
          ],
          "editableUntil" : "2015-03-12T01:37:19.578Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "134"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "575526323705217024",
      "id_str" : "575825363269476352",
      "in_reply_to_user_id" : "144119186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "575825363269476352",
      "in_reply_to_status_id" : "575526323705217024",
      "created_at" : "Thu Mar 12 01:07:19 +0000 2015",
      "favorited" : false,
      "full_text" : "@chaotic_iak For all n,m there are finite sequences starting with n that don't change after the mth term. Then count incrementing n+m.",
      "lang" : "en",
      "in_reply_to_screen_name" : "chaotic_iak",
      "in_reply_to_user_id_str" : "144119186"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "575460644016627712"
          ],
          "editableUntil" : "2015-03-11T01:28:03.732Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "98"
      ],
      "favorite_count" : "1",
      "id_str" : "575460644016627712",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "575460644016627712",
      "created_at" : "Wed Mar 11 00:58:03 +0000 2015",
      "favorited" : false,
      "full_text" : "If you are eighteen, you are a teen. //I don't know why I'm enjoying homophones so much right now.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "575089206206267392"
          ],
          "editableUntil" : "2015-03-10T00:52:06.057Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "66"
      ],
      "favorite_count" : "0",
      "id_str" : "575089206206267392",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "575089206206267392",
      "created_at" : "Tue Mar 10 00:22:06 +0000 2015",
      "favorited" : false,
      "full_text" : "Public ships are cruise ships. Private ships are the crew's ships.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "575053149679022081"
          ],
          "editableUntil" : "2015-03-09T22:28:49.511Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "575052650665873408",
      "id_str" : "575053149679022081",
      "in_reply_to_user_id" : "2444552670",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "575053149679022081",
      "in_reply_to_status_id" : "575052650665873408",
      "created_at" : "Mon Mar 09 21:58:49 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer Now I've said \"rawer\" and \"rarer\" too much, and they don't sound like English words. They sound like noises you'd hear at a zoo.",
      "lang" : "en",
      "in_reply_to_screen_name" : "Jack_L_Lance",
      "in_reply_to_user_id_str" : "2444552670"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "575052650665873408"
          ],
          "editableUntil" : "2015-03-09T22:26:50.537Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "116"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "575049480770306048",
      "id_str" : "575052650665873408",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "575052650665873408",
      "in_reply_to_status_id" : "575049480770306048",
      "created_at" : "Mon Mar 09 21:56:50 +0000 2015",
      "favorited" : false,
      "full_text" : "@edderiofer Oops, yeah. I got confused what rare steak meant. Rephrase that as\n\"If your steak is rarer, it's rawer.\"",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "575029906209435648"
          ],
          "editableUntil" : "2015-03-09T20:56:27.836Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "0",
      "id_str" : "575029906209435648",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "575029906209435648",
      "created_at" : "Mon Mar 09 20:26:27 +0000 2015",
      "favorited" : false,
      "full_text" : "Your steak can either be rarer or rawer.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "573703865679417344"
          ],
          "editableUntil" : "2015-03-06T05:07:15.137Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "57"
      ],
      "favorite_count" : "0",
      "id_str" : "573703865679417344",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "573703865679417344",
      "created_at" : "Fri Mar 06 04:37:15 +0000 2015",
      "favorited" : false,
      "full_text" : "If you get distressed, you should try to get de-stressed.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "573225516934799360"
          ],
          "editableUntil" : "2015-03-04T21:26:27.909Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "http://t.co/rVE1mRoWWn",
            "expanded_url" : "http://www.puzzlescript.net/play.html?p=b232577d35eba6453614",
            "display_url" : "puzzlescript.net/play.html?p=b2…",
            "indices" : [
              "40",
              "62"
            ]
          },
          {
            "url" : "http://t.co/lmS4QbWs2J",
            "expanded_url" : "http://www.puzzlescript.net/play.html?p=debb1df146c14ea3916b",
            "display_url" : "puzzlescript.net/play.html?p=de…",
            "indices" : [
              "117",
              "139"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "573225516934799360",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "573225516934799360",
      "possibly_sensitive" : false,
      "created_at" : "Wed Mar 04 20:56:27 +0000 2015",
      "favorited" : false,
      "full_text" : "Three hard \"Dinosaur Love Story\" levels http://t.co/rVE1mRoWWn \nNow with multiple dinosaurs!\n(Here are the old ones: http://t.co/lmS4QbWs2J)",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "572949718764007425"
          ],
          "editableUntil" : "2015-03-04T03:10:32.501Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/k8S75T8PI7",
            "expanded_url" : "http://www.labnol.org/software/ms-paint-tips/9305/",
            "display_url" : "labnol.org/software/ms-pa…",
            "indices" : [
              "21",
              "43"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "138"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "572947897286701057",
      "id_str" : "572949718764007425",
      "in_reply_to_user_id" : "144119186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "572949718764007425",
      "in_reply_to_status_id" : "572947897286701057",
      "possibly_sensitive" : false,
      "created_at" : "Wed Mar 04 02:40:32 +0000 2015",
      "favorited" : false,
      "full_text" : "@chaotic_iak Oh wat. http://t.co/k8S75T8PI7 says it \"supports 3-level of undos\". I was referring more to mistakes than bifurcating though.",
      "lang" : "en",
      "in_reply_to_screen_name" : "chaotic_iak",
      "in_reply_to_user_id_str" : "144119186"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "572944948124917760"
          ],
          "editableUntil" : "2015-03-04T02:51:35.092Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "68"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "572942728406818816",
      "id_str" : "572944948124917760",
      "in_reply_to_user_id" : "144119186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "572944948124917760",
      "in_reply_to_status_id" : "572942728406818816",
      "created_at" : "Wed Mar 04 02:21:35 +0000 2015",
      "favorited" : false,
      "full_text" : "@chaotic_iak MS Paint supports 3 undos, so it's only so much better.",
      "lang" : "en",
      "in_reply_to_screen_name" : "chaotic_iak",
      "in_reply_to_user_id_str" : "144119186"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "572940800214077440"
          ],
          "editableUntil" : "2015-03-04T02:35:06.153Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "48"
      ],
      "favorite_count" : "0",
      "id_str" : "572940800214077440",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "572940800214077440",
      "created_at" : "Wed Mar 04 02:05:06 +0000 2015",
      "favorited" : false,
      "full_text" : "Protip: Don't practise marathon problems in pen.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "572503356452839426"
          ],
          "editableUntil" : "2015-03-02T21:36:51.433Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "86"
      ],
      "favorite_count" : "0",
      "id_str" : "572503356452839426",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "572503356452839426",
      "created_at" : "Mon Mar 02 21:06:51 +0000 2015",
      "favorited" : false,
      "full_text" : "Now put words of this in a box and make 'O's shaded to find an ESB to go do logically.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "571504343796432897"
          ],
          "editableUntil" : "2015-02-28T03:27:08.255Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "69"
      ],
      "favorite_count" : "0",
      "id_str" : "571504343796432897",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "571504343796432897",
      "created_at" : "Sat Feb 28 02:57:08 +0000 2015",
      "favorited" : false,
      "full_text" : "Each word that this tweet uses can take some noun/pronoun definition.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "571452377968087040"
          ],
          "editableUntil" : "2015-02-28T00:00:38.636Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "129"
      ],
      "favorite_count" : "0",
      "id_str" : "571452377968087040",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "571452377968087040",
      "created_at" : "Fri Feb 27 23:30:38 +0000 2015",
      "favorited" : false,
      "full_text" : "\"sleep around\" and \"mixed greens\" can be interpreted as instructions on how to make the words \"peels\" and \"genres\", respectively.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "571408974894903296"
          ],
          "editableUntil" : "2015-02-27T21:08:10.537Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "571408974894903296",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "571408974894903296",
      "created_at" : "Fri Feb 27 20:38:10 +0000 2015",
      "favorited" : false,
      "full_text" : "The picture of that dress was posted for the 1st time less than 2 days ago, yet everyone has seen it now. That is WAY more incredible to me.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "571141081892556800"
          ],
          "editableUntil" : "2015-02-27T03:23:39.868Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "projectyl",
            "screen_name" : "projectyl",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "14076574",
            "id" : "14076574"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/vgwTLDI0H1",
            "expanded_url" : "https://jacoblance.wordpress.com/2015/02/23/three-metapuzzles/",
            "display_url" : "jacoblance.wordpress.com/2015/02/23/thr…",
            "indices" : [
              "84",
              "107"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "107"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "571137975213432833",
      "id_str" : "571141081892556800",
      "in_reply_to_user_id" : "14076574",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "571141081892556800",
      "in_reply_to_status_id" : "571137975213432833",
      "possibly_sensitive" : false,
      "created_at" : "Fri Feb 27 02:53:39 +0000 2015",
      "favorited" : false,
      "full_text" : "@projectyl Yup! You may or may not have already seen three other metas I made here: https://t.co/vgwTLDI0H1",
      "lang" : "en",
      "in_reply_to_screen_name" : "projectyl",
      "in_reply_to_user_id_str" : "14076574"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "571116837980790784"
          ],
          "editableUntil" : "2015-02-27T01:47:19.669Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "89"
      ],
      "favorite_count" : "0",
      "id_str" : "571116837980790784",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "571116837980790784",
      "created_at" : "Fri Feb 27 01:17:19 +0000 2015",
      "favorited" : false,
      "full_text" : "Here's another meta, words are order:\nBACKYARDS\nMANYFOLD\nOVERPAYS\nSUNDAY\nTRYSTED\nOVERLAYS",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "569991163798822912"
          ],
          "editableUntil" : "2015-02-23T23:14:18.030Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "67"
      ],
      "favorite_count" : "0",
      "id_str" : "569991163798822912",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "569991163798822912",
      "created_at" : "Mon Feb 23 22:44:18 +0000 2015",
      "favorited" : false,
      "full_text" : "The shortest game of United Square possible is a mere 8 moves long.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "569968042316316672"
          ],
          "editableUntil" : "2015-02-23T21:42:25.439Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "136"
      ],
      "favorite_count" : "0",
      "id_str" : "569968042316316672",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "569968042316316672",
      "created_at" : "Mon Feb 23 21:12:25 +0000 2015",
      "favorited" : false,
      "full_text" : "Can anyone come up with two words which contain synonyms of each other within them? The best I can get is \"vari[ant]\" and \"[form]icidae\"",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "569658399484305408"
          ],
          "editableUntil" : "2015-02-23T01:12:00.835Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "55"
      ],
      "favorite_count" : "0",
      "id_str" : "569658399484305408",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "569658399484305408",
      "created_at" : "Mon Feb 23 00:42:00 +0000 2015",
      "favorited" : false,
      "full_text" : "Would the hanging tree be found in the hanging gardens?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "569328333978271744"
          ],
          "editableUntil" : "2015-02-22T03:20:27.086Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "133"
      ],
      "favorite_count" : "0",
      "id_str" : "569328333978271744",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "569328333978271744",
      "created_at" : "Sun Feb 22 02:50:27 +0000 2015",
      "favorited" : false,
      "full_text" : "\"uninflated\" and \"reprimanding\" can be interpreted as instructions on how to make the words \"flaunted\" and \"repriming\", respectively.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "568881416504795136"
          ],
          "editableUntil" : "2015-02-20T21:44:33.657Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "55"
      ],
      "favorite_count" : "0",
      "id_str" : "568881416504795136",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "568881416504795136",
      "created_at" : "Fri Feb 20 21:14:33 +0000 2015",
      "favorited" : false,
      "full_text" : "Please anagram all second letters. (Two word adjective)",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "568564526809022464"
          ],
          "editableUntil" : "2015-02-20T00:45:21.266Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "568564526809022464",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "568564526809022464",
      "created_at" : "Fri Feb 20 00:15:21 +0000 2015",
      "favorited" : false,
      "full_text" : "In puzzles in which 100 perfect logicians get captured and threatened unless they perform some task, are such scandals called \"Logic-gates\"?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "568554746396717056"
          ],
          "editableUntil" : "2015-02-20T00:06:29.434Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "107"
      ],
      "favorite_count" : "1",
      "id_str" : "568554746396717056",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "568554746396717056",
      "created_at" : "Thu Feb 19 23:36:29 +0000 2015",
      "favorited" : false,
      "full_text" : "During the winter, so many people openly wear Uggs and leggings, but I thought that bootlegging is illegal!",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "567521368745705473"
          ],
          "editableUntil" : "2015-02-17T03:40:13.003Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "68"
      ],
      "favorite_count" : "0",
      "id_str" : "567521368745705473",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "567521368745705473",
      "created_at" : "Tue Feb 17 03:10:13 +0000 2015",
      "favorited" : false,
      "full_text" : "Now I, Jack L. Lance, utilizing pi, create words for digit mnemonic.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "567043439607283712"
          ],
          "editableUntil" : "2015-02-15T20:01:05.817Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "http://t.co/pHtbN5daD7",
            "expanded_url" : "http://gyazo.com/07d37e2bac6b053b3088170de8ddd76e",
            "display_url" : "gyazo.com/07d37e2bac6b05…",
            "indices" : [
              "75",
              "97"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "97"
      ],
      "favorite_count" : "0",
      "id_str" : "567043439607283712",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "567043439607283712",
      "possibly_sensitive" : false,
      "created_at" : "Sun Feb 15 19:31:05 +0000 2015",
      "favorited" : false,
      "full_text" : "Look at my previous tweet first. \nHere's a spoiler, in case you didn't it: http://t.co/pHtbN5daD7",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "567013905730637824"
          ],
          "editableUntil" : "2015-02-15T18:03:44.392Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "115"
      ],
      "favorite_count" : "1",
      "id_str" : "567013905730637824",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "567013905730637824",
      "created_at" : "Sun Feb 15 17:33:44 +0000 2015",
      "favorited" : false,
      "full_text" : "Put words in this sentence inside box of height eight w/ seven integers in it. //Note that punctuation is included.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "566790036604354560"
          ],
          "editableUntil" : "2015-02-15T03:14:09.833Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "115"
      ],
      "favorite_count" : "0",
      "id_str" : "566790036604354560",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "566790036604354560",
      "created_at" : "Sun Feb 15 02:44:09 +0000 2015",
      "favorited" : false,
      "full_text" : "The words \"Odd\" and \"Impaired\" are related words in two entirely different senses. Same with \"Number\" and \"Single\".",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "566739206651666432"
          ],
          "editableUntil" : "2015-02-14T23:52:11.028Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "22"
      ],
      "favorite_count" : "0",
      "id_str" : "566739206651666432",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "566739206651666432",
      "created_at" : "Sat Feb 14 23:22:11 +0000 2015",
      "favorited" : false,
      "full_text" : "P.I.HUNT 1 in a month!",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "566420454798540800"
          ],
          "editableUntil" : "2015-02-14T02:45:34.664Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "46"
      ],
      "favorite_count" : "0",
      "id_str" : "566420454798540800",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "566420454798540800",
      "created_at" : "Sat Feb 14 02:15:34 +0000 2015",
      "favorited" : false,
      "full_text" : "All the vowels in this occur in equal amounts.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "566072839405854720"
          ],
          "editableUntil" : "2015-02-13T03:44:16.696Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "135"
      ],
      "favorite_count" : "0",
      "id_str" : "566072839405854720",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "566072839405854720",
      "created_at" : "Fri Feb 13 03:14:16 +0000 2015",
      "favorited" : false,
      "full_text" : "Hmm.. If you leave twitter open in a tab, my deleted tweets won't delete. If you see a lot of tweets by me you can just refresh, sorry!",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "566063472975564801"
          ],
          "editableUntil" : "2015-02-13T03:07:03.565Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "56"
      ],
      "favorite_count" : "1",
      "id_str" : "566063472975564801",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "566063472975564801",
      "created_at" : "Fri Feb 13 02:37:03 +0000 2015",
      "favorited" : false,
      "full_text" : "If a trickster has tricks, what does a grandmaster have?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "564100825601949698"
          ],
          "editableUntil" : "2015-02-07T17:08:11.967Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "81"
      ],
      "favorite_count" : "0",
      "id_str" : "564100825601949698",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "564100825601949698",
      "created_at" : "Sat Feb 07 16:38:11 +0000 2015",
      "favorited" : false,
      "full_text" : "The word \"has\" is a conjugated form of the same verb in both English and Spanish.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "563892847024160768"
          ],
          "editableUntil" : "2015-02-07T03:21:46.010Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "115"
      ],
      "favorite_count" : "0",
      "id_str" : "563892847024160768",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "563892847024160768",
      "created_at" : "Sat Feb 07 02:51:46 +0000 2015",
      "favorited" : false,
      "full_text" : "Having an albatross on your neck means metaphorically that you have a burden and literally that you have a bird on.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "563528923779067905"
          ],
          "editableUntil" : "2015-02-06T03:15:39.947Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "111"
      ],
      "favorite_count" : "0",
      "id_str" : "563528923779067905",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "563528923779067905",
      "created_at" : "Fri Feb 06 02:45:39 +0000 2015",
      "favorited" : false,
      "full_text" : "//However they are also very interesting\n\"Shuts\" = \"Such\"\n\"Apple\" = \"Lap\"\n\"Jabbed\" = \"Badge\"\n\"Sang\" =/= \"Gains\"",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "563517444505874432"
          ],
          "editableUntil" : "2015-02-06T02:30:03.075Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "103"
      ],
      "favorite_count" : "0",
      "id_str" : "563517444505874432",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "563517444505874432",
      "created_at" : "Fri Feb 06 02:00:03 +0000 2015",
      "favorited" : false,
      "full_text" : "\"Nutty spoken English\" = \"Listening tone, kapeesh?\" \n//Wow phonetic anagrams are harder than I thought.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "562802659166806016"
          ],
          "editableUntil" : "2015-02-04T03:09:44.970Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "71"
      ],
      "favorite_count" : "0",
      "id_str" : "562802659166806016",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "562802659166806016",
      "created_at" : "Wed Feb 04 02:39:44 +0000 2015",
      "favorited" : false,
      "full_text" : "To know where you are in a [story] line, you need to have [e]xposition.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "562759849617149953"
          ],
          "editableUntil" : "2015-02-04T00:19:38.378Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "60"
      ],
      "favorite_count" : "0",
      "id_str" : "562759849617149953",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "562759849617149953",
      "created_at" : "Tue Feb 03 23:49:38 +0000 2015",
      "favorited" : false,
      "full_text" : "Stock a grid to find an awesome latin square //{A,E,I,O,U,Y}",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "562738435543539712"
          ],
          "editableUntil" : "2015-02-03T22:54:32.865Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "85"
      ],
      "favorite_count" : "0",
      "id_str" : "562738435543539712",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "562738435543539712",
      "created_at" : "Tue Feb 03 22:24:32 +0000 2015",
      "favorited" : false,
      "full_text" : "Position into a grid and then color 'O's black to create a masyu. Go ahead and do it.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "561582064836018176"
          ],
          "editableUntil" : "2015-01-31T18:19:32.604Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "134"
      ],
      "favorite_count" : "0",
      "id_str" : "561582064836018176",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "561582064836018176",
      "created_at" : "Sat Jan 31 17:49:32 +0000 2015",
      "favorited" : false,
      "full_text" : "Word products are much more fun than word sums. \n(e.g. JACK= 10*1*3*11 = 330)\nCan you find 2016? Factorials from 4! to 11!? 9,000,000?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "558438386957307906"
          ],
          "editableUntil" : "2015-01-23T02:07:41.391Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "61"
      ],
      "favorite_count" : "0",
      "id_str" : "558438386957307906",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "558438386957307906",
      "created_at" : "Fri Jan 23 01:37:41 +0000 2015",
      "favorited" : false,
      "full_text" : "In England, money you use to pay an expense is your ex-pence.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "557722131350704128"
          ],
          "editableUntil" : "2015-01-21T02:41:32.747Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "120"
      ],
      "favorite_count" : "0",
      "id_str" : "557722131350704128",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "557722131350704128",
      "created_at" : "Wed Jan 21 02:11:32 +0000 2015",
      "favorited" : false,
      "full_text" : "The address of the State of the Union (w/ capitals) address is at the Capitol in the capital of the union of the states.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "557368782931628032"
          ],
          "editableUntil" : "2015-01-20T03:17:27.919Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "Puzzfeed",
            "indices" : [
              "98",
              "107"
            ]
          },
          {
            "text" : "Mysteryhunt",
            "indices" : [
              "108",
              "120"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "120"
      ],
      "favorite_count" : "3",
      "id_str" : "557368782931628032",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "557368782931628032",
      "created_at" : "Tue Jan 20 02:47:27 +0000 2015",
      "favorited" : false,
      "full_text" : "You won't believe the 7 things I tried to feed Cthulhu:\nSouls\nSoups\nSodas\nSocks\nSours\nSofas\nSongs\n#Puzzfeed #Mysteryhunt",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "557354669102878721"
          ],
          "editableUntil" : "2015-01-20T02:21:22.920Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Anand Sarwate",
            "screen_name" : "ergodicwalk",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "2330768095",
            "id" : "2330768095"
          },
          {
            "name" : "Molly",
            "screen_name" : "mollishka",
            "indices" : [
              "13",
              "23"
            ],
            "id_str" : "24627348",
            "id" : "24627348"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "91"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "557336950089457664",
      "id_str" : "557354669102878721",
      "in_reply_to_user_id" : "2330768095",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "557354669102878721",
      "in_reply_to_status_id" : "557336950089457664",
      "created_at" : "Tue Jan 20 01:51:22 +0000 2015",
      "favorited" : false,
      "full_text" : "@ergodicwalk @mollishka The phrase \"HALIBUT that BASS\" was in the puzzle \"Feeling Bluefin\".",
      "lang" : "en",
      "in_reply_to_screen_name" : "ergodicwalk",
      "in_reply_to_user_id_str" : "2330768095"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "556928605088129024"
          ],
          "editableUntil" : "2015-01-18T22:08:21.343Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "137"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "556864618425892864",
      "id_str" : "556928605088129024",
      "in_reply_to_user_id" : "144119186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "556928605088129024",
      "in_reply_to_status_id" : "556864618425892864",
      "created_at" : "Sun Jan 18 21:38:21 +0000 2015",
      "favorited" : false,
      "full_text" : "@chaotic_iak I'm on \"Test Solution, Please Ignore\", which is the reddit-based team. we solved 109 puzzles, but way better than last year.",
      "lang" : "en",
      "in_reply_to_screen_name" : "chaotic_iak",
      "in_reply_to_user_id_str" : "144119186"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "556851210301751297"
          ],
          "editableUntil" : "2015-01-18T17:00:48.988Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "68"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "556759648737316864",
      "id_str" : "556851210301751297",
      "in_reply_to_user_id" : "144119186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "556851210301751297",
      "in_reply_to_status_id" : "556759648737316864",
      "created_at" : "Sun Jan 18 16:30:48 +0000 2015",
      "favorited" : false,
      "full_text" : "@chaotic_iak I enjoyed \"Polyglot\", which I highly suspect you wrote.",
      "lang" : "en",
      "in_reply_to_screen_name" : "chaotic_iak",
      "in_reply_to_user_id_str" : "144119186"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "555846329579368448"
          ],
          "editableUntil" : "2015-01-15T22:27:46.754Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "75"
      ],
      "favorite_count" : "0",
      "id_str" : "555846329579368448",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "555846329579368448",
      "created_at" : "Thu Jan 15 21:57:46 +0000 2015",
      "favorited" : false,
      "full_text" : "If something is made clear, it either becomes more visible or less visible.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "552968498599972864"
          ],
          "editableUntil" : "2015-01-07T23:52:18.381Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "http://t.co/QGUSNTh2vQ",
            "expanded_url" : "http://i.imgur.com/sfMmSrl.jpg",
            "display_url" : "i.imgur.com/sfMmSrl.jpg",
            "indices" : [
              "21",
              "43"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "43"
      ],
      "favorite_count" : "0",
      "id_str" : "552968498599972864",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "552968498599972864",
      "possibly_sensitive" : false,
      "created_at" : "Wed Jan 07 23:22:18 +0000 2015",
      "favorited" : false,
      "full_text" : "So excited for this. http://t.co/QGUSNTh2vQ",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "552288718137339905"
          ],
          "editableUntil" : "2015-01-06T02:51:06.089Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "137"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "552156387346640896",
      "id_str" : "552288718137339905",
      "in_reply_to_user_id" : "144119186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "552288718137339905",
      "in_reply_to_status_id" : "552156387346640896",
      "created_at" : "Tue Jan 06 02:21:06 +0000 2015",
      "favorited" : false,
      "full_text" : "@chaotic_iak This has three solutions, no? If you replace 4x4 with 2x2 it is unique, or if you don't let similar pieces touch at corners.",
      "lang" : "en",
      "in_reply_to_screen_name" : "chaotic_iak",
      "in_reply_to_user_id_str" : "144119186"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "552232285974429696"
          ],
          "editableUntil" : "2015-01-05T23:06:51.613Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "http://t.co/NSdFWCQACo",
            "expanded_url" : "http://regex.alf.nu/",
            "display_url" : "regex.alf.nu",
            "indices" : [
              "0",
              "22"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "22"
      ],
      "favorite_count" : "0",
      "id_str" : "552232285974429696",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "552232285974429696",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jan 05 22:36:51 +0000 2015",
      "favorited" : false,
      "full_text" : "http://t.co/NSdFWCQACo",
      "lang" : "zxx"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "550392028094541826"
          ],
          "editableUntil" : "2014-12-31T21:14:19.944Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "137"
      ],
      "favorite_count" : "0",
      "id_str" : "550392028094541826",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "550392028094541826",
      "created_at" : "Wed Dec 31 20:44:19 +0000 2014",
      "favorited" : false,
      "full_text" : "Make the number 2015 with 0-6 in any order, concatenation, multiplication, and/or division. (concatenating 1 and 2 gives 12, for example)",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "550365739535052800"
          ],
          "editableUntil" : "2014-12-31T19:29:52.263Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Jack Lance",
            "screen_name" : "Jack_L_Lance",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "2444552670",
            "id" : "2444552670"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "60"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "550344354364391424",
      "id_str" : "550365739535052800",
      "in_reply_to_user_id" : "2444552670",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "550365739535052800",
      "in_reply_to_status_id" : "550344354364391424",
      "created_at" : "Wed Dec 31 18:59:52 +0000 2014",
      "favorited" : false,
      "full_text" : "@Jack_L_Lance Oops, parenthesis are allowed on this one too.",
      "lang" : "en",
      "in_reply_to_screen_name" : "Jack_L_Lance",
      "in_reply_to_user_id_str" : "2444552670"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "550347258966065154"
          ],
          "editableUntil" : "2014-12-31T18:16:26.152Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "137"
      ],
      "favorite_count" : "0",
      "id_str" : "550347258966065154",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "550347258966065154",
      "created_at" : "Wed Dec 31 17:46:26 +0000 2014",
      "favorited" : false,
      "full_text" : "Make the number 2015 with 1-9 in any order, concatenation, multiplication, and/or division. (concatenating 1 and 2 gives 12, for example)",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "550344354364391424"
          ],
          "editableUntil" : "2014-12-31T18:04:53.641Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "92"
      ],
      "favorite_count" : "0",
      "id_str" : "550344354364391424",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "550344354364391424",
      "created_at" : "Wed Dec 31 17:34:53 +0000 2014",
      "favorited" : false,
      "full_text" : "Make 2015 using the numbers 6,5,4,3,2,1,0 in order, and subtraction, addition, or factorials",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "550343134354616320"
          ],
          "editableUntil" : "2014-12-31T18:00:02.768Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "131"
      ],
      "favorite_count" : "0",
      "id_str" : "550343134354616320",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "550343134354616320",
      "created_at" : "Wed Dec 31 17:30:02 +0000 2014",
      "favorited" : false,
      "full_text" : "Now make 2015 using 9 7's and any of PEMDAS. (There are a few ways to do this, you can make it harder by using only PEMDS or PEMAS)",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "550340343242428417"
          ],
          "editableUntil" : "2014-12-31T17:48:57.315Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "101"
      ],
      "favorite_count" : "0",
      "id_str" : "550340343242428417",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "550340343242428417",
      "created_at" : "Wed Dec 31 17:18:57 +0000 2014",
      "favorited" : false,
      "full_text" : "New years countdown: Use the numbers 8,7,6,5,4,3,2,1 in order, along with any of PEMDAS to make 2015!",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "550327940433870848"
          ],
          "editableUntil" : "2014-12-31T16:59:40.255Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "FitzgeraldTeller",
            "screen_name" : "Mathgrant",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1532161137927766016",
            "id" : "1532161137927766016"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/cV4xSLm82h",
            "expanded_url" : "http://plus.google.com/settings",
            "display_url" : "plus.google.com/settings",
            "indices" : [
              "17",
              "39"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "102"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "550325037082091520",
      "id_str" : "550327940433870848",
      "in_reply_to_user_id" : "816686946",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "550327940433870848",
      "in_reply_to_status_id" : "550325037082091520",
      "possibly_sensitive" : false,
      "created_at" : "Wed Dec 31 16:29:40 +0000 2014",
      "favorited" : false,
      "full_text" : "@mathgrant Go to http://t.co/cV4xSLm82h and uncheck everything under \"Receive Notifications\", I think.",
      "lang" : "en",
      "in_reply_to_user_id_str" : "816686946"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "549956909848334336"
          ],
          "editableUntil" : "2014-12-30T16:25:19.670Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "http://t.co/gQcS4hmCnI",
            "expanded_url" : "http://isithuntyet.info",
            "display_url" : "isithuntyet.info",
            "indices" : [
              "0",
              "22"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "22"
      ],
      "favorite_count" : "0",
      "id_str" : "549956909848334336",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "549956909848334336",
      "possibly_sensitive" : false,
      "created_at" : "Tue Dec 30 15:55:19 +0000 2014",
      "favorited" : false,
      "full_text" : "http://t.co/gQcS4hmCnI",
      "lang" : "zxx"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "548969184097345537"
          ],
          "editableUntil" : "2014-12-27T23:00:27.500Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "548969184097345537",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "548969184097345537",
      "created_at" : "Sat Dec 27 22:30:27 +0000 2014",
      "favorited" : false,
      "full_text" : "\"e.g. \"Austin rocks\" is weaker than \"Austin roxxorz\" (note spelling), which is weaker than \"Au5t1N is t3h r0xx0rz\" (note grammar)\"-Wikipedia",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "547786349433344003"
          ],
          "editableUntil" : "2014-12-24T16:40:17.740Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "http://t.co/sMbTmr4BW3",
            "expanded_url" : "http://gyazo.com/b9303e6213182f319d5c3eb57dcb7cad",
            "display_url" : "gyazo.com/b9303e6213182f…",
            "indices" : [
              "16",
              "38"
            ]
          },
          {
            "url" : "http://t.co/kioTMYzjpj",
            "expanded_url" : "http://gyazo.com/51216f4a18d351864362708110530aaf",
            "display_url" : "gyazo.com/51216f4a18d351…",
            "indices" : [
              "39",
              "61"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "61"
      ],
      "favorite_count" : "0",
      "id_str" : "547786349433344003",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "547786349433344003",
      "possibly_sensitive" : false,
      "created_at" : "Wed Dec 24 16:10:17 +0000 2014",
      "favorited" : false,
      "full_text" : "Prisms are fun:\nhttp://t.co/sMbTmr4BW3\nhttp://t.co/kioTMYzjpj",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "547190271147278336"
          ],
          "editableUntil" : "2014-12-23T01:11:41.602Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "http://t.co/MLSRHAXMN4",
            "expanded_url" : "http://gyazo.com/88a1d73a18d70d827a52a45c552bcd2e",
            "display_url" : "gyazo.com/88a1d73a18d70d…",
            "indices" : [
              "40",
              "62"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "62"
      ],
      "favorite_count" : "0",
      "id_str" : "547190271147278336",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "547190271147278336",
      "possibly_sensitive" : false,
      "created_at" : "Tue Dec 23 00:41:41 +0000 2014",
      "favorited" : false,
      "full_text" : "Translated my contacts into foodtongue: http://t.co/MLSRHAXMN4",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "547099704673447936"
          ],
          "editableUntil" : "2014-12-22T19:11:48.872Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "69"
      ],
      "favorite_count" : "0",
      "id_str" : "547099704673447936",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "547099704673447936",
      "created_at" : "Mon Dec 22 18:41:48 +0000 2014",
      "favorited" : false,
      "full_text" : "The word \"eagle\" is phonetically contained within the word \"seagull\".",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "544982570664873984"
          ],
          "editableUntil" : "2014-12-16T22:59:04.790Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "0",
      "id_str" : "544982570664873984",
      "in_reply_to_user_id" : "144119186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "544982570664873984",
      "created_at" : "Tue Dec 16 22:29:04 +0000 2014",
      "favorited" : false,
      "full_text" : "@chaotic_iak IK (+1) --&gt; JL",
      "lang" : "nl",
      "in_reply_to_screen_name" : "chaotic_iak",
      "in_reply_to_user_id_str" : "144119186"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "544186246034391040"
          ],
          "editableUntil" : "2014-12-14T18:14:46.203Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "31"
      ],
      "favorite_count" : "0",
      "id_str" : "544186246034391040",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "544186246034391040",
      "created_at" : "Sun Dec 14 17:44:46 +0000 2014",
      "favorited" : false,
      "full_text" : "An update keeps you up to date.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "541262941556080641"
          ],
          "editableUntil" : "2014-12-06T16:38:36.103Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "FitzgeraldTeller",
            "screen_name" : "Mathgrant",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1532161137927766016",
            "id" : "1532161137927766016"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/qFHm6I4FFa",
            "expanded_url" : "http://gyazo.com/2a937b52555276e4a731cbac62be7bae",
            "display_url" : "gyazo.com/2a937b52555276…",
            "indices" : [
              "116",
              "138"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "138"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "541070378354110465",
      "id_str" : "541262941556080641",
      "in_reply_to_user_id" : "816686946",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "541262941556080641",
      "in_reply_to_status_id" : "541070378354110465",
      "possibly_sensitive" : false,
      "created_at" : "Sat Dec 06 16:08:36 +0000 2014",
      "favorited" : false,
      "full_text" : "@mathgrant :( \nWell, as long as you're still in the world of puzzle-solving, here is my tribute to all you've done: http://t.co/qFHm6I4FFa",
      "lang" : "en",
      "in_reply_to_user_id_str" : "816686946"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "540702845130268672"
          ],
          "editableUntil" : "2014-12-05T03:32:58.709Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "540693736796078081",
      "id_str" : "540702845130268672",
      "in_reply_to_user_id" : "144119186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "540702845130268672",
      "in_reply_to_status_id" : "540693736796078081",
      "created_at" : "Fri Dec 05 03:02:58 +0000 2014",
      "favorited" : false,
      "full_text" : "@chaotic_iak This phrase contains in it a hundred letters and is placed in a grid which there lives a cool nifty hitori to be solved, whoa!",
      "lang" : "en",
      "in_reply_to_screen_name" : "chaotic_iak",
      "in_reply_to_user_id_str" : "144119186"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "540685845460971521"
          ],
          "editableUntil" : "2014-12-05T02:25:25.672Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "126"
      ],
      "favorite_count" : "0",
      "id_str" : "540685845460971521",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "540685845460971521",
      "created_at" : "Fri Dec 05 01:55:25 +0000 2014",
      "favorited" : false,
      "full_text" : "This phrase contains in it a hundred letters and is placed in a grid which there lays a huge breezy hitori to be solved, by JL",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "540638909844037632"
          ],
          "editableUntil" : "2014-12-04T23:18:55.349Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "FitzgeraldTeller",
            "screen_name" : "Mathgrant",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1532161137927766016",
            "id" : "1532161137927766016"
          },
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "11",
              "23"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          },
          {
            "name" : "Joseph DeVincentis",
            "screen_name" : "_dev_joe",
            "indices" : [
              "24",
              "33"
            ],
            "id_str" : "216902496",
            "id" : "216902496"
          },
          {
            "name" : "Adam R. Wood",
            "screen_name" : "TheZotmeister",
            "indices" : [
              "34",
              "48"
            ],
            "id_str" : "508129916",
            "id" : "508129916"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "117"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "540347889311309825",
      "id_str" : "540638909844037632",
      "in_reply_to_user_id" : "816686946",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "540638909844037632",
      "in_reply_to_status_id" : "540347889311309825",
      "created_at" : "Thu Dec 04 22:48:55 +0000 2014",
      "favorited" : false,
      "full_text" : "@mathgrant @chaotic_iak @_dev_joe @TheZotmeister I'd try it sometime. Just made an account with username \"jacklance\".",
      "lang" : "en",
      "in_reply_to_user_id_str" : "816686946"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "540344465668722688"
          ],
          "editableUntil" : "2014-12-04T03:48:54.387Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "46"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "540120789513547776",
      "id_str" : "540344465668722688",
      "in_reply_to_user_id" : "144119186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "540344465668722688",
      "in_reply_to_status_id" : "540120789513547776",
      "created_at" : "Thu Dec 04 03:18:54 +0000 2014",
      "favorited" : false,
      "full_text" : "@chaotic_iak I'm hooked. (just like the fish?)",
      "lang" : "en",
      "in_reply_to_screen_name" : "chaotic_iak",
      "in_reply_to_user_id_str" : "144119186"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "539510005964500992"
          ],
          "editableUntil" : "2014-12-01T20:33:03.690Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "FitzgeraldTeller",
            "screen_name" : "Mathgrant",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1532161137927766016",
            "id" : "1532161137927766016"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "138"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "539472791817691136",
      "id_str" : "539510005964500992",
      "in_reply_to_user_id" : "816686946",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "539510005964500992",
      "in_reply_to_status_id" : "539472791817691136",
      "created_at" : "Mon Dec 01 20:03:03 +0000 2014",
      "favorited" : false,
      "full_text" : "@mathgrant OK\nNew:\nFactorial (integer num) {\nIf num is nonzero then run:\nRecurse and then print\nProduct of the int\ntimes factorial(num-1)}",
      "lang" : "en",
      "in_reply_to_user_id_str" : "816686946"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "539456064992071680"
          ],
          "editableUntil" : "2014-12-01T16:58:43.160Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/FY2NNpfS51",
            "expanded_url" : "http://codeforces.com/contests/492",
            "display_url" : "codeforces.com/contests/492",
            "indices" : [
              "13",
              "35"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "65"
      ],
      "favorite_count" : "0",
      "id_str" : "539456064992071680",
      "in_reply_to_user_id" : "144119186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "539456064992071680",
      "possibly_sensitive" : false,
      "created_at" : "Mon Dec 01 16:28:43 +0000 2014",
      "favorited" : false,
      "full_text" : "@chaotic_iak http://t.co/FY2NNpfS51 Codeforces 492nd contest now!",
      "lang" : "en",
      "in_reply_to_screen_name" : "chaotic_iak",
      "in_reply_to_user_id_str" : "144119186"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "539425436590419968"
          ],
          "editableUntil" : "2014-12-01T14:57:00.780Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "539425436590419968",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "539425436590419968",
      "created_at" : "Mon Dec 01 14:27:00 +0000 2014",
      "favorited" : false,
      "full_text" : "Logic in poem:\nThe only lie in this poem is line 2\nNo, line 4 is also not true\nLine 2 is a lie\nAnd so is line 5\nLine 1 is a blatant lie too",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "539423566232817665"
          ],
          "editableUntil" : "2014-12-01T14:49:34.852Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "539423566232817665",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "539423566232817665",
      "created_at" : "Mon Dec 01 14:19:34 +0000 2014",
      "favorited" : false,
      "full_text" : "Proof in poem:\nIf rt(2) was said rationally\nIn simplest form a to b\na's square's half of b's\nSo halve both of these\nThe ratio's smaller QED",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "539421068365430785"
          ],
          "editableUntil" : "2014-12-01T14:39:39.314Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "539421068365430785",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "539421068365430785",
      "created_at" : "Mon Dec 01 14:09:39 +0000 2014",
      "favorited" : false,
      "full_text" : "Coding in poem:\nInput an integer n \nFor i from 2 to n, then:\n     If n mod i is none\n     Print out \"We are done\"\nElse do the for loop again",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "539226303460036608"
          ],
          "editableUntil" : "2014-12-01T01:45:43.742Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "111"
      ],
      "favorite_count" : "0",
      "id_str" : "539226303460036608",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "539226303460036608",
      "created_at" : "Mon Dec 01 01:15:43 +0000 2014",
      "favorited" : false,
      "full_text" : "I think that that that that \"that\" that appeared second in this sentence meant might be difficult to interpret.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "539174706566664194"
          ],
          "editableUntil" : "2014-11-30T22:20:42.084Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "111"
      ],
      "favorite_count" : "0",
      "id_str" : "539174706566664194",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "539174706566664194",
      "created_at" : "Sun Nov 30 21:50:42 +0000 2014",
      "favorited" : false,
      "full_text" : "That feeling when you just spent an hour trying to figure out why in the world \"isValidSqaure\" is not in scope.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "538381623402954753"
          ],
          "editableUntil" : "2014-11-28T17:49:16.323Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "109"
      ],
      "favorite_count" : "0",
      "id_str" : "538381623402954753",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "538381623402954753",
      "created_at" : "Fri Nov 28 17:19:16 +0000 2014",
      "favorited" : false,
      "full_text" : "BLACK L _ _ _ _, L _ _ _ _ S _ _ _, S _ _ _ B _ _ _ _ _ _ _, B _ _ _ _ _ _ _ C _ _ _ _ _, C _ _ _ _ _ FRIDAY.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "537964271314161664"
          ],
          "editableUntil" : "2014-11-27T14:10:51.831Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "48"
      ],
      "favorite_count" : "0",
      "id_str" : "537964271314161664",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "537964271314161664",
      "created_at" : "Thu Nov 27 13:40:51 +0000 2014",
      "favorited" : false,
      "full_text" : "Also note that it has each letter at least once.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "537964186329186304"
          ],
          "editableUntil" : "2014-11-27T14:10:31.569Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "137"
      ],
      "favorite_count" : "0",
      "id_str" : "537964186329186304",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "537964186329186304",
      "created_at" : "Thu Nov 27 13:40:31 +0000 2014",
      "favorited" : false,
      "full_text" : "URAQT\nURNXLNC\nURABUT\nURNIDLNTT\n\nYOYOY\nNFRICU\nIMCNWRDVS\nNIMNVSFU\n\nURNHL\nSURADAT\nUFFREINU\nGURLIC\n\nYOYOY\nNFRUAPR\nIMCNWRNNME\nEZSABCTC\nNIMJSNU",
      "lang" : "fi"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "537961430633684993"
          ],
          "editableUntil" : "2014-11-27T13:59:34.560Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "53"
      ],
      "favorite_count" : "0",
      "id_str" : "537961430633684993",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "537961430633684993",
      "created_at" : "Thu Nov 27 13:29:34 +0000 2014",
      "favorited" : false,
      "full_text" : "The next tweet is a song in less than 140 characters.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "537442928738971648"
          ],
          "editableUntil" : "2014-11-26T03:39:14.075Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "537442928738971648",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "537442928738971648",
      "created_at" : "Wed Nov 26 03:09:14 +0000 2014",
      "favorited" : false,
      "full_text" : "For getting along with others, 25% of people rated themselves in the top 1%. For driving skill, 93% of the US put themselves in the top 50%",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "537083684600705026"
          ],
          "editableUntil" : "2014-11-25T03:51:43.598Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "58"
      ],
      "favorite_count" : "0",
      "id_str" : "537083684600705026",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "537083684600705026",
      "created_at" : "Tue Nov 25 03:21:43 +0000 2014",
      "favorited" : false,
      "full_text" : "You can't say \"Dynamite? DYNAMITE!!!\" without \"Might die\".",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "535263180768169984"
          ],
          "editableUntil" : "2014-11-20T03:17:41.661Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "69"
      ],
      "favorite_count" : "0",
      "id_str" : "535263180768169984",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "535263180768169984",
      "created_at" : "Thu Nov 20 02:47:41 +0000 2014",
      "favorited" : false,
      "full_text" : "Oops, I should not use \"//\" for line break if I use it for commenting",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "535259913405366272"
          ],
          "editableUntil" : "2014-11-20T03:04:42.661Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "90"
      ],
      "favorite_count" : "0",
      "id_str" : "535259913405366272",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "535259913405366272",
      "created_at" : "Thu Nov 20 02:34:42 +0000 2014",
      "favorited" : false,
      "full_text" : "(cont.) What's your deal? You just cut them out and shuffle through // You're a wild card.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "535259736435064832"
          ],
          "editableUntil" : "2014-11-20T03:04:00.468Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "101"
      ],
      "favorite_count" : "0",
      "id_str" : "535259736435064832",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "535259736435064832",
      "created_at" : "Thu Nov 20 02:34:00 +0000 2014",
      "favorited" : false,
      "full_text" : "All the guys in the club have diamonds paid (spade) for you // But you're just playing with hearts //",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "534780094418792448"
          ],
          "editableUntil" : "2014-11-18T19:18:04.900Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "31"
      ],
      "favorite_count" : "0",
      "id_str" : "534780094418792448",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "534780094418792448",
      "created_at" : "Tue Nov 18 18:48:04 +0000 2014",
      "favorited" : false,
      "full_text" : "\"Unity\" begins with \"you 'n' I\"",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "534455013712883713"
          ],
          "editableUntil" : "2014-11-17T21:46:19.620Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "http://t.co/SbFGKvNKwL",
            "expanded_url" : "http://gyazo.com/eb937fdae616589e8cd01170de48a7d1",
            "display_url" : "gyazo.com/eb937fdae61658…",
            "indices" : [
              "34",
              "56"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "136"
      ],
      "favorite_count" : "0",
      "id_str" : "534455013712883713",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "534455013712883713",
      "possibly_sensitive" : false,
      "created_at" : "Mon Nov 17 21:16:19 +0000 2014",
      "favorited" : false,
      "full_text" : "Most hilarious spam award goes to http://t.co/SbFGKvNKwL\nOops, looks like some one had a bug in the code.\nThe comment goes on for pages.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "533694416301486081"
          ],
          "editableUntil" : "2014-11-15T19:23:59.066Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "32"
      ],
      "favorite_count" : "1",
      "id_str" : "533694416301486081",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "533694416301486081",
      "created_at" : "Sat Nov 15 18:53:59 +0000 2014",
      "favorited" : false,
      "full_text" : "Is Silverado a type of Colorado?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "533427793263362048"
          ],
          "editableUntil" : "2014-11-15T01:44:31.180Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "61"
      ],
      "favorite_count" : "0",
      "id_str" : "533427793263362048",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "533427793263362048",
      "created_at" : "Sat Nov 15 01:14:31 +0000 2014",
      "favorited" : false,
      "full_text" : "Oh duh. How did I miss that. It should be called pun-k music.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "533420306153873408"
          ],
          "editableUntil" : "2014-11-15T01:14:46.114Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "109"
      ],
      "favorite_count" : "0",
      "id_str" : "533420306153873408",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "533420306153873408",
      "created_at" : "Sat Nov 15 00:44:46 +0000 2014",
      "favorited" : false,
      "full_text" : "\"You can f your x, that relationship wasn't even functional anyway.\" //Does \"puns\" count as a genre of music?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "532720058485972992"
          ],
          "editableUntil" : "2014-11-13T02:52:14.060Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "http://t.co/J9TOTJbHZw",
            "expanded_url" : "http://gyazo.com/d47c521958f628149eee995e48f2ec86",
            "display_url" : "gyazo.com/d47c521958f628…",
            "indices" : [
              "61",
              "83"
            ]
          },
          {
            "url" : "http://t.co/JrZ2iMEjQY",
            "expanded_url" : "http://gyazo.com/4b689f95361f674e059ec9544eded591",
            "display_url" : "gyazo.com/4b689f95361f67…",
            "indices" : [
              "84",
              "106"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "106"
      ],
      "favorite_count" : "0",
      "id_str" : "532720058485972992",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "532720058485972992",
      "possibly_sensitive" : false,
      "created_at" : "Thu Nov 13 02:22:14 +0000 2014",
      "favorited" : false,
      "full_text" : "The BGA favicon looks very familiar to me for some reason...\nhttp://t.co/J9TOTJbHZw\nhttp://t.co/JrZ2iMEjQY",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "532653131763822592"
          ],
          "editableUntil" : "2014-11-12T22:26:17.486Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "132"
      ],
      "favorite_count" : "1",
      "id_str" : "532653131763822592",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "532653131763822592",
      "created_at" : "Wed Nov 12 21:56:17 +0000 2014",
      "favorited" : false,
      "full_text" : "Pros/Cons of being a literalist:\nCONS:\na person found guilty of a criminal offense.\nPROS:\nPeople who profit engaged in a profession.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "532369444526649346"
          ],
          "editableUntil" : "2014-11-12T03:39:01.178Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "72"
      ],
      "favorite_count" : "0",
      "id_str" : "532369444526649346",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "532369444526649346",
      "created_at" : "Wed Nov 12 03:09:01 +0000 2014",
      "favorited" : false,
      "full_text" : "Casinos can be very addictive, is that why its staff are called dealers?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "532201225291583488"
          ],
          "editableUntil" : "2014-11-11T16:30:34.587Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "134"
      ],
      "favorite_count" : "0",
      "id_str" : "532201225291583488",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "532201225291583488",
      "created_at" : "Tue Nov 11 16:00:34 +0000 2014",
      "favorited" : false,
      "full_text" : "Constant for natural logarithm, or limit of a bank account's growth with continuous compounding. //Finally a non-recursive definition.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "531225590071042049"
          ],
          "editableUntil" : "2014-11-08T23:53:45.024Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "129"
      ],
      "favorite_count" : "0",
      "id_str" : "531225590071042049",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "531225590071042049",
      "created_at" : "Sat Nov 08 23:23:45 +0000 2014",
      "favorited" : false,
      "full_text" : "What's halfway between \"Bluetooth\" and \"Red handed\"? What about \"Black-eye\" and \"White collar\"? \"Yellow-belly\" and \"Blue Jacket\"?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "528983537836646400"
          ],
          "editableUntil" : "2014-11-02T19:24:38.116Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "106"
      ],
      "favorite_count" : "1",
      "id_str" : "528983537836646400",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "528983537836646400",
      "created_at" : "Sun Nov 02 18:54:38 +0000 2014",
      "favorited" : false,
      "full_text" : "If you haven't learned Rubik's cube notation by now, then you've been, to be upfront, downright left back.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "527985647571976193"
          ],
          "editableUntil" : "2014-10-31T01:19:22.537Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "527985647571976193",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "527985647571976193",
      "created_at" : "Fri Oct 31 00:49:22 +0000 2014",
      "favorited" : false,
      "full_text" : "Fun game: Start with a word of one letter or one phoneme. At each step, change a letter or change a phoneme. How long of a word can you get?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "526048618491678720"
          ],
          "editableUntil" : "2014-10-25T17:02:18.816Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "http://t.co/UYQeLTsocD",
            "expanded_url" : "http://gyazo.com/83f0172951a3a8474f8836bc72ad0ba5",
            "display_url" : "gyazo.com/83f0172951a3a8…",
            "indices" : [
              "81",
              "103"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "103"
      ],
      "favorite_count" : "0",
      "id_str" : "526048618491678720",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "526048618491678720",
      "possibly_sensitive" : false,
      "created_at" : "Sat Oct 25 16:32:18 +0000 2014",
      "favorited" : false,
      "full_text" : "Here is a picture of a famous singer and a completely unrelated famous comedian. http://t.co/UYQeLTsocD",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "525089449433378816"
          ],
          "editableUntil" : "2014-10-23T01:30:55.092Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "107"
      ],
      "favorite_count" : "0",
      "id_str" : "525089449433378816",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "525089449433378816",
      "created_at" : "Thu Oct 23 01:00:55 +0000 2014",
      "favorited" : false,
      "full_text" : "Note: Previous tweet does not take into account subreddits like /r/ainbow which are not words on their own.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "525026170442883072"
          ],
          "editableUntil" : "2014-10-22T21:19:28.205Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "88"
      ],
      "favorite_count" : "0",
      "id_str" : "525026170442883072",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "525026170442883072",
      "created_at" : "Wed Oct 22 20:49:28 +0000 2014",
      "favorited" : false,
      "full_text" : "/r/evolution and /r/emigration are the longest subreddit names which take 'r' backhooks.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "524644957383311360"
          ],
          "editableUntil" : "2014-10-21T20:04:39.929Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "FitzgeraldTeller",
            "screen_name" : "Mathgrant",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1532161137927766016",
            "id" : "1532161137927766016"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "63"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "524640658146226176",
      "id_str" : "524644957383311360",
      "in_reply_to_user_id" : "816686946",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "524644957383311360",
      "in_reply_to_status_id" : "524640658146226176",
      "created_at" : "Tue Oct 21 19:34:39 +0000 2014",
      "favorited" : false,
      "full_text" : "@mathgrant Also works with 5 dice, 7 dice, 8 dice, 9 dice, etc.",
      "lang" : "en",
      "in_reply_to_user_id_str" : "816686946"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "524363854521040896"
          ],
          "editableUntil" : "2014-10-21T01:27:39.784Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "http://t.co/scmHB4wWNe",
            "expanded_url" : "http://jacoblance.wordpress.com/2014/10/21/puzzle-62-pentominous-mastermind/",
            "display_url" : "jacoblance.wordpress.com/2014/10/21/puz…",
            "indices" : [
              "62",
              "84"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "84"
      ],
      "favorite_count" : "0",
      "id_str" : "524363854521040896",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "524363854521040896",
      "possibly_sensitive" : false,
      "created_at" : "Tue Oct 21 00:57:39 +0000 2014",
      "favorited" : false,
      "full_text" : "Mastermind pentominous. FILL IT UP WITTILLY W/ NIFTY PUZZLIN'\nhttp://t.co/scmHB4wWNe",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "524308860274606080"
          ],
          "editableUntil" : "2014-10-20T21:49:08.134Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "89"
      ],
      "favorite_count" : "0",
      "id_str" : "524308860274606080",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "524308860274606080",
      "created_at" : "Mon Oct 20 21:19:08 +0000 2014",
      "favorited" : false,
      "full_text" : "I like 2048. I've even played its variants a couple times too. times 2. times 2. times 2.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "522943225305518080"
          ],
          "editableUntil" : "2014-10-17T03:22:35.385Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "FitzgeraldTeller",
            "screen_name" : "Mathgrant",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1532161137927766016",
            "id" : "1532161137927766016"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "70"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "522940527764066304",
      "id_str" : "522943225305518080",
      "in_reply_to_user_id" : "816686946",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "522943225305518080",
      "in_reply_to_status_id" : "522940527764066304",
      "created_at" : "Fri Oct 17 02:52:35 +0000 2014",
      "favorited" : false,
      "full_text" : "@mathgrant Have you tried turning it off and then turning it on again?",
      "lang" : "en",
      "in_reply_to_user_id_str" : "816686946"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "522745310100332544"
          ],
          "editableUntil" : "2014-10-16T14:16:08.723Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "FitzgeraldTeller",
            "screen_name" : "Mathgrant",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1532161137927766016",
            "id" : "1532161137927766016"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "86"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "522577987150299137",
      "id_str" : "522745310100332544",
      "in_reply_to_user_id" : "816686946",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "522745310100332544",
      "in_reply_to_status_id" : "522577987150299137",
      "created_at" : "Thu Oct 16 13:46:08 +0000 2014",
      "favorited" : false,
      "full_text" : "@mathgrant Each line declares two variables, while also spelling out a word or phrase.",
      "lang" : "en",
      "in_reply_to_user_id_str" : "816686946"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "522561367291990016"
          ],
          "editableUntil" : "2014-10-16T02:05:13.340Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "58"
      ],
      "favorite_count" : "0",
      "id_str" : "522561367291990016",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "522561367291990016",
      "created_at" : "Thu Oct 16 01:35:13 +0000 2014",
      "favorited" : false,
      "full_text" : "double jo, int ed; \nint he, long run;\nstring sa, long for;",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "521810211951378432"
          ],
          "editableUntil" : "2014-10-14T00:20:23.951Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "94"
      ],
      "favorite_count" : "0",
      "id_str" : "521810211951378432",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "521810211951378432",
      "created_at" : "Mon Oct 13 23:50:23 +0000 2014",
      "favorited" : false,
      "full_text" : "Pshh. I'm not addicted to playing on BGA. I can stop Can't Stop anytime I want anytime I want.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "520772420224184320"
          ],
          "editableUntil" : "2014-10-11T03:36:35.122Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "55"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "520769889934389248",
      "id_str" : "520772420224184320",
      "in_reply_to_user_id" : "144119186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "520772420224184320",
      "in_reply_to_status_id" : "520769889934389248",
      "created_at" : "Sat Oct 11 03:06:35 +0000 2014",
      "favorited" : false,
      "full_text" : "@chaotic_iak You have two 'I's in C3 and two 'L's in C7",
      "lang" : "en",
      "in_reply_to_screen_name" : "chaotic_iak",
      "in_reply_to_user_id_str" : "144119186"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "520766790998437888"
          ],
          "editableUntil" : "2014-10-11T03:14:13.010Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "520766790998437888",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "520766790998437888",
      "created_at" : "Sat Oct 11 02:44:13 +0000 2014",
      "favorited" : false,
      "full_text" : "This hitori puzzle's sixty-four letters make a phrase that does convey itself. //Theoretically, max is 11x11 on twitter, but that's so hard.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "520673849407717376"
          ],
          "editableUntil" : "2014-10-10T21:04:54.008Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "69"
      ],
      "favorite_count" : "0",
      "id_str" : "520673849407717376",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "520673849407717376",
      "created_at" : "Fri Oct 10 20:34:54 +0000 2014",
      "favorited" : false,
      "full_text" : "Consecutive consonant count: 6 'n', 5 'c', 4 't', 3 's', 2 'v', 1 'r'",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "520396883903389696"
          ],
          "editableUntil" : "2014-10-10T02:44:20.286Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "http://t.co/Fhtnt92baW",
            "expanded_url" : "http://nutrimatic.org/?q=%22s%5Bou%5Dd%5Bou%5Dk%5Bou%5D%22&go=Go",
            "display_url" : "nutrimatic.org/?q=%22s%5Bou%5…",
            "indices" : [
              "21",
              "43"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "43"
      ],
      "favorite_count" : "0",
      "id_str" : "520396883903389696",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "520396883903389696",
      "possibly_sensitive" : false,
      "created_at" : "Fri Oct 10 02:14:20 +0000 2014",
      "favorited" : false,
      "full_text" : "This page upsets me: http://t.co/Fhtnt92baW",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "520358914974834689"
          ],
          "editableUntil" : "2014-10-10T00:13:27.788Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "FitzgeraldTeller",
            "screen_name" : "Mathgrant",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1532161137927766016",
            "id" : "1532161137927766016"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "520350127425585152",
      "id_str" : "520358914974834689",
      "in_reply_to_user_id" : "816686946",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "520358914974834689",
      "in_reply_to_status_id" : "520350127425585152",
      "created_at" : "Thu Oct 09 23:43:27 +0000 2014",
      "favorited" : false,
      "full_text" : "@mathgrant BIOLOGIC is right. I was pretty constrained with words to get a coherent message, but I liked the substring of LOGIC in this one.",
      "lang" : "en",
      "in_reply_to_user_id_str" : "816686946"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "520345999391612929"
          ],
          "editableUntil" : "2014-10-09T23:22:08.473Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "61"
      ],
      "favorite_count" : "0",
      "id_str" : "520345999391612929",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "520345999391612929",
      "created_at" : "Thu Oct 09 22:52:08 +0000 2014",
      "favorited" : false,
      "full_text" : "Once ordered by consecutive length, initialize its graphemes.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "520059550293315585"
          ],
          "editableUntil" : "2014-10-09T04:23:53.686Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "136"
      ],
      "favorite_count" : "0",
      "id_str" : "520059550293315585",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "520059550293315585",
      "created_at" : "Thu Oct 09 03:53:53 +0000 2014",
      "favorited" : false,
      "full_text" : "Here's something neat. Put every word of 4 letters in a square area downwards in an order so the across entries are all words! How dope!",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "519943393053798400"
          ],
          "editableUntil" : "2014-10-08T20:42:19.642Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "97"
      ],
      "favorite_count" : "0",
      "id_str" : "519943393053798400",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "519943393053798400",
      "created_at" : "Wed Oct 08 20:12:19 +0000 2014",
      "favorited" : false,
      "full_text" : "\"Phonemic\" relates to speaking, and can be broken down into two words which are both spoken into.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "517672065043013633"
          ],
          "editableUntil" : "2014-10-02T14:16:52.845Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Supervocalic",
            "screen_name" : "supervocalic",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "2474042306",
            "id" : "2474042306"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "138"
      ],
      "favorite_count" : "0",
      "id_str" : "517672065043013633",
      "in_reply_to_user_id" : "2474042306",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "517672065043013633",
      "created_at" : "Thu Oct 02 13:46:52 +0000 2014",
      "favorited" : false,
      "full_text" : "@Supervocalic would be cool if it used phonemically distinct vowels, but then again, “Megasupervocally findacator 4000.2” isn’t as catchy.",
      "lang" : "en",
      "in_reply_to_screen_name" : "supervocalic",
      "in_reply_to_user_id_str" : "2474042306"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "517517155693502464"
          ],
          "editableUntil" : "2014-10-02T04:01:19.578Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "102"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "517495502603288576",
      "id_str" : "517517155693502464",
      "in_reply_to_user_id" : "144119186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "517517155693502464",
      "in_reply_to_status_id" : "517495502603288576",
      "created_at" : "Thu Oct 02 03:31:19 +0000 2014",
      "favorited" : false,
      "full_text" : "@chaotic_iak I'm going to guess that this CS class definitely does not stand for Countable Sets class.",
      "lang" : "en",
      "in_reply_to_screen_name" : "chaotic_iak",
      "in_reply_to_user_id_str" : "144119186"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "514795688182702081"
          ],
          "editableUntil" : "2014-09-24T15:47:11.161Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "2",
      "id_str" : "514795688182702081",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "514795688182702081",
      "created_at" : "Wed Sep 24 15:17:11 +0000 2014",
      "favorited" : false,
      "full_text" : "Put this in a six x six box, then solve a hitori.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "514369843165151232"
          ],
          "editableUntil" : "2014-09-23T11:35:01.797Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "FitzgeraldTeller",
            "screen_name" : "Mathgrant",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1532161137927766016",
            "id" : "1532161137927766016"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "95"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "514235608513138688",
      "id_str" : "514369843165151232",
      "in_reply_to_user_id" : "816686946",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "514369843165151232",
      "in_reply_to_status_id" : "514235608513138688",
      "created_at" : "Tue Sep 23 11:05:01 +0000 2014",
      "favorited" : false,
      "full_text" : "@mathgrant What? Does that not require 400 cubes? How many decks are you going to use on that!?",
      "lang" : "en",
      "in_reply_to_user_id_str" : "816686946"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "512351543727632385"
          ],
          "editableUntil" : "2014-09-17T21:55:01.713Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "61"
      ],
      "favorite_count" : "0",
      "id_str" : "512351543727632385",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "512351543727632385",
      "created_at" : "Wed Sep 17 21:25:01 +0000 2014",
      "favorited" : false,
      "full_text" : "This tweet's written so all letters in it have an even total.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "511621404077617152"
          ],
          "editableUntil" : "2014-09-15T21:33:42.855Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "112"
      ],
      "favorite_count" : "1",
      "id_str" : "511621404077617152",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "511621404077617152",
      "created_at" : "Mon Sep 15 21:03:42 +0000 2014",
      "favorited" : false,
      "full_text" : "Does anyone else have a problem with the fact that one of the steps in the Hokey Pokey is to do the Hokey Pokey.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "511466358912335872"
          ],
          "editableUntil" : "2014-09-15T11:17:37.207Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/511466358912335872/photo/1",
            "indices" : [
              "24",
              "46"
            ],
            "url" : "http://t.co/eG04mvRAjZ",
            "media_url" : "http://pbs.twimg.com/media/BxkX8QfIAAAzFOj.png",
            "id_str" : "511466356668366848",
            "id" : "511466356668366848",
            "media_url_https" : "https://pbs.twimg.com/media/BxkX8QfIAAAzFOj.png",
            "sizes" : {
              "large" : {
                "w" : "176",
                "h" : "47",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "176",
                "h" : "47",
                "resize" : "fit"
              },
              "small" : {
                "w" : "176",
                "h" : "47",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "47",
                "h" : "47",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/eG04mvRAjZ"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "46"
      ],
      "favorite_count" : "1",
      "id_str" : "511466358912335872",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "511466358912335872",
      "possibly_sensitive" : false,
      "created_at" : "Mon Sep 15 10:47:37 +0000 2014",
      "favorited" : false,
      "full_text" : "Mathematician problems. http://t.co/eG04mvRAjZ",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/511466358912335872/photo/1",
            "indices" : [
              "24",
              "46"
            ],
            "url" : "http://t.co/eG04mvRAjZ",
            "media_url" : "http://pbs.twimg.com/media/BxkX8QfIAAAzFOj.png",
            "id_str" : "511466356668366848",
            "id" : "511466356668366848",
            "media_url_https" : "https://pbs.twimg.com/media/BxkX8QfIAAAzFOj.png",
            "sizes" : {
              "large" : {
                "w" : "176",
                "h" : "47",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "176",
                "h" : "47",
                "resize" : "fit"
              },
              "small" : {
                "w" : "176",
                "h" : "47",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "47",
                "h" : "47",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/eG04mvRAjZ"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "511301129955966976"
          ],
          "editableUntil" : "2014-09-15T00:21:03.554Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "83"
      ],
      "favorite_count" : "0",
      "id_str" : "511301129955966976",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "511301129955966976",
      "created_at" : "Sun Sep 14 23:51:03 +0000 2014",
      "favorited" : false,
      "full_text" : "You can't spell \"square\" without \"u are\". You can't spell \"diamond\" without \"i am\".",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "509826898357391361"
          ],
          "editableUntil" : "2014-09-10T22:42:59.351Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/509826898357391361/photo/1",
            "indices" : [
              "92",
              "114"
            ],
            "url" : "http://t.co/i9gPj86Kgb",
            "media_url" : "http://pbs.twimg.com/media/BxNE3F1CIAAR8EL.png",
            "id_str" : "509826896071106560",
            "id" : "509826896071106560",
            "media_url_https" : "https://pbs.twimg.com/media/BxNE3F1CIAAR8EL.png",
            "sizes" : {
              "small" : {
                "w" : "512",
                "h" : "512",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "512",
                "h" : "512",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "512",
                "h" : "512",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/i9gPj86Kgb"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "114"
      ],
      "favorite_count" : "0",
      "id_str" : "509826898357391361",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "509826898357391361",
      "possibly_sensitive" : false,
      "created_at" : "Wed Sep 10 22:12:59 +0000 2014",
      "favorited" : false,
      "full_text" : "My mind can't deal with the fact that there are only three distinct colors in this picture. http://t.co/i9gPj86Kgb",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/509826898357391361/photo/1",
            "indices" : [
              "92",
              "114"
            ],
            "url" : "http://t.co/i9gPj86Kgb",
            "media_url" : "http://pbs.twimg.com/media/BxNE3F1CIAAR8EL.png",
            "id_str" : "509826896071106560",
            "id" : "509826896071106560",
            "media_url_https" : "https://pbs.twimg.com/media/BxNE3F1CIAAR8EL.png",
            "sizes" : {
              "small" : {
                "w" : "512",
                "h" : "512",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "512",
                "h" : "512",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "512",
                "h" : "512",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/i9gPj86Kgb"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "509415730086154240"
          ],
          "editableUntil" : "2014-09-09T19:29:09.196Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "projectyl",
            "screen_name" : "projectyl",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "14076574",
            "id" : "14076574"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "509395222443606016",
      "id_str" : "509415730086154240",
      "in_reply_to_user_id" : "14076574",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "509415730086154240",
      "in_reply_to_status_id" : "509395222443606016",
      "created_at" : "Tue Sep 09 18:59:09 +0000 2014",
      "favorited" : false,
      "full_text" : "@projectyl If it's allowed to be fictional,  &amp; \"Sonic Knurkles\" or \"Jark Jark\" sound pretty hilarious, otherwise Dirk Storkton I guess.",
      "lang" : "en",
      "in_reply_to_screen_name" : "projectyl",
      "in_reply_to_user_id_str" : "14076574"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "509074732814446593"
          ],
          "editableUntil" : "2014-09-08T20:54:09.111Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "134"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "508804666042642432",
      "id_str" : "509074732814446593",
      "in_reply_to_user_id" : "144119186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "509074732814446593",
      "in_reply_to_status_id" : "508804666042642432",
      "created_at" : "Mon Sep 08 20:24:09 +0000 2014",
      "favorited" : false,
      "full_text" : "@chaotic_iak You mean if it is from range [p,q] not [0,1]? Then integrals become messy and there is no neat and short formula I think.",
      "lang" : "en",
      "in_reply_to_screen_name" : "chaotic_iak",
      "in_reply_to_user_id_str" : "144119186"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "508614707050471425"
          ],
          "editableUntil" : "2014-09-07T14:26:10.422Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "97"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "508492582821691393",
      "id_str" : "508614707050471425",
      "in_reply_to_user_id" : "144119186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "508614707050471425",
      "in_reply_to_status_id" : "508492582821691393",
      "created_at" : "Sun Sep 07 13:56:10 +0000 2014",
      "favorited" : false,
      "full_text" : "@chaotic_iak In general it is (total number of tails so far +1)/(total number of flips so far +2)",
      "lang" : "en",
      "in_reply_to_screen_name" : "chaotic_iak",
      "in_reply_to_user_id_str" : "144119186"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "503670487025987585"
          ],
          "editableUntil" : "2014-08-24T22:59:36.509Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "137"
      ],
      "favorite_count" : "0",
      "id_str" : "503670487025987585",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "503670487025987585",
      "created_at" : "Sun Aug 24 22:29:36 +0000 2014",
      "favorited" : false,
      "full_text" : "Pride is the most deadly of the 7 sins in Christianity, and the word \"pride\" is now often associated with LGBT.  Interesting coincidence.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "503355079127470080"
          ],
          "editableUntil" : "2014-08-24T02:06:17.406Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "100"
      ],
      "favorite_count" : "0",
      "id_str" : "503355079127470080",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "503355079127470080",
      "created_at" : "Sun Aug 24 01:36:17 +0000 2014",
      "favorited" : false,
      "full_text" : "The word \"taxicab\" is the most redundant word, considering it is a synonym of both \"taxi\" and \"cab\".",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "502840547896463361"
          ],
          "editableUntil" : "2014-08-22T16:01:43.601Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "84"
      ],
      "favorite_count" : "1",
      "id_str" : "502840547896463361",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "502840547896463361",
      "created_at" : "Fri Aug 22 15:31:43 +0000 2014",
      "favorited" : false,
      "full_text" : "The word \"illuminated\" means the same thing even if you only use every third letter.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "502647147029086209"
          ],
          "editableUntil" : "2014-08-22T03:13:13.241Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "78"
      ],
      "favorite_count" : "1",
      "id_str" : "502647147029086209",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "502647147029086209",
      "created_at" : "Fri Aug 22 02:43:13 +0000 2014",
      "favorited" : false,
      "full_text" : "You can't spell \"alone\" without \"one\". You can't say \"together\" without \"two\".",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "501488626237468672"
          ],
          "editableUntil" : "2014-08-18T22:29:40.360Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "79"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "500630224837431296",
      "id_str" : "501488626237468672",
      "in_reply_to_user_id" : "144119186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "501488626237468672",
      "in_reply_to_status_id" : "500630224837431296",
      "created_at" : "Mon Aug 18 21:59:40 +0000 2014",
      "favorited" : false,
      "full_text" : "@chaotic_iak user: JackLance Friend key: 83037_726682ca0a625734b6caa0cd7133165b",
      "lang" : "en",
      "in_reply_to_screen_name" : "chaotic_iak",
      "in_reply_to_user_id_str" : "144119186"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "499676124230582275"
          ],
          "editableUntil" : "2014-08-13T22:27:26.207Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "133"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "499644784647344128",
      "id_str" : "499676124230582275",
      "in_reply_to_user_id" : "144119186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "499676124230582275",
      "in_reply_to_status_id" : "499644784647344128",
      "created_at" : "Wed Aug 13 21:57:26 +0000 2014",
      "favorited" : false,
      "full_text" : "@chaotic_iak ...I just said it because *selfie*/*cell fee*. \nYou avoid the problem if your phone company's plans *sell free* texting.",
      "lang" : "en",
      "in_reply_to_screen_name" : "chaotic_iak",
      "in_reply_to_user_id_str" : "144119186"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "499631121504931840"
          ],
          "editableUntil" : "2014-08-13T19:28:36.721Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "58"
      ],
      "favorite_count" : "1",
      "id_str" : "499631121504931840",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "499631121504931840",
      "created_at" : "Wed Aug 13 18:58:36 +0000 2014",
      "favorited" : false,
      "full_text" : "If you text too many selfies, you get very high cell fees.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "499014368823369728"
          ],
          "editableUntil" : "2014-08-12T02:37:51.423Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "91"
      ],
      "favorite_count" : "1",
      "id_str" : "499014368823369728",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "499014368823369728",
      "created_at" : "Tue Aug 12 02:07:51 +0000 2014",
      "favorited" : false,
      "full_text" : "If a straight beats a pair of queens, you're either playing poker or watching a hate crime.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "498892829327106049"
          ],
          "editableUntil" : "2014-08-11T18:34:54.149Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "51"
      ],
      "favorite_count" : "1",
      "id_str" : "498892829327106049",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "498892829327106049",
      "created_at" : "Mon Aug 11 18:04:54 +0000 2014",
      "favorited" : false,
      "full_text" : "Say 'X' followed by the consonants in my last name.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "497861886629904384"
          ],
          "editableUntil" : "2014-08-08T22:18:18.256Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "46"
      ],
      "favorite_count" : "0",
      "id_str" : "497861886629904384",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "497861886629904384",
      "created_at" : "Fri Aug 08 21:48:18 +0000 2014",
      "favorited" : false,
      "full_text" : "Psychology puts the \"science\" in \"conscience\".",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "497138256342188032"
          ],
          "editableUntil" : "2014-08-06T22:22:51.351Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "FitzgeraldTeller",
            "screen_name" : "Mathgrant",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1532161137927766016",
            "id" : "1532161137927766016"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "497100186280534016",
      "id_str" : "497138256342188032",
      "in_reply_to_user_id" : "816686946",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "497138256342188032",
      "in_reply_to_status_id" : "497100186280534016",
      "created_at" : "Wed Aug 06 21:52:51 +0000 2014",
      "favorited" : false,
      "full_text" : "@mathgrant 15625 and (1,5,625)",
      "lang" : "und",
      "in_reply_to_user_id_str" : "816686946"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "497095824288264192"
          ],
          "editableUntil" : "2014-08-06T19:34:14.761Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "1",
      "id_str" : "497095824288264192",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "497095824288264192",
      "created_at" : "Wed Aug 06 19:04:14 +0000 2014",
      "favorited" : false,
      "full_text" : "The History Channel: Where quality TV is history.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "496825623814627328"
          ],
          "editableUntil" : "2014-08-06T01:40:33.948Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "97"
      ],
      "favorite_count" : "0",
      "id_str" : "496825623814627328",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "496825623814627328",
      "created_at" : "Wed Aug 06 01:10:33 +0000 2014",
      "favorited" : false,
      "full_text" : "Stenography and steganography are opposites. English....why must you do this kind of thing to us?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "496737876533862400"
          ],
          "editableUntil" : "2014-08-05T19:51:53.366Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "59"
      ],
      "favorite_count" : "0",
      "id_str" : "496737876533862400",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "496737876533862400",
      "created_at" : "Tue Aug 05 19:21:53 +0000 2014",
      "favorited" : false,
      "full_text" : "I use second meanings each second I'm meaning to be clever.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "496736226406563840"
          ],
          "editableUntil" : "2014-08-05T19:45:19.945Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "FitzgeraldTeller",
            "screen_name" : "Mathgrant",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1532161137927766016",
            "id" : "1532161137927766016"
          },
          {
            "name" : "Dave Mackey",
            "screen_name" : "davidamackey",
            "indices" : [
              "11",
              "24"
            ],
            "id_str" : "385923651",
            "id" : "385923651"
          },
          {
            "name" : "PennyDellPuzzles.com",
            "screen_name" : "PennyDellPuzzle",
            "indices" : [
              "25",
              "41"
            ],
            "id_str" : "201689168",
            "id" : "201689168"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "80"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "496362736197312512",
      "id_str" : "496736226406563840",
      "in_reply_to_user_id" : "816686946",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "496736226406563840",
      "in_reply_to_status_id" : "496362736197312512",
      "created_at" : "Tue Aug 05 19:15:19 +0000 2014",
      "favorited" : false,
      "full_text" : "@mathgrant @davidamackey @PennyDellPuzzle I guess there really is no \"i\" in team",
      "lang" : "en",
      "in_reply_to_user_id_str" : "816686946"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "481903759748907008"
          ],
          "editableUntil" : "2014-06-25T21:26:24.320Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "FitzgeraldTeller",
            "screen_name" : "Mathgrant",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1532161137927766016",
            "id" : "1532161137927766016"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "137"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "481631958607216640",
      "id_str" : "481903759748907008",
      "in_reply_to_user_id" : "816686946",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "481903759748907008",
      "in_reply_to_status_id" : "481631958607216640",
      "created_at" : "Wed Jun 25 20:56:24 +0000 2014",
      "favorited" : false,
      "full_text" : "@mathgrant Lee Strobel, I admit that I did cheat with nutrimatic though. I love seeing you adding more info while keeping the char limit.",
      "lang" : "en",
      "in_reply_to_user_id_str" : "816686946"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "481804532989440000"
          ],
          "editableUntil" : "2014-06-25T14:52:06.817Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "73"
      ],
      "favorite_count" : "0",
      "id_str" : "481804532989440000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "481804532989440000",
      "created_at" : "Wed Jun 25 14:22:06 +0000 2014",
      "favorited" : false,
      "full_text" : "\"Insert innuendo here.\" is on Wikipedia's list of autological phrases. XD",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "481532241214857217"
          ],
          "editableUntil" : "2014-06-24T20:50:07.399Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "481532241214857217",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "481532241214857217",
      "created_at" : "Tue Jun 24 20:20:07 +0000 2014",
      "favorited" : false,
      "full_text" : "WWW is short for \"World Wide Web\", however, it has 3 times as many syllables. You literally can't get less efficient than that if you tried.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "481250919812583424"
          ],
          "editableUntil" : "2014-06-24T02:12:15.150Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "34"
      ],
      "favorite_count" : "1",
      "id_str" : "481250919812583424",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "481250919812583424",
      "created_at" : "Tue Jun 24 01:42:15 +0000 2014",
      "favorited" : false,
      "full_text" : "William Shakespeare is a Play-Bill",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "471386244774391808"
          ],
          "editableUntil" : "2014-05-27T20:53:33.344Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "53"
      ],
      "favorite_count" : "0",
      "id_str" : "471386244774391808",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "471386244774391808",
      "created_at" : "Tue May 27 20:23:33 +0000 2014",
      "favorited" : false,
      "full_text" : "This is too ambiguous as spoken English is too silly.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "470615959581904897"
          ],
          "editableUntil" : "2014-05-25T17:52:43.043Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "FitzgeraldTeller",
            "screen_name" : "Mathgrant",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1532161137927766016",
            "id" : "1532161137927766016"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "45"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "468489444471742464",
      "id_str" : "470615959581904897",
      "in_reply_to_user_id" : "816686946",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "470615959581904897",
      "in_reply_to_status_id" : "468489444471742464",
      "created_at" : "Sun May 25 17:22:43 +0000 2014",
      "favorited" : false,
      "full_text" : "@mathgrant You could call that a \"Dog pound\".",
      "lang" : "en",
      "in_reply_to_user_id_str" : "816686946"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "461960364603998208"
          ],
          "editableUntil" : "2014-05-01T20:38:28.387Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "104"
      ],
      "favorite_count" : "0",
      "id_str" : "461960364603998208",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "461960364603998208",
      "created_at" : "Thu May 01 20:08:28 +0000 2014",
      "favorited" : false,
      "full_text" : "Similarly (to last post), \"recreational\" and \"re-creational\" are opposites when referring to intercourse",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "458632965569130497"
          ],
          "editableUntil" : "2014-04-22T16:16:34.637Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "122"
      ],
      "favorite_count" : "1",
      "id_str" : "458632965569130497",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "458632965569130497",
      "created_at" : "Tue Apr 22 15:46:34 +0000 2014",
      "favorited" : false,
      "full_text" : "\"Left there\" can be its own opposite, as in \"Everyone but him left there 15 minutes ago, so he is the only one left there\"",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "456743905849905153"
          ],
          "editableUntil" : "2014-04-17T11:10:07.703Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "133"
      ],
      "favorite_count" : "0",
      "id_str" : "456743905849905153",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "456743905849905153",
      "created_at" : "Thu Apr 17 10:40:07 +0000 2014",
      "favorited" : false,
      "full_text" : "If you've heard about \"Game of four\" or \"Size four talk\", how about \"Limit eight minus three speak\" or \"Length thirty fifths tongue\"?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "456179172365570048"
          ],
          "editableUntil" : "2014-04-15T21:46:04.748Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "FitzgeraldTeller",
            "screen_name" : "Mathgrant",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1532161137927766016",
            "id" : "1532161137927766016"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "27"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "454109718567337984",
      "id_str" : "456179172365570048",
      "in_reply_to_user_id" : "816686946",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "456179172365570048",
      "in_reply_to_status_id" : "454109718567337984",
      "created_at" : "Tue Apr 15 21:16:04 +0000 2014",
      "favorited" : false,
      "full_text" : "@mathgrant crypto-currency!",
      "lang" : "en",
      "in_reply_to_user_id_str" : "816686946"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "456146573466935297"
          ],
          "editableUntil" : "2014-04-15T19:36:32.565Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "72"
      ],
      "favorite_count" : "0",
      "id_str" : "456146573466935297",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "456146573466935297",
      "created_at" : "Tue Apr 15 19:06:32 +0000 2014",
      "favorited" : false,
      "full_text" : "forewArd, nErd, bIrd. Really english.... these wOrds are getting absUrd.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1223322221772447745"
          ],
          "editableUntil" : "2020-01-31T19:38:40.555Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/TDYkHqA7Db",
            "expanded_url" : "https://ideone.com/pWAzLE",
            "display_url" : "ideone.com/pWAzLE",
            "indices" : [
              "44",
              "67"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "67"
      ],
      "favorite_count" : "60",
      "id_str" : "1223322221772447745",
      "truncated" : false,
      "retweet_count" : "19",
      "id" : "1223322221772447745",
      "possibly_sensitive" : false,
      "created_at" : "Fri Jan 31 19:08:40 +0000 2020",
      "favorited" : false,
      "full_text" : "There's something VERY wrong with my code:\n\nhttps://t.co/TDYkHqA7Db",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1211846955720232960"
          ],
          "editableUntil" : "2019-12-31T03:40:03.928Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "178"
      ],
      "favorite_count" : "4",
      "id_str" : "1211846955720232960",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1211846955720232960",
      "created_at" : "Tue Dec 31 03:10:03 +0000 2019",
      "favorited" : false,
      "full_text" : "For someone who claims to be a real human being who just always wears a robot costume and definitely not a robot, I have to say the name \"Guy-Man\"uel sure is a little suspicious.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1210390904009379840"
          ],
          "editableUntil" : "2019-12-27T03:14:14.148Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1210390904009379840/photo/1",
            "indices" : [
              "26",
              "49"
            ],
            "url" : "https://t.co/bQBLC6TVvs",
            "media_url" : "http://pbs.twimg.com/media/EMwrrQkWwAAGcS4.png",
            "id_str" : "1210390422037643264",
            "id" : "1210390422037643264",
            "media_url_https" : "https://pbs.twimg.com/media/EMwrrQkWwAAGcS4.png",
            "sizes" : {
              "large" : {
                "w" : "336",
                "h" : "172",
                "resize" : "fit"
              },
              "small" : {
                "w" : "336",
                "h" : "172",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "336",
                "h" : "172",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/bQBLC6TVvs"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "133",
      "id_str" : "1210390904009379840",
      "truncated" : false,
      "retweet_count" : "35",
      "id" : "1210390904009379840",
      "possibly_sensitive" : false,
      "created_at" : "Fri Dec 27 02:44:14 +0000 2019",
      "favorited" : false,
      "full_text" : "Swype keyboard pictionary https://t.co/bQBLC6TVvs",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1210390904009379840/photo/1",
            "indices" : [
              "26",
              "49"
            ],
            "url" : "https://t.co/bQBLC6TVvs",
            "media_url" : "http://pbs.twimg.com/media/EMwrrQkWwAAGcS4.png",
            "id_str" : "1210390422037643264",
            "id" : "1210390422037643264",
            "media_url_https" : "https://pbs.twimg.com/media/EMwrrQkWwAAGcS4.png",
            "sizes" : {
              "large" : {
                "w" : "336",
                "h" : "172",
                "resize" : "fit"
              },
              "small" : {
                "w" : "336",
                "h" : "172",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "336",
                "h" : "172",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/bQBLC6TVvs"
          },
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1210390904009379840/photo/1",
            "indices" : [
              "26",
              "49"
            ],
            "url" : "https://t.co/bQBLC6TVvs",
            "media_url" : "http://pbs.twimg.com/media/EMwrsoPWoAEI3lB.png",
            "id_str" : "1210390445571874817",
            "id" : "1210390445571874817",
            "media_url_https" : "https://pbs.twimg.com/media/EMwrsoPWoAEI3lB.png",
            "sizes" : {
              "small" : {
                "w" : "341",
                "h" : "194",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "341",
                "h" : "194",
                "resize" : "fit"
              },
              "large" : {
                "w" : "341",
                "h" : "194",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/bQBLC6TVvs"
          },
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1210390904009379840/photo/1",
            "indices" : [
              "26",
              "49"
            ],
            "url" : "https://t.co/bQBLC6TVvs",
            "media_url" : "http://pbs.twimg.com/media/EMwrwSdX0AEct6y.png",
            "id_str" : "1210390508444569601",
            "id" : "1210390508444569601",
            "media_url_https" : "https://pbs.twimg.com/media/EMwrwSdX0AEct6y.png",
            "sizes" : {
              "small" : {
                "w" : "343",
                "h" : "172",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "343",
                "h" : "172",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "343",
                "h" : "172",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/bQBLC6TVvs"
          },
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1210390904009379840/photo/1",
            "indices" : [
              "26",
              "49"
            ],
            "url" : "https://t.co/bQBLC6TVvs",
            "media_url" : "http://pbs.twimg.com/media/EMwrydcXYAAvUG4.png",
            "id_str" : "1210390545752875008",
            "id" : "1210390545752875008",
            "media_url_https" : "https://pbs.twimg.com/media/EMwrydcXYAAvUG4.png",
            "sizes" : {
              "small" : {
                "w" : "346",
                "h" : "179",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "346",
                "h" : "179",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "346",
                "h" : "179",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/bQBLC6TVvs"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1207866204863508480"
          ],
          "editableUntil" : "2019-12-20T04:01:58.965Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "projectyl",
            "screen_name" : "projectyl",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "14076574",
            "id" : "14076574"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "128"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1207861318671163392",
      "id_str" : "1207866204863508480",
      "in_reply_to_user_id" : "14076574",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1207866204863508480",
      "in_reply_to_status_id" : "1207861318671163392",
      "created_at" : "Fri Dec 20 03:31:58 +0000 2019",
      "favorited" : false,
      "full_text" : "@projectyl Some random ideas, in alphabetical order so you can see for yourself if they worked well:\nGINOST\nACHIPT\nACDEHR\nCELOOT",
      "lang" : "en",
      "in_reply_to_screen_name" : "projectyl",
      "in_reply_to_user_id_str" : "14076574"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1207656547326873601"
          ],
          "editableUntil" : "2019-12-19T14:08:52.713Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "86"
      ],
      "favorite_count" : "21",
      "id_str" : "1207656547326873601",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1207656547326873601",
      "created_at" : "Thu Dec 19 13:38:52 +0000 2019",
      "favorited" : false,
      "full_text" : "GENETIC CLASSIFICATION\n\nis an anagram of\n\nSCIENCE OF INITIALS \"A\", \"C\", \"G\", &amp; \"T\"",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1204066190332706819"
          ],
          "editableUntil" : "2019-12-09T16:22:04.900Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "109"
      ],
      "favorite_count" : "5",
      "id_str" : "1204066190332706819",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1204066190332706819",
      "created_at" : "Mon Dec 09 15:52:04 +0000 2019",
      "favorited" : false,
      "full_text" : "Concatenating the indices of JL in the alphabet (0-indexed) gives 911.\n\nDoing the same with JACK gives 90210.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1197686166029524992"
          ],
          "editableUntil" : "2019-11-22T01:50:08.571Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Tom Montgomery",
            "screen_name" : "tntmonty",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "60988328",
            "id" : "60988328"
          },
          {
            "name" : "benji ᓚᘏᗢ",
            "screen_name" : "birdsarecommies",
            "indices" : [
              "10",
              "26"
            ],
            "id_str" : "3244669657",
            "id" : "3244669657"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "194"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1197614795069022209",
      "id_str" : "1197686166029524992",
      "in_reply_to_user_id" : "60988328",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1197686166029524992",
      "in_reply_to_status_id" : "1197614795069022209",
      "created_at" : "Fri Nov 22 01:20:08 +0000 2019",
      "favorited" : false,
      "full_text" : "@tntmonty @birdsarecommies Sorry! I just patched something yesterday, but it broke this. It's reverted now so if you refresh it should bring you back to your checkpoint and this should work now.",
      "lang" : "en",
      "in_reply_to_screen_name" : "tntmonty",
      "in_reply_to_user_id_str" : "60988328"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1191885363243032576"
          ],
          "editableUntil" : "2019-11-06T01:39:49.413Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "benji ᓚᘏᗢ",
            "screen_name" : "birdsarecommies",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "3244669657",
            "id" : "3244669657"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "207"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1191881292264005632",
      "id_str" : "1191885363243032576",
      "in_reply_to_user_id" : "3244669657",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1191885363243032576",
      "in_reply_to_status_id" : "1191881292264005632",
      "created_at" : "Wed Nov 06 01:09:49 +0000 2019",
      "favorited" : false,
      "full_text" : "@birdsarecommies Nice!\nIt's been interesting to see find which branches people find the hardest.\n\nEverything you need for that one is in the 8x8 square there, you're not missing anything except the \"aha!\" :)",
      "lang" : "en",
      "in_reply_to_screen_name" : "birdsarecommies",
      "in_reply_to_user_id_str" : "3244669657"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1191484862773047299"
          ],
          "editableUntil" : "2019-11-04T23:08:22.660Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/UDVRpdawxu",
            "expanded_url" : "https://jacklance.github.io/PuzzleScript/play.html?p=cfdcc6e23f1fb3e9de2fd42fafaf4d4c",
            "display_url" : "jacklance.github.io/PuzzleScript/p…",
            "indices" : [
              "24",
              "47"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "47"
      ],
      "favorite_count" : "95",
      "id_str" : "1191484862773047299",
      "truncated" : false,
      "retweet_count" : "30",
      "id" : "1191484862773047299",
      "possibly_sensitive" : false,
      "created_at" : "Mon Nov 04 22:38:22 +0000 2019",
      "favorited" : false,
      "full_text" : "Hi, here's a new game!\n\nhttps://t.co/UDVRpdawxu",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1186075066322378758"
          ],
          "editableUntil" : "2019-10-21T00:51:46.677Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1186075066322378758/photo/1",
            "indices" : [
              "0",
              "23"
            ],
            "url" : "https://t.co/RaIiQqCij1",
            "media_url" : "http://pbs.twimg.com/media/EHXI_ABWkAEJv97.png",
            "id_str" : "1186075061544980481",
            "id" : "1186075061544980481",
            "media_url_https" : "https://pbs.twimg.com/media/EHXI_ABWkAEJv97.png",
            "sizes" : {
              "large" : {
                "w" : "923",
                "h" : "109",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "109",
                "h" : "109",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "80",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "923",
                "h" : "109",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/RaIiQqCij1"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "9",
      "id_str" : "1186075066322378758",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1186075066322378758",
      "possibly_sensitive" : false,
      "created_at" : "Mon Oct 21 00:21:46 +0000 2019",
      "favorited" : false,
      "full_text" : "https://t.co/RaIiQqCij1",
      "lang" : "zxx",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1186075066322378758/photo/1",
            "indices" : [
              "0",
              "23"
            ],
            "url" : "https://t.co/RaIiQqCij1",
            "media_url" : "http://pbs.twimg.com/media/EHXI_ABWkAEJv97.png",
            "id_str" : "1186075061544980481",
            "id" : "1186075061544980481",
            "media_url_https" : "https://pbs.twimg.com/media/EHXI_ABWkAEJv97.png",
            "sizes" : {
              "large" : {
                "w" : "923",
                "h" : "109",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "109",
                "h" : "109",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "80",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "923",
                "h" : "109",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/RaIiQqCij1"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1164330133353828352"
          ],
          "editableUntil" : "2019-08-22T00:45:10.656Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "164"
      ],
      "favorite_count" : "7",
      "id_str" : "1164330133353828352",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1164330133353828352",
      "created_at" : "Thu Aug 22 00:15:10 +0000 2019",
      "favorited" : false,
      "full_text" : "If you remove every other letter of \"Thanos\" (perfectly balanced, as all things should be), you get \"Tao\", which is a word referring to the balance of the universe!",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1158917091535314945"
          ],
          "editableUntil" : "2019-08-07T02:15:40.917Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1158917091535314945/photo/1",
            "indices" : [
              "54",
              "77"
            ],
            "url" : "https://t.co/FhDToWu0CO",
            "media_url" : "http://pbs.twimg.com/media/EBVM1phWkAA1PEt.png",
            "id_str" : "1158916963680292864",
            "id" : "1158916963680292864",
            "media_url_https" : "https://pbs.twimg.com/media/EBVM1phWkAA1PEt.png",
            "sizes" : {
              "large" : {
                "w" : "561",
                "h" : "185",
                "resize" : "fit"
              },
              "small" : {
                "w" : "561",
                "h" : "185",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "561",
                "h" : "185",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/FhDToWu0CO"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "77"
      ],
      "favorite_count" : "13",
      "id_str" : "1158917091535314945",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1158917091535314945",
      "possibly_sensitive" : false,
      "created_at" : "Wed Aug 07 01:45:40 +0000 2019",
      "favorited" : false,
      "full_text" : "Total up letter tally.\nDetect name \"J.L.L.\" viewable. https://t.co/FhDToWu0CO",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1158917091535314945/photo/1",
            "indices" : [
              "54",
              "77"
            ],
            "url" : "https://t.co/FhDToWu0CO",
            "media_url" : "http://pbs.twimg.com/media/EBVM1phWkAA1PEt.png",
            "id_str" : "1158916963680292864",
            "id" : "1158916963680292864",
            "media_url_https" : "https://pbs.twimg.com/media/EBVM1phWkAA1PEt.png",
            "sizes" : {
              "large" : {
                "w" : "561",
                "h" : "185",
                "resize" : "fit"
              },
              "small" : {
                "w" : "561",
                "h" : "185",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "561",
                "h" : "185",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/FhDToWu0CO"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1149348574750269440"
          ],
          "editableUntil" : "2019-07-11T16:33:48.741Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/jgmTEtffv7",
            "expanded_url" : "http://www.puzzlescript.net/play.html?p=9eb8f8f3df4efb450b798a279eeba2e0",
            "display_url" : "puzzlescript.net/play.html?p=9e…",
            "indices" : [
              "32",
              "55"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "55"
      ],
      "favorite_count" : "120",
      "id_str" : "1149348574750269440",
      "truncated" : false,
      "retweet_count" : "22",
      "id" : "1149348574750269440",
      "possibly_sensitive" : false,
      "created_at" : "Thu Jul 11 16:03:48 +0000 2019",
      "favorited" : false,
      "full_text" : "Just made this game \"VEXT EDIT\"\nhttps://t.co/jgmTEtffv7",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1142129301317402630"
          ],
          "editableUntil" : "2019-06-21T18:26:59.827Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "203"
      ],
      "favorite_count" : "7",
      "id_str" : "1142129301317402630",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1142129301317402630",
      "created_at" : "Fri Jun 21 17:56:59 +0000 2019",
      "favorited" : false,
      "full_text" : "Heard someone say \"period\" to indicate that there was nothing more to be said, but they said it thrice for emphasis which turns it into an ellipsis which indicates that there's something more to be said.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1126662532180135938"
          ],
          "editableUntil" : "2019-05-10T02:07:34.706Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/fB1y9NKCSG",
            "expanded_url" : "https://www.puzzlescript.net/play.html?p=a4bb2bf44284bdb9347cf3f1399d4f11",
            "display_url" : "puzzlescript.net/play.html?p=a4…",
            "indices" : [
              "0",
              "23"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "14",
      "id_str" : "1126662532180135938",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1126662532180135938",
      "possibly_sensitive" : false,
      "created_at" : "Fri May 10 01:37:34 +0000 2019",
      "favorited" : false,
      "full_text" : "https://t.co/fB1y9NKCSG",
      "lang" : "zxx"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1124422488614678528"
          ],
          "editableUntil" : "2019-05-03T21:46:26.702Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1124422488614678528/photo/1",
            "indices" : [
              "29",
              "52"
            ],
            "url" : "https://t.co/rEd5jTUX47",
            "media_url" : "http://pbs.twimg.com/media/D5rAPKFWsAAqJQi.png",
            "id_str" : "1124422423619743744",
            "id" : "1124422423619743744",
            "media_url_https" : "https://pbs.twimg.com/media/D5rAPKFWsAAqJQi.png",
            "sizes" : {
              "small" : {
                "w" : "390",
                "h" : "160",
                "resize" : "fit"
              },
              "large" : {
                "w" : "390",
                "h" : "160",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "390",
                "h" : "160",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/rEd5jTUX47"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "52"
      ],
      "favorite_count" : "0",
      "id_str" : "1124422488614678528",
      "in_reply_to_user_id" : "75783213",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1124422488614678528",
      "possibly_sensitive" : false,
      "created_at" : "Fri May 03 21:16:26 +0000 2019",
      "favorited" : false,
      "full_text" : "@increpare 3BYTE x your name https://t.co/rEd5jTUX47",
      "lang" : "en",
      "in_reply_to_user_id_str" : "75783213",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1124422488614678528/photo/1",
            "indices" : [
              "29",
              "52"
            ],
            "url" : "https://t.co/rEd5jTUX47",
            "media_url" : "http://pbs.twimg.com/media/D5rAPKFWsAAqJQi.png",
            "id_str" : "1124422423619743744",
            "id" : "1124422423619743744",
            "media_url_https" : "https://pbs.twimg.com/media/D5rAPKFWsAAqJQi.png",
            "sizes" : {
              "small" : {
                "w" : "390",
                "h" : "160",
                "resize" : "fit"
              },
              "large" : {
                "w" : "390",
                "h" : "160",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "390",
                "h" : "160",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/rEd5jTUX47"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1123066339634163712"
          ],
          "editableUntil" : "2019-04-30T03:57:35.589Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/BmpxbG1JE6",
            "expanded_url" : "https://ldjam.com/events/ludum-dare/44/test",
            "display_url" : "ldjam.com/events/ludum-d…",
            "indices" : [
              "39",
              "62"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "62"
      ],
      "favorite_count" : "1",
      "id_str" : "1123066339634163712",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1123066339634163712",
      "possibly_sensitive" : false,
      "created_at" : "Tue Apr 30 03:27:35 +0000 2019",
      "favorited" : false,
      "full_text" : "Made a game with a friend for LD44 :)\n\nhttps://t.co/BmpxbG1JE6",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1115839928385069060"
          ],
          "editableUntil" : "2019-04-10T05:22:24.887Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1115839928385069060/photo/1",
            "indices" : [
              "0",
              "23"
            ],
            "url" : "https://t.co/ZYqumbkWCD",
            "media_url" : "http://pbs.twimg.com/media/D3xCf66WsAA7GGr.png",
            "id_str" : "1115839923838431232",
            "id" : "1115839923838431232",
            "media_url_https" : "https://pbs.twimg.com/media/D3xCf66WsAA7GGr.png",
            "sizes" : {
              "large" : {
                "w" : "368",
                "h" : "230",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "368",
                "h" : "230",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "368",
                "h" : "230",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/ZYqumbkWCD"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "15",
      "id_str" : "1115839928385069060",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1115839928385069060",
      "possibly_sensitive" : false,
      "created_at" : "Wed Apr 10 04:52:24 +0000 2019",
      "favorited" : false,
      "full_text" : "https://t.co/ZYqumbkWCD",
      "lang" : "zxx",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1115839928385069060/photo/1",
            "indices" : [
              "0",
              "23"
            ],
            "url" : "https://t.co/ZYqumbkWCD",
            "media_url" : "http://pbs.twimg.com/media/D3xCf66WsAA7GGr.png",
            "id_str" : "1115839923838431232",
            "id" : "1115839923838431232",
            "media_url_https" : "https://pbs.twimg.com/media/D3xCf66WsAA7GGr.png",
            "sizes" : {
              "large" : {
                "w" : "368",
                "h" : "230",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "368",
                "h" : "230",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "368",
                "h" : "230",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/ZYqumbkWCD"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1111374947178278912"
          ],
          "editableUntil" : "2019-03-28T21:40:10.412Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "122"
      ],
      "favorite_count" : "27",
      "id_str" : "1111374947178278912",
      "truncated" : false,
      "retweet_count" : "9",
      "id" : "1111374947178278912",
      "created_at" : "Thu Mar 28 21:10:10 +0000 2019",
      "favorited" : false,
      "full_text" : "Assuming punctuation is ignored in anagrams:\n\nfibonacciRabbits\n=\nfor(int i=0; i++&lt;s; )\n{\n    c=a+b;\n    a=b;\n    b=c;\n}",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1107429856684457984"
          ],
          "editableUntil" : "2019-03-18T00:23:47.542Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "3",
      "id_str" : "1107429856684457984",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1107429856684457984",
      "created_at" : "Sun Mar 17 23:53:47 +0000 2019",
      "favorited" : false,
      "full_text" : "Of all the mountains to climb, EVEREST'S SEVEREST",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1106225736464171008"
          ],
          "editableUntil" : "2019-03-14T16:39:02.910Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/2RuCR8F97s",
            "expanded_url" : "https://jacoblance.wordpress.com/2019/03/14/p-i-hunt-5/",
            "display_url" : "jacoblance.wordpress.com/2019/03/14/p-i…",
            "indices" : [
              "12",
              "35"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "5",
      "id_str" : "1106225736464171008",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1106225736464171008",
      "possibly_sensitive" : false,
      "created_at" : "Thu Mar 14 16:09:02 +0000 2019",
      "favorited" : false,
      "full_text" : "P.I.HUNT 5!\nhttps://t.co/2RuCR8F97s",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1096896298459037697"
          ],
          "editableUntil" : "2019-02-16T22:47:11.557Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "5",
      "id_str" : "1096896298459037697",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1096896298459037697",
      "created_at" : "Sat Feb 16 22:17:11 +0000 2019",
      "favorited" : false,
      "full_text" : "UNIVERSITY MASCOT = IN VARSITY COSTUME",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1055113906899828736"
          ],
          "editableUntil" : "2018-10-24T15:38:53.130Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "April🧪",
            "screen_name" : "SereneBiologist",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "863952466639040512",
            "id" : "863952466639040512"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "194"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1054912436258721792",
      "id_str" : "1055113906899828736",
      "in_reply_to_user_id" : "863952466639040512",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1055113906899828736",
      "in_reply_to_status_id" : "1054912436258721792",
      "created_at" : "Wed Oct 24 15:08:53 +0000 2018",
      "favorited" : false,
      "full_text" : "@SereneBiologist This seems true at first glance,but isn’t actually. 2x is 2 + (2+...)/(3+...) not 2 + (4+...)/(6+...)\nAt second glance it might look like 1+(1+x)/(2+x), but it’s not that either",
      "lang" : "en",
      "in_reply_to_screen_name" : "SereneBiologist",
      "in_reply_to_user_id_str" : "863952466639040512"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1037531348431499264"
          ],
          "editableUntil" : "2018-09-06T03:12:04.523Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "274"
      ],
      "favorite_count" : "5",
      "in_reply_to_status_id_str" : "1037521433474347009",
      "id_str" : "1037531348431499264",
      "in_reply_to_user_id" : "2444552670",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1037531348431499264",
      "in_reply_to_status_id" : "1037521433474347009",
      "created_at" : "Thu Sep 06 02:42:04 +0000 2018",
      "favorited" : false,
      "full_text" : "Mystery solved:\n🔜 means an event is in the future and 🔚 means it was in the past, so 🔛 means it's happening now (\"it's on!\")\n\nThe three emojis apparently were in the original set, and predate even the smiley emoji. Seems like no one knows what it means anymore. Interesting!",
      "lang" : "en",
      "in_reply_to_screen_name" : "Jack_L_Lance",
      "in_reply_to_user_id_str" : "2444552670"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1037521433474347009"
          ],
          "editableUntil" : "2018-09-06T02:32:40.613Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "263"
      ],
      "favorite_count" : "5",
      "id_str" : "1037521433474347009",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1037521433474347009",
      "created_at" : "Thu Sep 06 02:02:40 +0000 2018",
      "favorited" : false,
      "full_text" : "After researching, I still have no idea why the 🔛 emoji exists.\n\nSome other weird looking emojis like 〽 or 🎴 have more meaning (usually something Japanese) behind them, but as far as I can tell, 🔛 is just \"ON!\" with a double facing arrow for absolutely no reason?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1037072926347022336"
          ],
          "editableUntil" : "2018-09-04T20:50:28.181Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "269"
      ],
      "favorite_count" : "3",
      "id_str" : "1037072926347022336",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1037072926347022336",
      "created_at" : "Tue Sep 04 20:20:28 +0000 2018",
      "favorited" : false,
      "full_text" : "\"Revolt\", as in a rebellion, is a noun.\n\"Revolt\" can also be the verb form of the noun \"revolt\"\n\"Revolution\" is the noun form of the verb \"revolt\"\n\"Revolutionize\" is the verb form of the noun \"revolution\"\n\"Revolutionization\" is the noun form of the verb \"revolutionize\"",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1034472481191604224"
          ],
          "editableUntil" : "2018-08-28T16:37:13.742Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "projectyl",
            "screen_name" : "projectyl",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "14076574",
            "id" : "14076574"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "255"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1034302789290086400",
      "id_str" : "1034472481191604224",
      "in_reply_to_user_id" : "14076574",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1034472481191604224",
      "in_reply_to_status_id" : "1034302789290086400",
      "created_at" : "Tue Aug 28 16:07:13 +0000 2018",
      "favorited" : false,
      "full_text" : "@projectyl The 100%s are great because of the 1 hour impassable wait.\nSpeedruns of The Witness include people making and eating a sandwich, playing mario, or solving Rubik's Cubes in the middle (and then returning to rapidly entering memorized solutions.)",
      "lang" : "en",
      "in_reply_to_screen_name" : "projectyl",
      "in_reply_to_user_id_str" : "14076574"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1015254757999562752"
          ],
          "editableUntil" : "2018-07-06T15:52:51.485Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "123"
      ],
      "favorite_count" : "3",
      "id_str" : "1015254757999562752",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1015254757999562752",
      "created_at" : "Fri Jul 06 15:22:51 +0000 2018",
      "favorited" : false,
      "full_text" : "“Shift plus {three, apostrophe, nine, equals} makes” ~\n“{hash, quote marks, open (i.e. left) parenthesis, plus}”\n(anagrams)",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1015239937308979200"
          ],
          "editableUntil" : "2018-07-06T14:53:57.957Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "96"
      ],
      "favorite_count" : "7",
      "id_str" : "1015239937308979200",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1015239937308979200",
      "created_at" : "Fri Jul 06 14:23:57 +0000 2018",
      "favorited" : false,
      "full_text" : "You tell someone to “break a leg” before an audition because you’re hoping they get into a cast.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1012735900235784193"
          ],
          "editableUntil" : "2018-06-29T17:03:48.996Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "280"
      ],
      "favorite_count" : "2",
      "id_str" : "1012735900235784193",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1012735900235784193",
      "created_at" : "Fri Jun 29 16:33:48 +0000 2018",
      "favorited" : false,
      "full_text" : "\"This text looks super weird like broken english\" you say \"It really sounds off just kinda\" I did write so that there'd be task hidden so well in it but if needed you can find still. You just need to start to erase words not placed divisible even into thirds. Be reading when done",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1011733246630121473"
          ],
          "editableUntil" : "2018-06-26T22:39:37.748Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1011733246630121473/photo/1",
            "indices" : [
              "0",
              "23"
            ],
            "url" : "https://t.co/85GvVxE6wD",
            "media_url" : "http://pbs.twimg.com/media/DgpmBSyUcAET6wT.jpg",
            "id_str" : "1011733238706892801",
            "id" : "1011733238706892801",
            "media_url_https" : "https://pbs.twimg.com/media/DgpmBSyUcAET6wT.jpg",
            "sizes" : {
              "small" : {
                "w" : "508",
                "h" : "420",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "508",
                "h" : "420",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "508",
                "h" : "420",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/85GvVxE6wD"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "32",
      "id_str" : "1011733246630121473",
      "truncated" : false,
      "retweet_count" : "7",
      "id" : "1011733246630121473",
      "possibly_sensitive" : false,
      "created_at" : "Tue Jun 26 22:09:37 +0000 2018",
      "favorited" : false,
      "full_text" : "https://t.co/85GvVxE6wD",
      "lang" : "zxx",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/1011733246630121473/photo/1",
            "indices" : [
              "0",
              "23"
            ],
            "url" : "https://t.co/85GvVxE6wD",
            "media_url" : "http://pbs.twimg.com/media/DgpmBSyUcAET6wT.jpg",
            "id_str" : "1011733238706892801",
            "id" : "1011733238706892801",
            "media_url_https" : "https://pbs.twimg.com/media/DgpmBSyUcAET6wT.jpg",
            "sizes" : {
              "small" : {
                "w" : "508",
                "h" : "420",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "508",
                "h" : "420",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "508",
                "h" : "420",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/85GvVxE6wD"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1010121006206287873"
          ],
          "editableUntil" : "2018-06-22T11:53:09.677Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "188"
      ],
      "favorite_count" : "0",
      "id_str" : "1010121006206287873",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1010121006206287873",
      "created_at" : "Fri Jun 22 11:23:09 +0000 2018",
      "favorited" : false,
      "full_text" : "Use the digits 1, 2, 3, 4, and 5, each exactly once, along with any amount of addition, subtraction, multiplication, division, exponentiation, decimal points, and parentheses to make 2018.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1007422843229962240"
          ],
          "editableUntil" : "2018-06-15T01:11:37.494Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "276"
      ],
      "favorite_count" : "0",
      "id_str" : "1007422843229962240",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1007422843229962240",
      "created_at" : "Fri Jun 15 00:41:37 +0000 2018",
      "favorited" : false,
      "full_text" : "bool all_are_doubles(string words, int length){\n  map&lt;char, bool&gt; map;\n  for(int i=0; i&lt;=length-1; i++){\n    map[words[i]] = !(map[words[i]]);\n  }\n  for(auto i = map.begin(); !(i == map.end()); i++){\n     while(i-&gt;second){\n       return 0;\n     }\n  }\n  return 1;\n}",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1007060079240273930"
          ],
          "editableUntil" : "2018-06-14T01:10:07.819Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "90"
      ],
      "favorite_count" : "2",
      "id_str" : "1007060079240273930",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1007060079240273930",
      "created_at" : "Thu Jun 14 00:40:07 +0000 2018",
      "favorited" : false,
      "full_text" : "I like orange melon, but not green. I think they should be renamed Honeydont and Canelope.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "999082687695675392"
          ],
          "editableUntil" : "2018-05-23T00:50:49.462Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "projectyl",
            "screen_name" : "projectyl",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "14076574",
            "id" : "14076574"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "55"
      ],
      "favorite_count" : "6",
      "in_reply_to_status_id_str" : "998111447828742145",
      "id_str" : "999082687695675392",
      "in_reply_to_user_id" : "14076574",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "999082687695675392",
      "in_reply_to_status_id" : "998111447828742145",
      "created_at" : "Wed May 23 00:20:49 +0000 2018",
      "favorited" : false,
      "full_text" : "@projectyl FAQs set drunkly to see quine  (4 3 7 2 3 5)",
      "lang" : "en",
      "in_reply_to_screen_name" : "projectyl",
      "in_reply_to_user_id_str" : "14076574"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "968023059134341121"
          ],
          "editableUntil" : "2018-02-26T07:50:56.953Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "90"
      ],
      "favorite_count" : "7",
      "id_str" : "968023059134341121",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "968023059134341121",
      "created_at" : "Mon Feb 26 07:20:56 +0000 2018",
      "favorited" : false,
      "full_text" : "asexuality + bisexuality = (a+bi)sexuality \n\nNo wonder some people claim they aren’t real!",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "963134420168466437"
          ],
          "editableUntil" : "2018-02-12T20:05:14.597Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "102"
      ],
      "favorite_count" : "4",
      "id_str" : "963134420168466437",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "963134420168466437",
      "created_at" : "Mon Feb 12 19:35:14 +0000 2018",
      "favorited" : false,
      "full_text" : "dad = a papa\nracecar = track cart\nnever odd or even = NaN\nwas it a car or a cat I saw? = motor o' tom?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "959302084347576320"
          ],
          "editableUntil" : "2018-02-02T06:16:54.536Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Alan Hazelden/Draknek & Friends",
            "screen_name" : "Draknek",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "17040610",
            "id" : "17040610"
          },
          {
            "name" : "Edward Kmett",
            "screen_name" : "kmett",
            "indices" : [
              "9",
              "15"
            ],
            "id_str" : "16781974",
            "id" : "16781974"
          },
          {
            "name" : "Daniel Linssen 🦊",
            "screen_name" : "managore",
            "indices" : [
              "16",
              "25"
            ],
            "id_str" : "17306760",
            "id" : "17306760"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "120"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "959235612891951104",
      "id_str" : "959302084347576320",
      "in_reply_to_user_id" : "17040610",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "959302084347576320",
      "in_reply_to_status_id" : "959235612891951104",
      "created_at" : "Fri Feb 02 05:46:54 +0000 2018",
      "favorited" : false,
      "full_text" : "@Draknek @kmett @Managore The other levels get a tick because they're beaten. \nThat level gets a tick because it's \"B10\"",
      "lang" : "en",
      "in_reply_to_screen_name" : "Draknek",
      "in_reply_to_user_id_str" : "17040610"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "957134102024654848"
          ],
          "editableUntil" : "2018-01-27T06:42:07.271Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/957134102024654848/photo/1",
            "indices" : [
              "28",
              "51"
            ],
            "url" : "https://t.co/rimS1AsLbc",
            "media_url" : "http://pbs.twimg.com/media/DUhsPZqUQAInY9L.jpg",
            "id_str" : "957133932658442242",
            "id" : "957133932658442242",
            "media_url_https" : "https://pbs.twimg.com/media/DUhsPZqUQAInY9L.jpg",
            "sizes" : {
              "large" : {
                "w" : "335",
                "h" : "316",
                "resize" : "fit"
              },
              "small" : {
                "w" : "335",
                "h" : "316",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "335",
                "h" : "316",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/rimS1AsLbc"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "51"
      ],
      "favorite_count" : "1",
      "id_str" : "957134102024654848",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "957134102024654848",
      "possibly_sensitive" : false,
      "created_at" : "Sat Jan 27 06:12:07 +0000 2018",
      "favorited" : false,
      "full_text" : "P.I.HUNT 4 coming soon-ish! https://t.co/rimS1AsLbc",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/957134102024654848/photo/1",
            "indices" : [
              "28",
              "51"
            ],
            "url" : "https://t.co/rimS1AsLbc",
            "media_url" : "http://pbs.twimg.com/media/DUhsPZqUQAInY9L.jpg",
            "id_str" : "957133932658442242",
            "id" : "957133932658442242",
            "media_url_https" : "https://pbs.twimg.com/media/DUhsPZqUQAInY9L.jpg",
            "sizes" : {
              "large" : {
                "w" : "335",
                "h" : "316",
                "resize" : "fit"
              },
              "small" : {
                "w" : "335",
                "h" : "316",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "335",
                "h" : "316",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/rimS1AsLbc"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "953115884398301184"
          ],
          "editableUntil" : "2018-01-16T04:35:09.534Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "93"
      ],
      "favorite_count" : "3",
      "id_str" : "953115884398301184",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "953115884398301184",
      "created_at" : "Tue Jan 16 04:05:09 +0000 2018",
      "favorited" : false,
      "full_text" : "Jack does give quiz:\nLoad four char (A-Zed) dice. Next turn them. Goal: Make each word, okay?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "946713837637582848"
          ],
          "editableUntil" : "2017-12-29T12:35:42.642Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "91"
      ],
      "favorite_count" : "2",
      "id_str" : "946713837637582848",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "946713837637582848",
      "created_at" : "Fri Dec 29 12:05:42 +0000 2017",
      "favorited" : false,
      "full_text" : "\"Speaking from the bottom of my heart\" is pretty close to \"Speaking at the top of my lungs\"",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "946713686239883264"
          ],
          "editableUntil" : "2017-12-29T12:35:06.546Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "68"
      ],
      "favorite_count" : "0",
      "id_str" : "946713686239883264",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "946713686239883264",
      "created_at" : "Fri Dec 29 12:05:06 +0000 2017",
      "favorited" : false,
      "full_text" : "In a camel race, you can be 3 feet apart and still be neck and neck.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "938595521224200192"
          ],
          "editableUntil" : "2017-12-07T02:56:25.178Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "137"
      ],
      "favorite_count" : "2",
      "id_str" : "938595521224200192",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "938595521224200192",
      "created_at" : "Thu Dec 07 02:26:25 +0000 2017",
      "favorited" : false,
      "full_text" : "Square meals:\n\nDIP\nICE\nPEA\n\nACOB\nCAKE\nOKRA\nBEAN\n\nLAMB LAMB\nAGAR-AGAR\nMAHI-MAHI\nBRIE BRIE\n --   --\nLAMB LAMB\nAGAR-AGAR\nMAHI-MAHI\nBRIE BRIE",
      "lang" : "ca"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "928395655348973569"
          ],
          "editableUntil" : "2017-11-08T23:25:47.649Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "74"
      ],
      "favorite_count" : "4",
      "id_str" : "928395655348973569",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "928395655348973569",
      "created_at" : "Wed Nov 08 22:55:47 +0000 2017",
      "favorited" : false,
      "full_text" : "At a frat party, you might find people dropping acid or dropping the bass.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "910887404990496771"
          ],
          "editableUntil" : "2017-09-21T15:54:15.476Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Google Students",
            "screen_name" : "googlestudents",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "30315557",
            "id" : "30315557"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "910886925887787008",
      "id_str" : "910887404990496771",
      "in_reply_to_user_id" : "2444552670",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "910887404990496771",
      "in_reply_to_status_id" : "910886925887787008",
      "created_at" : "Thu Sep 21 15:24:15 +0000 2017",
      "favorited" : false,
      "full_text" : "@googlestudents Looking at the source, it says \"Code expired\".\nThough, interestingly, I can't find any mention of that code anywhere online.",
      "lang" : "en",
      "in_reply_to_screen_name" : "Jack_L_Lance",
      "in_reply_to_user_id_str" : "2444552670"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "910886925887787008"
          ],
          "editableUntil" : "2017-09-21T15:52:21.249Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Google Students",
            "screen_name" : "googlestudents",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "30315557",
            "id" : "30315557"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "130"
      ],
      "favorite_count" : "0",
      "id_str" : "910886925887787008",
      "in_reply_to_user_id" : "30315557",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "910886925887787008",
      "created_at" : "Thu Sep 21 15:22:21 +0000 2017",
      "favorited" : false,
      "full_text" : "@googlestudents Huh. I managed to find foo code D9Mch6LK at the end of one of  your videos, but I get the message \"Invalid token.\"",
      "lang" : "en",
      "in_reply_to_screen_name" : "googlestudents",
      "in_reply_to_user_id_str" : "30315557"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "902274161602695168"
          ],
          "editableUntil" : "2017-08-28T21:28:18.226Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "18"
      ],
      "favorite_count" : "0",
      "id_str" : "902274161602695168",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "902274161602695168",
      "created_at" : "Mon Aug 28 20:58:18 +0000 2017",
      "favorited" : false,
      "full_text" : "mildew = mild \"ew\"",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "898653137057103872"
          ],
          "editableUntil" : "2017-08-18T21:39:38.699Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "projectyl",
            "screen_name" : "projectyl",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "14076574",
            "id" : "14076574"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "151"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "898652917363769348",
      "id_str" : "898653137057103872",
      "in_reply_to_user_id" : "2444552670",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "898653137057103872",
      "in_reply_to_status_id" : "898652917363769348",
      "created_at" : "Fri Aug 18 21:09:38 +0000 2017",
      "favorited" : false,
      "full_text" : "@projectyl (2/2) Covfefe was hard to figure out, but this just a cryptic clue for EW (with the definition half being the current political climate obv)",
      "lang" : "en",
      "in_reply_to_screen_name" : "Jack_L_Lance",
      "in_reply_to_user_id_str" : "2444552670"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "898652917363769348"
          ],
          "editableUntil" : "2017-08-18T21:38:46.320Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "projectyl",
            "screen_name" : "projectyl",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "14076574",
            "id" : "14076574"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "110"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "898625871300263936",
      "id_str" : "898652917363769348",
      "in_reply_to_user_id" : "14076574",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "898652917363769348",
      "in_reply_to_status_id" : "898625871300263936",
      "created_at" : "Fri Aug 18 21:08:46 +0000 2017",
      "favorited" : false,
      "full_text" : "@projectyl (1/2) Assuming you're referring to what I think, the difficulty curve was really bad in my opinion.",
      "lang" : "en",
      "in_reply_to_screen_name" : "projectyl",
      "in_reply_to_user_id_str" : "14076574"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "897884951810625537"
          ],
          "editableUntil" : "2017-08-16T18:47:09.064Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "80"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "897882487883485192",
      "id_str" : "897884951810625537",
      "in_reply_to_user_id" : "2444552670",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "897884951810625537",
      "in_reply_to_status_id" : "897882487883485192",
      "created_at" : "Wed Aug 16 18:17:09 +0000 2017",
      "favorited" : false,
      "full_text" : "(Depending on where you live, sometimes a different percentage D-marks D marks.)",
      "lang" : "en",
      "contributors" : [
        "715607955903799296"
      ],
      "in_reply_to_screen_name" : "Jack_L_Lance",
      "in_reply_to_user_id_str" : "2444552670"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "897882487883485192"
          ],
          "editableUntil" : "2017-08-16T18:37:21.618Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "34"
      ],
      "favorite_count" : "0",
      "id_str" : "897882487883485192",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "897882487883485192",
      "created_at" : "Wed Aug 16 18:07:21 +0000 2017",
      "favorited" : false,
      "full_text" : "Getting 65% on a test is D-grading",
      "lang" : "en",
      "contributors" : [
        "715607955903799296"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "894669083383353344"
          ],
          "editableUntil" : "2017-08-07T21:48:26.283Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "108"
      ],
      "favorite_count" : "2",
      "id_str" : "894669083383353344",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "894669083383353344",
      "created_at" : "Mon Aug 07 21:18:26 +0000 2017",
      "favorited" : false,
      "full_text" : "Place this into a box. Then, you can use A through I to form a puzzle-y grid that's quality groovy, by Jack.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "891683534724890625"
          ],
          "editableUntil" : "2017-07-30T16:04:56.014Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/891683534724890625/photo/1",
            "indices" : [
              "124",
              "147"
            ],
            "url" : "https://t.co/b1tG62oOCT",
            "media_url" : "http://pbs.twimg.com/media/DF_lRcIXgAEiN0A.jpg",
            "id_str" : "891683339014471681",
            "id" : "891683339014471681",
            "media_url_https" : "https://pbs.twimg.com/media/DF_lRcIXgAEiN0A.jpg",
            "sizes" : {
              "large" : {
                "w" : "764",
                "h" : "217",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "193",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "764",
                "h" : "217",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/b1tG62oOCT"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "147"
      ],
      "favorite_count" : "2",
      "id_str" : "891683534724890625",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "891683534724890625",
      "possibly_sensitive" : false,
      "created_at" : "Sun Jul 30 15:34:56 +0000 2017",
      "favorited" : false,
      "full_text" : "I turn 20 today!\nHere are 20 matchsticks that spell TWENTY.\nMove just 4 of them to make an expression that evaluates to 20. https://t.co/b1tG62oOCT",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/891683534724890625/photo/1",
            "indices" : [
              "124",
              "147"
            ],
            "url" : "https://t.co/b1tG62oOCT",
            "media_url" : "http://pbs.twimg.com/media/DF_lRcIXgAEiN0A.jpg",
            "id_str" : "891683339014471681",
            "id" : "891683339014471681",
            "media_url_https" : "https://pbs.twimg.com/media/DF_lRcIXgAEiN0A.jpg",
            "sizes" : {
              "large" : {
                "w" : "764",
                "h" : "217",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "193",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "764",
                "h" : "217",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/b1tG62oOCT"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "891673716983291904"
          ],
          "editableUntil" : "2017-07-30T15:25:55.282Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "1",
      "id_str" : "891673716983291904",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "891673716983291904",
      "created_at" : "Sun Jul 30 14:55:55 +0000 2017",
      "favorited" : false,
      "full_text" : "\"Random repetitions?\"\n=\n\"Nope, It is modern art!\"",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "889846423856041989"
          ],
          "editableUntil" : "2017-07-25T14:24:54.651Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "121"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "889842798786162692",
      "id_str" : "889846423856041989",
      "in_reply_to_user_id" : "2444552670",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "889846423856041989",
      "in_reply_to_status_id" : "889842798786162692",
      "created_at" : "Tue Jul 25 13:54:54 +0000 2017",
      "favorited" : false,
      "full_text" : "I suppose it is very visually stunning for tourists, so I understand why the English pronunciation is the \"Eyeful\" Tower!",
      "lang" : "en",
      "in_reply_to_screen_name" : "Jack_L_Lance",
      "in_reply_to_user_id_str" : "2444552670"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "889844790300475393"
          ],
          "editableUntil" : "2017-07-25T14:18:25.181Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "61"
      ],
      "favorite_count" : "1",
      "id_str" : "889844790300475393",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "889844790300475393",
      "created_at" : "Tue Jul 25 13:48:25 +0000 2017",
      "favorited" : false,
      "full_text" : "The letters T-E-N are exactly half of the letters T-W-E-N-T-Y",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "889844701871865856"
          ],
          "editableUntil" : "2017-07-25T14:18:04.098Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "123"
      ],
      "favorite_count" : "0",
      "id_str" : "889844701871865856",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "889844701871865856",
      "created_at" : "Tue Jul 25 13:48:04 +0000 2017",
      "favorited" : false,
      "full_text" : "Pronouncing aloud the first two letters of \"fowl\" and the first two letters of \"party\" means the same thing as \"party fowl\"",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "889842798786162692"
          ],
          "editableUntil" : "2017-07-25T14:10:30.367Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "103"
      ],
      "favorite_count" : "0",
      "id_str" : "889842798786162692",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "889842798786162692",
      "created_at" : "Tue Jul 25 13:40:30 +0000 2017",
      "favorited" : false,
      "full_text" : "For such a tall monument that you can go to the top of, the \"I Fell\" Tower is a pretty unsettling name.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "868623748571815936"
          ],
          "editableUntil" : "2017-05-28T00:53:34.565Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "80"
      ],
      "favorite_count" : "2",
      "id_str" : "868623748571815936",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "868623748571815936",
      "created_at" : "Sun May 28 00:23:34 +0000 2017",
      "favorited" : false,
      "full_text" : "On \"Rome's Got Talent\", when all the judges give you an X, it's a perfect score.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "850634301582528512"
          ],
          "editableUntil" : "2017-04-08T09:29:56.175Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "1",
      "id_str" : "850634301582528512",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "850634301582528512",
      "created_at" : "Sat Apr 08 08:59:56 +0000 2017",
      "favorited" : false,
      "full_text" : "Cool beans make chilly chili.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "833902591180423168"
          ],
          "editableUntil" : "2017-02-21T05:24:05.555Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "55"
      ],
      "favorite_count" : "0",
      "id_str" : "833902591180423168",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "833902591180423168",
      "created_at" : "Tue Feb 21 04:54:05 +0000 2017",
      "favorited" : false,
      "full_text" : "\"Parallel\" and \"Concurrent\" can be synonyms or antonyms",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "824121174242324481"
          ],
          "editableUntil" : "2017-01-25T05:36:14.027Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "118"
      ],
      "favorite_count" : "0",
      "id_str" : "824121174242324481",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "824121174242324481",
      "created_at" : "Wed Jan 25 05:06:14 +0000 2017",
      "favorited" : false,
      "full_text" : "Double negatives:\n\nOverlay - Understand\nNightfall - Dayspring\nIndie - Outlive\nHothead - Cold Feet\nRushmore - Ceaseless",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "818242536615608320"
          ],
          "editableUntil" : "2017-01-09T00:16:37.597Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "0",
      "id_str" : "818242536615608320",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "818242536615608320",
      "created_at" : "Sun Jan 08 23:46:37 +0000 2017",
      "favorited" : false,
      "full_text" : "Is cow tipping how steak tips are made?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "811050355966545921"
          ],
          "editableUntil" : "2016-12-20T03:57:28.106Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "113"
      ],
      "favorite_count" : "3",
      "id_str" : "811050355966545921",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "811050355966545921",
      "created_at" : "Tue Dec 20 03:27:28 +0000 2016",
      "favorited" : false,
      "full_text" : "Letters related to numbers related to one shape can form a phrase related to a time related to a different shape!",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "809240831676809216"
          ],
          "editableUntil" : "2016-12-15T04:07:03.896Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "99"
      ],
      "favorite_count" : "0",
      "id_str" : "809240831676809216",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "809240831676809216",
      "created_at" : "Thu Dec 15 03:37:03 +0000 2016",
      "favorited" : false,
      "full_text" : "If Artoo Detoo (R2D2) and See Threepio (C3PO) are robots, doesn't that make Obi Wan (OB1) one, too?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "808554374893072384"
          ],
          "editableUntil" : "2016-12-13T06:39:19.845Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/r5Z7JSTFVW",
            "expanded_url" : "http://ludumdare.com/compo/ludum-dare-37/?action=preview&uid=125227",
            "display_url" : "ludumdare.com/compo/ludum-da…",
            "indices" : [
              "55",
              "78"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/808554374893072384/photo/1",
            "indices" : [
              "79",
              "102"
            ],
            "url" : "https://t.co/leQ83Dd2nk",
            "media_url" : "http://pbs.twimg.com/media/CziP6eNXgAAn8-1.jpg",
            "id_str" : "808554367817318400",
            "id" : "808554367817318400",
            "media_url_https" : "https://pbs.twimg.com/media/CziP6eNXgAAn8-1.jpg",
            "sizes" : {
              "large" : {
                "w" : "552",
                "h" : "343",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "552",
                "h" : "343",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "552",
                "h" : "343",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/leQ83Dd2nk"
          }
        ],
        "hashtags" : [
          {
            "text" : "LDJAM",
            "indices" : [
              "35",
              "41"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "102"
      ],
      "favorite_count" : "0",
      "id_str" : "808554374893072384",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "808554374893072384",
      "possibly_sensitive" : false,
      "created_at" : "Tue Dec 13 06:09:19 +0000 2016",
      "favorited" : false,
      "full_text" : "Hey, I made a game in 48 hours for #LDJAM \nGo play it!\nhttps://t.co/r5Z7JSTFVW https://t.co/leQ83Dd2nk",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/808554374893072384/photo/1",
            "indices" : [
              "79",
              "102"
            ],
            "url" : "https://t.co/leQ83Dd2nk",
            "media_url" : "http://pbs.twimg.com/media/CziP6eNXgAAn8-1.jpg",
            "id_str" : "808554367817318400",
            "id" : "808554367817318400",
            "media_url_https" : "https://pbs.twimg.com/media/CziP6eNXgAAn8-1.jpg",
            "sizes" : {
              "large" : {
                "w" : "552",
                "h" : "343",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "552",
                "h" : "343",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "552",
                "h" : "343",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/leQ83Dd2nk"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "806684984954253313"
          ],
          "editableUntil" : "2016-12-08T02:51:02.552Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Mike Kasprzak 🦖",
            "screen_name" : "mikekasprzak",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "14368555",
            "id" : "14368555"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "86"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "806666288005337088",
      "id_str" : "806684984954253313",
      "in_reply_to_user_id" : "14368555",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "806684984954253313",
      "in_reply_to_status_id" : "806666288005337088",
      "created_at" : "Thu Dec 08 02:21:02 +0000 2016",
      "favorited" : false,
      "full_text" : "@mikekasprzak Is the clock on the website right?\nIt says there's only 24 hours left...",
      "lang" : "en",
      "in_reply_to_screen_name" : "mikekasprzak",
      "in_reply_to_user_id_str" : "14368555"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "801638818831040513"
          ],
          "editableUntil" : "2016-11-24T04:39:22.795Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Sai",
            "screen_name" : "saizai",
            "indices" : [
              "11",
              "18"
            ],
            "id_str" : "56189468",
            "id" : "56189468"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/801638818831040513/photo/1",
            "indices" : [
              "83",
              "106"
            ],
            "url" : "https://t.co/IJDTIgnALZ",
            "media_url" : "http://pbs.twimg.com/media/Cx_95xpXUAERaGN.jpg",
            "id_str" : "801638427716440065",
            "id" : "801638427716440065",
            "media_url_https" : "https://pbs.twimg.com/media/Cx_95xpXUAERaGN.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "288",
                "h" : "286",
                "resize" : "fit"
              },
              "small" : {
                "w" : "288",
                "h" : "286",
                "resize" : "fit"
              },
              "large" : {
                "w" : "288",
                "h" : "286",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/IJDTIgnALZ"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "106"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "801623655012794368",
      "id_str" : "801638818831040513",
      "in_reply_to_user_id" : "75783213",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "801638818831040513",
      "in_reply_to_status_id" : "801623655012794368",
      "possibly_sensitive" : false,
      "created_at" : "Thu Nov 24 04:09:22 +0000 2016",
      "favorited" : false,
      "full_text" : "@increpare @saizai I want to learn this from you. It's tricky. Am I doing it okay? https://t.co/IJDTIgnALZ",
      "lang" : "en",
      "in_reply_to_user_id_str" : "75783213",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/801638818831040513/photo/1",
            "indices" : [
              "83",
              "106"
            ],
            "url" : "https://t.co/IJDTIgnALZ",
            "media_url" : "http://pbs.twimg.com/media/Cx_95xpXUAERaGN.jpg",
            "id_str" : "801638427716440065",
            "id" : "801638427716440065",
            "media_url_https" : "https://pbs.twimg.com/media/Cx_95xpXUAERaGN.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "288",
                "h" : "286",
                "resize" : "fit"
              },
              "small" : {
                "w" : "288",
                "h" : "286",
                "resize" : "fit"
              },
              "large" : {
                "w" : "288",
                "h" : "286",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/IJDTIgnALZ"
          },
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/801638818831040513/photo/1",
            "indices" : [
              "83",
              "106"
            ],
            "url" : "https://t.co/IJDTIgnALZ",
            "media_url" : "http://pbs.twimg.com/media/Cx_968tWIAA-0bs.jpg",
            "id_str" : "801638447865798656",
            "id" : "801638447865798656",
            "media_url_https" : "https://pbs.twimg.com/media/Cx_968tWIAA-0bs.jpg",
            "sizes" : {
              "large" : {
                "w" : "58",
                "h" : "121",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "58",
                "h" : "58",
                "resize" : "crop"
              },
              "small" : {
                "w" : "58",
                "h" : "121",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "58",
                "h" : "121",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/IJDTIgnALZ"
          },
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/801638818831040513/photo/1",
            "indices" : [
              "83",
              "106"
            ],
            "url" : "https://t.co/IJDTIgnALZ",
            "media_url" : "http://pbs.twimg.com/media/Cx_97sKWEAAJCy0.jpg",
            "id_str" : "801638460603895808",
            "id" : "801638460603895808",
            "media_url_https" : "https://pbs.twimg.com/media/Cx_97sKWEAAJCy0.jpg",
            "sizes" : {
              "large" : {
                "w" : "225",
                "h" : "337",
                "resize" : "fit"
              },
              "small" : {
                "w" : "225",
                "h" : "337",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "225",
                "h" : "337",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/IJDTIgnALZ"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "796598507566198785"
          ],
          "editableUntil" : "2016-11-10T06:50:58.945Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "46"
      ],
      "favorite_count" : "0",
      "id_str" : "796598507566198785",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "796598507566198785",
      "created_at" : "Thu Nov 10 06:20:58 +0000 2016",
      "favorited" : false,
      "full_text" : "/rəˈspänd/ can mean \"comeback\" or \"came back\".",
      "lang" : "fi"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "794755490215501824"
          ],
          "editableUntil" : "2016-11-05T04:47:29.367Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "70"
      ],
      "favorite_count" : "0",
      "id_str" : "794755490215501824",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "794755490215501824",
      "created_at" : "Sat Nov 05 04:17:29 +0000 2016",
      "favorited" : false,
      "full_text" : "Autohomophonological words:\nWE\nNOSY\nWHIRRED\nEYELESS (?)\nEFFEMINATE (?)",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "789587668606877696"
          ],
          "editableUntil" : "2016-10-21T22:32:24.682Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/789587668606877696/photo/1",
            "indices" : [
              "25",
              "48"
            ],
            "url" : "https://t.co/SSQTeCLGqq",
            "media_url" : "http://pbs.twimg.com/media/CvUta1HXEAAgR8s.jpg",
            "id_str" : "789587248631189504",
            "id" : "789587248631189504",
            "media_url_https" : "https://pbs.twimg.com/media/CvUta1HXEAAgR8s.jpg",
            "sizes" : {
              "large" : {
                "w" : "750",
                "h" : "562",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "750",
                "h" : "562",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/SSQTeCLGqq"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "48"
      ],
      "favorite_count" : "0",
      "id_str" : "789587668606877696",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "789587668606877696",
      "possibly_sensitive" : false,
      "created_at" : "Fri Oct 21 22:02:24 +0000 2016",
      "favorited" : false,
      "full_text" : "Wow, what a promotional! https://t.co/SSQTeCLGqq",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/789587668606877696/photo/1",
            "indices" : [
              "25",
              "48"
            ],
            "url" : "https://t.co/SSQTeCLGqq",
            "media_url" : "http://pbs.twimg.com/media/CvUta1HXEAAgR8s.jpg",
            "id_str" : "789587248631189504",
            "id" : "789587248631189504",
            "media_url_https" : "https://pbs.twimg.com/media/CvUta1HXEAAgR8s.jpg",
            "sizes" : {
              "large" : {
                "w" : "750",
                "h" : "562",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "750",
                "h" : "562",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/SSQTeCLGqq"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "784056643071905792"
          ],
          "editableUntil" : "2016-10-06T16:14:05.433Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "0",
      "id_str" : "784056643071905792",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "784056643071905792",
      "created_at" : "Thu Oct 06 15:44:05 +0000 2016",
      "favorited" : false,
      "full_text" : "Lines of \"c\"s in cursive look like seas!",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "782022725334360064"
          ],
          "editableUntil" : "2016-10-01T01:32:01.656Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Heiser Saint",
            "screen_name" : "SaintHeiser",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1335985333",
            "id" : "1335985333"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/esIVHBjobh",
            "expanded_url" : "https://i.gyazo.com/3c55ce8d98cbab8ffe1c12f73958ca4a.png",
            "display_url" : "i.gyazo.com/3c55ce8d98cbab…",
            "indices" : [
              "75",
              "98"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "781916815060504576",
      "id_str" : "782022725334360064",
      "in_reply_to_user_id" : "2444552670",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "782022725334360064",
      "in_reply_to_status_id" : "781916815060504576",
      "possibly_sensitive" : false,
      "created_at" : "Sat Oct 01 01:02:01 +0000 2016",
      "favorited" : false,
      "full_text" : "@SaintHeiser Similar bug on this level unless I missed part of the ruleset\nhttps://t.co/esIVHBjobh\n(pressing down doesn't make yellow move)",
      "lang" : "en",
      "in_reply_to_screen_name" : "Jack_L_Lance",
      "in_reply_to_user_id_str" : "2444552670"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "781916815060504576"
          ],
          "editableUntil" : "2016-09-30T18:31:10.679Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Heiser Saint",
            "screen_name" : "SaintHeiser",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1335985333",
            "id" : "1335985333"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "133"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "781916536273592320",
      "id_str" : "781916815060504576",
      "in_reply_to_user_id" : "2444552670",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "781916815060504576",
      "in_reply_to_status_id" : "781916536273592320",
      "created_at" : "Fri Sep 30 18:01:10 +0000 2016",
      "favorited" : false,
      "full_text" : "@SaintHeiser I believe it should move the green guy and the box left. If I hit right -&gt; left -&gt; left then it works correctly...",
      "lang" : "en",
      "in_reply_to_screen_name" : "Jack_L_Lance",
      "in_reply_to_user_id_str" : "2444552670"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "781916536273592320"
          ],
          "editableUntil" : "2016-09-30T18:30:04.211Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Heiser Saint",
            "screen_name" : "SaintHeiser",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1335985333",
            "id" : "1335985333"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/dict34A417",
            "expanded_url" : "https://i.gyazo.com/29bab255c99b358ba3169be75742796c.png",
            "display_url" : "i.gyazo.com/29bab255c99b35…",
            "indices" : [
              "57",
              "80"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "80"
      ],
      "favorite_count" : "0",
      "id_str" : "781916536273592320",
      "in_reply_to_user_id" : "1335985333",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "781916536273592320",
      "possibly_sensitive" : false,
      "created_at" : "Fri Sep 30 18:00:04 +0000 2016",
      "favorited" : false,
      "full_text" : "@SaintHeiser Hitting left does nothing in this position?\nhttps://t.co/dict34A417",
      "lang" : "en",
      "in_reply_to_screen_name" : "SaintHeiser",
      "in_reply_to_user_id_str" : "1335985333"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "773688199789023233"
          ],
          "editableUntil" : "2016-09-08T01:33:35.918Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "projectyl",
            "screen_name" : "projectyl",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "14076574",
            "id" : "14076574"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "107"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "773338974597156864",
      "id_str" : "773688199789023233",
      "in_reply_to_user_id" : "14076574",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "773688199789023233",
      "in_reply_to_status_id" : "773338974597156864",
      "created_at" : "Thu Sep 08 01:03:35 +0000 2016",
      "favorited" : false,
      "full_text" : "@projectyl \nI got one that says that I'm a Master Actor.\nThe front of it is a much better descriptor of me.",
      "lang" : "en",
      "in_reply_to_screen_name" : "projectyl",
      "in_reply_to_user_id_str" : "14076574"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "767451604580786176"
          ],
          "editableUntil" : "2016-08-21T20:31:35.750Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "1",
      "id_str" : "767451604580786176",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "767451604580786176",
      "created_at" : "Sun Aug 21 20:01:35 +0000 2016",
      "favorited" : false,
      "full_text" : "What's a 3 letter word meaning irritate, besides bug?\nWhat's a 5 letter word meaning land, besides earth?\nReply w/Rot13 to not spoil others.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "767448319299817472"
          ],
          "editableUntil" : "2016-08-21T20:18:32.478Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ivan K | chaotic_iak | Sky_min",
            "screen_name" : "chaotic_iak",
            "indices" : [
              "1",
              "13"
            ],
            "id_str" : "144119186",
            "id" : "144119186"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "108"
      ],
      "favorite_count" : "0",
      "id_str" : "767448319299817472",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "767448319299817472",
      "created_at" : "Sun Aug 21 19:48:32 +0000 2016",
      "favorited" : false,
      "full_text" : ".@chaotic_iak \n\nDancing prom inside trap for malefactors. (6)\nDancing prom inside trap for malefactors. (10)",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "766096176336736256"
          ],
          "editableUntil" : "2016-08-18T02:45:36.474Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "55"
      ],
      "favorite_count" : "1",
      "id_str" : "766096176336736256",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "766096176336736256",
      "created_at" : "Thu Aug 18 02:15:36 +0000 2016",
      "favorited" : false,
      "full_text" : "\"Is large in spain (6)\"\n=\n\" 'Peril', as in a sign (6) \"",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "765643213944287232"
          ],
          "editableUntil" : "2016-08-16T20:45:41.824Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "1",
      "id_str" : "765643213944287232",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "765643213944287232",
      "created_at" : "Tue Aug 16 20:15:41 +0000 2016",
      "favorited" : false,
      "full_text" : "Most perfect pangrams are hard to understand with archaic words or acronyms. Here's the opposite.\nOMGWTF! I C HAX! PLZ NVR! DQS U BYE.... JK",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "765345078651002880"
          ],
          "editableUntil" : "2016-08-16T01:01:00.831Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "64"
      ],
      "favorite_count" : "0",
      "id_str" : "765345078651002880",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "765345078651002880",
      "created_at" : "Tue Aug 16 00:31:00 +0000 2016",
      "favorited" : false,
      "full_text" : "\"Female words: Her, Miss, ...\"\n=\n\"...Damsel, She, Wife, or Mrs.\"",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "765314354417897472"
          ],
          "editableUntil" : "2016-08-15T22:58:55.603Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "99"
      ],
      "favorite_count" : "0",
      "id_str" : "765314354417897472",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "765314354417897472",
      "created_at" : "Mon Aug 15 22:28:55 +0000 2016",
      "favorited" : false,
      "full_text" : "\"He is a stranded Anglo, and a mortified cleric.\"\n=\n\"Instead, is marooned light red-face cardinal.\"",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "764507615640621056"
          ],
          "editableUntil" : "2016-08-13T17:33:14.090Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "2",
      "id_str" : "764507615640621056",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "764507615640621056",
      "created_at" : "Sat Aug 13 17:03:14 +0000 2016",
      "favorited" : false,
      "full_text" : "The past tweet is exactly an arrangement of this.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "764507536900980737"
          ],
          "editableUntil" : "2016-08-13T17:32:55.317Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "2",
      "id_str" : "764507536900980737",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "764507536900980737",
      "created_at" : "Sat Aug 13 17:02:55 +0000 2016",
      "favorited" : false,
      "full_text" : "A tweet that is next perfectly anagrams this one.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "762089675540553728"
          ],
          "editableUntil" : "2016-08-07T01:25:12.247Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "21"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "762082191618740224",
      "id_str" : "762089675540553728",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "762089675540553728",
      "in_reply_to_status_id" : "762082191618740224",
      "created_at" : "Sun Aug 07 00:55:12 +0000 2016",
      "favorited" : false,
      "full_text" : "@edderiofer Still no.",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "762081493862711296"
          ],
          "editableUntil" : "2016-08-07T00:52:41.583Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "22"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "762078127069814784",
      "id_str" : "762081493862711296",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "762081493862711296",
      "in_reply_to_status_id" : "762078127069814784",
      "created_at" : "Sun Aug 07 00:22:41 +0000 2016",
      "favorited" : false,
      "full_text" : "@edderiofer Not quite.",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "762034254561837057"
          ],
          "editableUntil" : "2016-08-06T21:44:58.856Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/762034254561837057/photo/1",
            "indices" : [
              "38",
              "61"
            ],
            "url" : "https://t.co/t5uTIhKaEj",
            "media_url" : "http://pbs.twimg.com/media/CpNKGZTWAAAYc1j.jpg",
            "id_str" : "762034235687436288",
            "id" : "762034235687436288",
            "media_url_https" : "https://pbs.twimg.com/media/CpNKGZTWAAAYc1j.jpg",
            "sizes" : {
              "small" : {
                "w" : "607",
                "h" : "286",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "607",
                "h" : "286",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "607",
                "h" : "286",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/t5uTIhKaEj"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "61"
      ],
      "favorite_count" : "0",
      "id_str" : "762034254561837057",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "762034254561837057",
      "possibly_sensitive" : false,
      "created_at" : "Sat Aug 06 21:14:58 +0000 2016",
      "favorited" : false,
      "full_text" : "(Cont.) Aaaah I've created a monster. https://t.co/t5uTIhKaEj",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/762034254561837057/photo/1",
            "indices" : [
              "38",
              "61"
            ],
            "url" : "https://t.co/t5uTIhKaEj",
            "media_url" : "http://pbs.twimg.com/media/CpNKGZTWAAAYc1j.jpg",
            "id_str" : "762034235687436288",
            "id" : "762034235687436288",
            "media_url_https" : "https://pbs.twimg.com/media/CpNKGZTWAAAYc1j.jpg",
            "sizes" : {
              "small" : {
                "w" : "607",
                "h" : "286",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "607",
                "h" : "286",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "607",
                "h" : "286",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/t5uTIhKaEj"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "762010485411745794"
          ],
          "editableUntil" : "2016-08-06T20:10:31.849Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "137"
      ],
      "favorite_count" : "0",
      "id_str" : "762010485411745794",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "762010485411745794",
      "created_at" : "Sat Aug 06 19:40:31 +0000 2016",
      "favorited" : false,
      "full_text" : "(Cont.) It seems like the kind of thing that someone on the internet already would have thought of and made a list, but I can't find any.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "762010193827885056"
          ],
          "editableUntil" : "2016-08-06T20:09:22.330Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "137"
      ],
      "favorite_count" : "0",
      "id_str" : "762010193827885056",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "762010193827885056",
      "created_at" : "Sat Aug 06 19:39:22 +0000 2016",
      "favorited" : false,
      "full_text" : "Wow. There is a _lot_ of phrases formed with a color and a body part.\nRedneck\nPurple heart\nBluetooth\nYellow belly\nBrown nose\nPinkeye\netc.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "762009300214640640"
          ],
          "editableUntil" : "2016-08-06T20:05:49.276Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "43"
      ],
      "favorite_count" : "0",
      "id_str" : "762009300214640640",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "762009300214640640",
      "created_at" : "Sat Aug 06 19:35:49 +0000 2016",
      "favorited" : false,
      "full_text" : "Red-handed : Green thumb :: White-faced : ?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "759112504522006533"
          ],
          "editableUntil" : "2016-07-29T20:14:59.363Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "133"
      ],
      "favorite_count" : "0",
      "id_str" : "759112504522006533",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "759112504522006533",
      "created_at" : "Fri Jul 29 19:44:59 +0000 2016",
      "favorited" : false,
      "full_text" : "The (_still_ currently unnamed) Puzzlescript game I'm working on just hit 60 levels! Definitely the biggest project I've made so far.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "754757789180887044"
          ],
          "editableUntil" : "2016-07-17T19:50:54.319Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "103"
      ],
      "favorite_count" : "0",
      "id_str" : "754757789180887044",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "754757789180887044",
      "created_at" : "Sun Jul 17 19:20:54 +0000 2016",
      "favorited" : false,
      "full_text" : "For a product that's used to save trees, the Amazon Kindle Fire does not bring the right image to mind.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "747105952009170944"
          ],
          "editableUntil" : "2016-06-26T17:05:14.173Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "119"
      ],
      "favorite_count" : "0",
      "id_str" : "747105952009170944",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "747105952009170944",
      "created_at" : "Sun Jun 26 16:35:14 +0000 2016",
      "favorited" : false,
      "full_text" : "(Last ones, I promise.)\n\nFind the odds of set or having what beats a set. (8)\nTop cards shuffled for cheat use. (3 4 4)",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "746465959817383936"
          ],
          "editableUntil" : "2016-06-24T22:42:08.144Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "99"
      ],
      "favorite_count" : "0",
      "id_str" : "746465959817383936",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "746465959817383936",
      "created_at" : "Fri Jun 24 22:12:08 +0000 2016",
      "favorited" : false,
      "full_text" : "Of Pepsi and Coke's root beers, how did the one that *isn't* called Barq's get the mascot of a dog?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "746040548251828224"
          ],
          "editableUntil" : "2016-06-23T18:31:42.123Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "95"
      ],
      "favorite_count" : "0",
      "id_str" : "746040548251828224",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "746040548251828224",
      "created_at" : "Thu Jun 23 18:01:42 +0000 2016",
      "favorited" : false,
      "full_text" : "Raps and rhapsodies are both styles of music used to convey strong emotion with irregular form.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "746039598854324225"
          ],
          "editableUntil" : "2016-06-23T18:27:55.769Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "0",
      "id_str" : "746039598854324225",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "746039598854324225",
      "created_at" : "Thu Jun 23 17:57:55 +0000 2016",
      "favorited" : false,
      "full_text" : "Five of clubs, spades, and hearts! (3)",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "745059747351560192"
          ],
          "editableUntil" : "2016-06-21T01:34:20.966Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "131"
      ],
      "favorite_count" : "0",
      "id_str" : "745059747351560192",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "745059747351560192",
      "created_at" : "Tue Jun 21 01:04:20 +0000 2016",
      "favorited" : false,
      "full_text" : "I'm not an expert in cryptic clues, so some subset of those might break a rule, but either way, the third one is quite interesting.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "745059433818918912"
          ],
          "editableUntil" : "2016-06-21T01:33:06.214Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "101"
      ],
      "favorite_count" : "0",
      "id_str" : "745059433818918912",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "745059433818918912",
      "created_at" : "Tue Jun 21 01:03:06 +0000 2016",
      "favorited" : false,
      "full_text" : "I flopped KAJ, holding clubs. (4)\n\nCrazy escapades of a real card. (3 2 6)\n\nFlash cards in poker? (5)",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "741791808921931776"
          ],
          "editableUntil" : "2016-06-12T01:08:43.729Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "1",
              "12"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "741767678986211328",
      "id_str" : "741791808921931776",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "741791808921931776",
      "in_reply_to_status_id" : "741767678986211328",
      "created_at" : "Sun Jun 12 00:38:43 +0000 2016",
      "favorited" : false,
      "full_text" : ".@edderiofer Ah. That's valid, but the way to make it 4 different parts of speech is \"fond of\" \"similar to\" \"in the way that\" \"interjection\"",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "741710064487170048"
          ],
          "editableUntil" : "2016-06-11T19:43:54.337Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/s39baqIUsH",
            "expanded_url" : "http://www.puzzlescript.net/play.html?p=4d1368bc277426dbda120ee885f087a4",
            "display_url" : "puzzlescript.net/play.html?p=4d…",
            "indices" : [
              "34",
              "57"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "57"
      ],
      "favorite_count" : "0",
      "id_str" : "741710064487170048",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "741710064487170048",
      "possibly_sensitive" : false,
      "created_at" : "Sat Jun 11 19:13:54 +0000 2016",
      "favorited" : false,
      "full_text" : "Level selection in Puzzlescript:\n\nhttps://t.co/s39baqIUsH",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "741707640556904449"
          ],
          "editableUntil" : "2016-06-11T19:34:16.427Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/0FRjbJEtKl",
            "expanded_url" : "http://www.dictionary.com/browse/like",
            "display_url" : "dictionary.com/browse/like",
            "indices" : [
              "61",
              "84"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "126"
      ],
      "favorite_count" : "0",
      "id_str" : "741707640556904449",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "741707640556904449",
      "possibly_sensitive" : false,
      "created_at" : "Sat Jun 11 19:04:16 +0000 2016",
      "favorited" : false,
      "full_text" : "The word \"like\" can be 7 out of 8 different parts of speech! https://t.co/0FRjbJEtKl\n\nAre there any other words that tie this?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "741707375028113409"
          ],
          "editableUntil" : "2016-06-11T19:33:13.120Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "138"
      ],
      "favorite_count" : "0",
      "id_str" : "741707375028113409",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "741707375028113409",
      "created_at" : "Sat Jun 11 19:03:13 +0000 2016",
      "favorited" : false,
      "full_text" : "In \"I like those people like those people like those people, like, those people are cool\", \"like\" is a different part of speech each time.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "738558617423642625"
          ],
          "editableUntil" : "2016-06-03T03:01:10.806Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/NfnHijykw9",
            "expanded_url" : "https://en.wikipedia.org/wiki/Eternal_return",
            "display_url" : "en.wikipedia.org/wiki/Eternal_r…",
            "indices" : [
              "0",
              "23"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "738558617423642625",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "738558617423642625",
      "possibly_sensitive" : false,
      "created_at" : "Fri Jun 03 02:31:10 +0000 2016",
      "favorited" : false,
      "full_text" : "https://t.co/NfnHijykw9\n\nPhonetically, \"Eternal Return\" is the perfect name for the philosophy that the end loops around to be the beginning",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "736760084689223681"
          ],
          "editableUntil" : "2016-05-29T03:54:27.187Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/736760084689223681/photo/1",
            "indices" : [
              "92",
              "115"
            ],
            "url" : "https://t.co/2rSlHE0eFR",
            "media_url" : "http://pbs.twimg.com/media/Cjl_ZI4XIAAr-po.jpg",
            "id_str" : "736760083909124096",
            "id" : "736760083909124096",
            "media_url_https" : "https://pbs.twimg.com/media/Cjl_ZI4XIAAr-po.jpg",
            "sizes" : {
              "medium" : {
                "w" : "587",
                "h" : "576",
                "resize" : "fit"
              },
              "large" : {
                "w" : "587",
                "h" : "576",
                "resize" : "fit"
              },
              "small" : {
                "w" : "587",
                "h" : "576",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/2rSlHE0eFR"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "115"
      ],
      "favorite_count" : "0",
      "id_str" : "736760084689223681",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "736760084689223681",
      "possibly_sensitive" : false,
      "created_at" : "Sun May 29 03:24:27 +0000 2016",
      "favorited" : false,
      "full_text" : "Screenshot Saturday of what I've been working on.\n(Yes, still technically Saturday for me.) https://t.co/2rSlHE0eFR",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/736760084689223681/photo/1",
            "indices" : [
              "92",
              "115"
            ],
            "url" : "https://t.co/2rSlHE0eFR",
            "media_url" : "http://pbs.twimg.com/media/Cjl_ZI4XIAAr-po.jpg",
            "id_str" : "736760083909124096",
            "id" : "736760083909124096",
            "media_url_https" : "https://pbs.twimg.com/media/Cjl_ZI4XIAAr-po.jpg",
            "sizes" : {
              "medium" : {
                "w" : "587",
                "h" : "576",
                "resize" : "fit"
              },
              "large" : {
                "w" : "587",
                "h" : "576",
                "resize" : "fit"
              },
              "small" : {
                "w" : "587",
                "h" : "576",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/2rSlHE0eFR"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "731285505095159808"
          ],
          "editableUntil" : "2016-05-14T01:20:25.699Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "84"
      ],
      "favorite_count" : "1",
      "id_str" : "731285505095159808",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "731285505095159808",
      "created_at" : "Sat May 14 00:50:25 +0000 2016",
      "favorited" : false,
      "full_text" : "All current presidential candidates have very rebus-y names:\n  D\nALD\n\nS ERS\n\nTO CL N",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "731274291560349696"
          ],
          "editableUntil" : "2016-05-14T00:35:52.184Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "98"
      ],
      "favorite_count" : "0",
      "id_str" : "731274291560349696",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "731274291560349696",
      "created_at" : "Sat May 14 00:05:52 +0000 2016",
      "favorited" : false,
      "full_text" : "I don't know the answer, but  I'll give you the (very easy) hint that the answer is either 3 or 4.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "731273996025520128"
          ],
          "editableUntil" : "2016-05-14T00:34:41.723Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "731273996025520128",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "731273996025520128",
      "created_at" : "Sat May 14 00:04:41 +0000 2016",
      "favorited" : false,
      "full_text" : "How many colors are needed in the area between circles of radii rt(3)/3 and rt(3)/2.9999 so pairs of points with distance 1 aren't the same?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "724623699127734272"
          ],
          "editableUntil" : "2016-04-25T16:08:47.386Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Alan Hazelden/Draknek & Friends",
            "screen_name" : "Draknek",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "17040610",
            "id" : "17040610"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "129"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "724442546869559297",
      "id_str" : "724623699127734272",
      "in_reply_to_user_id" : "17040610",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "724623699127734272",
      "in_reply_to_status_id" : "724442546869559297",
      "created_at" : "Mon Apr 25 15:38:47 +0000 2016",
      "favorited" : false,
      "full_text" : "@Draknek If you're looking for impossible, I recommend Fish Fillets NG or some games by Zachtronics. (KOHCTPYKTOP, TIS-100, etc.)",
      "lang" : "en",
      "in_reply_to_screen_name" : "Draknek",
      "in_reply_to_user_id_str" : "17040610"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "719258292355276800"
          ],
          "editableUntil" : "2016-04-10T20:48:34.727Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "92"
      ],
      "favorite_count" : "2",
      "id_str" : "719258292355276800",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "719258292355276800",
      "created_at" : "Sun Apr 10 20:18:34 +0000 2016",
      "favorited" : false,
      "full_text" : "Here's a pangram, and also a puzzle! The answer is a board game.\n\nSHIFTCZEWAKRLGDQNMJOUPBYXV",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "717550143462096897"
          ],
          "editableUntil" : "2016-04-06T03:41:00.295Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "109"
      ],
      "favorite_count" : "0",
      "id_str" : "717550143462096897",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "717550143462096897",
      "created_at" : "Wed Apr 06 03:11:00 +0000 2016",
      "favorited" : false,
      "full_text" : "Somewhat related, the \"Nintendo Network\" has 3 numbers in the name!\n\nIt's only 1 letter away from having 4!!!",
      "lang" : "en",
      "contributors" : [
        "715607955903799296"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "717549556347625473"
          ],
          "editableUntil" : "2016-04-06T03:38:40.316Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "MathematicianGameConsoles",
            "indices" : [
              "9",
              "35"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "id_str" : "717549556347625473",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "717549556347625473",
      "created_at" : "Wed Apr 06 03:08:40 +0000 2016",
      "favorited" : false,
      "full_text" : "Xbox Tau\n#MathematicianGameConsoles",
      "lang" : "de",
      "contributors" : [
        "715607955903799296"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "717549460885278721"
          ],
          "editableUntil" : "2016-04-06T03:38:17.556Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "MathematicianGameConsoles",
            "indices" : [
              "17",
              "43"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "43"
      ],
      "favorite_count" : "0",
      "id_str" : "717549460885278721",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "717549460885278721",
      "created_at" : "Wed Apr 06 03:08:17 +0000 2016",
      "favorited" : false,
      "full_text" : "GameDodecahedron\n#MathematicianGameConsoles",
      "lang" : "cy",
      "contributors" : [
        "715607955903799296"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "717549092361093120"
          ],
          "editableUntil" : "2016-04-06T03:36:49.693Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "MathematicianGameConsoles",
            "indices" : [
              "3",
              "29"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "0",
      "id_str" : "717549092361093120",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "717549092361093120",
      "created_at" : "Wed Apr 06 03:06:49 +0000 2016",
      "favorited" : false,
      "full_text" : "-W\n#MathematicianGameConsoles",
      "lang" : "und",
      "contributors" : [
        "715607955903799296"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "717549003680911360"
          ],
          "editableUntil" : "2016-04-06T03:36:28.550Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "MathematicianGameConsoles",
            "indices" : [
              "14",
              "40"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "0",
      "id_str" : "717549003680911360",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "717549003680911360",
      "created_at" : "Wed Apr 06 03:06:28 +0000 2016",
      "favorited" : false,
      "full_text" : "PlatoStation \n#MathematicianGameConsoles",
      "lang" : "en",
      "contributors" : [
        "715607955903799296"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "717548774567112705"
          ],
          "editableUntil" : "2016-04-06T03:35:33.925Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "MathematicianGameConsoles",
            "indices" : [
              "4",
              "30"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "0",
      "id_str" : "717548774567112705",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "717548774567112705",
      "created_at" : "Wed Apr 06 03:05:33 +0000 2016",
      "favorited" : false,
      "full_text" : "4DS #MathematicianGameConsoles",
      "lang" : "und",
      "contributors" : [
        "715607955903799296"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "715590879705219072"
          ],
          "editableUntil" : "2016-03-31T17:55:35.414Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "119"
      ],
      "favorite_count" : "1",
      "id_str" : "715590879705219072",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "715590879705219072",
      "created_at" : "Thu Mar 31 17:25:35 +0000 2016",
      "favorited" : false,
      "full_text" : "It's called \"table salt\" because it goes on the table.\n\n...but then why is the thing next to it called \"ground pepper\"?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "715425023125823488"
          ],
          "editableUntil" : "2016-03-31T06:56:32.124Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "715425023125823488",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "715425023125823488",
      "created_at" : "Thu Mar 31 06:26:32 +0000 2016",
      "favorited" : false,
      "full_text" : "I ﬁt in over one-ﬁﬅy-ﬁve chars, beneﬁtting suﬃciently from speciﬁc ﬁgures with f as the ﬁrst letter aﬃxed on the leﬅ to ﬁll space eﬃciently.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "709411278234787840"
          ],
          "editableUntil" : "2016-03-14T16:40:03.612Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/O5ligDoqdp",
            "expanded_url" : "https://jacoblance.wordpress.com/2016/03/14/p-i-hunt-2/",
            "display_url" : "jacoblance.wordpress.com/2016/03/14/p-i…",
            "indices" : [
              "12",
              "35"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "1",
      "id_str" : "709411278234787840",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "709411278234787840",
      "possibly_sensitive" : false,
      "created_at" : "Mon Mar 14 16:10:03 +0000 2016",
      "favorited" : false,
      "full_text" : "P.I.Hunt 2!\nhttps://t.co/O5ligDoqdp",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "707042985167495168"
          ],
          "editableUntil" : "2016-03-08T03:49:18.544Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/mBdWRfrs63",
            "expanded_url" : "https://i.gyazo.com/0448c48d877ca2ac88db0ef3ff54ae28.png",
            "display_url" : "i.gyazo.com/0448c48d877ca2…",
            "indices" : [
              "0",
              "23"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "88"
      ],
      "favorite_count" : "0",
      "id_str" : "707042985167495168",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "707042985167495168",
      "possibly_sensitive" : false,
      "created_at" : "Tue Mar 08 03:19:18 +0000 2016",
      "favorited" : false,
      "full_text" : "https://t.co/mBdWRfrs63\n\nPI HUNT TWO SHOWS UP IN ~1 week!\n\n(That's a letterlink puzzle.)",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "706309986998218752"
          ],
          "editableUntil" : "2016-03-06T03:16:38.162Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "91"
      ],
      "favorite_count" : "0",
      "id_str" : "706309986998218752",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "706309986998218752",
      "created_at" : "Sun Mar 06 02:46:38 +0000 2016",
      "favorited" : false,
      "full_text" : "\"He's got her nose.\" could be said about a mother and her child, or a father and his child.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "705177227034550272"
          ],
          "editableUntil" : "2016-03-03T00:15:27.141Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "120"
      ],
      "favorite_count" : "0",
      "id_str" : "705177227034550272",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "705177227034550272",
      "created_at" : "Wed Mar 02 23:45:27 +0000 2016",
      "favorited" : false,
      "full_text" : "Both roombas and goombas exist for the sole purpose of walking back and forth on all of the ground that they can access.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "705168703437086725"
          ],
          "editableUntil" : "2016-03-02T23:41:34.957Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/705168703437086725/photo/1",
            "indices" : [
              "27",
              "50"
            ],
            "url" : "https://t.co/jTjCLb6fcj",
            "media_url" : "http://pbs.twimg.com/media/CclDMuZXEAAntXp.jpg",
            "id_str" : "705168702552084480",
            "id" : "705168702552084480",
            "media_url_https" : "https://pbs.twimg.com/media/CclDMuZXEAAntXp.jpg",
            "sizes" : {
              "large" : {
                "w" : "469",
                "h" : "436",
                "resize" : "fit"
              },
              "small" : {
                "w" : "469",
                "h" : "436",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "469",
                "h" : "436",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/jTjCLb6fcj"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "50"
      ],
      "favorite_count" : "1",
      "id_str" : "705168703437086725",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "705168703437086725",
      "possibly_sensitive" : false,
      "created_at" : "Wed Mar 02 23:11:34 +0000 2016",
      "favorited" : false,
      "full_text" : "tERRible programming puns! https://t.co/jTjCLb6fcj",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Jack_L_Lance/status/705168703437086725/photo/1",
            "indices" : [
              "27",
              "50"
            ],
            "url" : "https://t.co/jTjCLb6fcj",
            "media_url" : "http://pbs.twimg.com/media/CclDMuZXEAAntXp.jpg",
            "id_str" : "705168702552084480",
            "id" : "705168702552084480",
            "media_url_https" : "https://pbs.twimg.com/media/CclDMuZXEAAntXp.jpg",
            "sizes" : {
              "large" : {
                "w" : "469",
                "h" : "436",
                "resize" : "fit"
              },
              "small" : {
                "w" : "469",
                "h" : "436",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "469",
                "h" : "436",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/jTjCLb6fcj"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "704779957013192704"
          ],
          "editableUntil" : "2016-03-01T21:56:50.587Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/4sNJyO7FiM",
            "expanded_url" : "http://www.puzzlescript.net/play.html?p=cb143ba29445568664d5",
            "display_url" : "puzzlescript.net/play.html?p=cb…",
            "indices" : [
              "24",
              "47"
            ]
          },
          {
            "url" : "https://t.co/HIBsHEszD6",
            "expanded_url" : "http://www.puzzlescript.net/play.html?p=4ceab0fa88f6502c06fb",
            "display_url" : "puzzlescript.net/play.html?p=4c…",
            "indices" : [
              "48",
              "71"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "71"
      ],
      "favorite_count" : "0",
      "id_str" : "704779957013192704",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "704779957013192704",
      "possibly_sensitive" : false,
      "created_at" : "Tue Mar 01 21:26:50 +0000 2016",
      "favorited" : false,
      "full_text" : "Two interesting levels:\nhttps://t.co/4sNJyO7FiM\nhttps://t.co/HIBsHEszD6",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "703694672275881984"
          ],
          "editableUntil" : "2016-02-27T22:04:18.542Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/3D78nymadb",
            "expanded_url" : "http://www.puzzlescript.net/play.html?p=d8a3643a693940739a29",
            "display_url" : "puzzlescript.net/play.html?p=d8…",
            "indices" : [
              "11",
              "34"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "34"
      ],
      "favorite_count" : "1",
      "id_str" : "703694672275881984",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "703694672275881984",
      "possibly_sensitive" : false,
      "created_at" : "Sat Feb 27 21:34:18 +0000 2016",
      "favorited" : false,
      "full_text" : "Game idea:\nhttps://t.co/3D78nymadb",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "698972489976832000"
          ],
          "editableUntil" : "2016-02-14T21:20:02.548Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "132"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "698972329095884803",
      "id_str" : "698972489976832000",
      "in_reply_to_user_id" : "2444552670",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "698972489976832000",
      "in_reply_to_status_id" : "698972329095884803",
      "created_at" : "Sun Feb 14 20:50:02 +0000 2016",
      "favorited" : false,
      "full_text" : "@edderiofer Mostly just because I think that if you allow for different spacings, there will be a ton of different things that work.",
      "lang" : "en",
      "in_reply_to_screen_name" : "Jack_L_Lance",
      "in_reply_to_user_id_str" : "2444552670"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "698972329095884803"
          ],
          "editableUntil" : "2016-02-14T21:19:24.191Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "132"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "698971908008714240",
      "id_str" : "698972329095884803",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "698972329095884803",
      "in_reply_to_status_id" : "698971908008714240",
      "created_at" : "Sun Feb 14 20:49:24 +0000 2016",
      "favorited" : false,
      "full_text" : "@edderiofer I know. I meant I prefer strictly different pronunciations, rather than different pronunciations and different spacings.",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "698963889963274241"
          ],
          "editableUntil" : "2016-02-14T20:45:52.145Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "137"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "698947774730104834",
      "id_str" : "698963889963274241",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "698963889963274241",
      "in_reply_to_status_id" : "698947774730104834",
      "created_at" : "Sun Feb 14 20:15:52 +0000 2016",
      "favorited" : false,
      "full_text" : "@edderiofer  I'm more interested in  pronunciations that differ in amounts of syllables, rather than respacings. I can only find those 3!",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "698895226392481792"
          ],
          "editableUntil" : "2016-02-14T16:13:01.474Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "74"
      ],
      "favorite_count" : "0",
      "id_str" : "698895226392481792",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "698895226392481792",
      "created_at" : "Sun Feb 14 15:43:01 +0000 2016",
      "favorited" : false,
      "full_text" : "Besides \"resume\", \"evening\" and \"moped\", do any other words work that way?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "698586902044274688"
          ],
          "editableUntil" : "2016-02-13T19:47:51.221Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "66"
      ],
      "favorite_count" : "2",
      "id_str" : "698586902044274688",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "698586902044274688",
      "created_at" : "Sat Feb 13 19:17:51 +0000 2016",
      "favorited" : false,
      "full_text" : "A haiku:\n\nResume the evening\nEvening the resume\nResume the evening",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "698158653317193729"
          ],
          "editableUntil" : "2016-02-12T15:26:08.768Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "id_str" : "698158653317193729",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "698158653317193729",
      "created_at" : "Fri Feb 12 14:56:08 +0000 2016",
      "favorited" : false,
      "full_text" : "Twenty-nine letters, twelve unique.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "696781478496202752"
          ],
          "editableUntil" : "2016-02-08T20:13:44.704Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "32"
      ],
      "favorite_count" : "2",
      "id_str" : "696781478496202752",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "696781478496202752",
      "created_at" : "Mon Feb 08 19:43:44 +0000 2016",
      "favorited" : false,
      "full_text" : "Universal formula:\ncos(m)•log(y)",
      "lang" : "es"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "696514390749741056"
          ],
          "editableUntil" : "2016-02-08T02:32:26.023Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "edderiofer",
            "screen_name" : "edderiofer",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "56060517",
            "id" : "56060517"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "44"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "696507455568793600",
      "id_str" : "696514390749741056",
      "in_reply_to_user_id" : "56060517",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "696514390749741056",
      "in_reply_to_status_id" : "696507455568793600",
      "created_at" : "Mon Feb 08 02:02:26 +0000 2016",
      "favorited" : false,
      "full_text" : "@edderiofer\nIsn't it 4?\n'D' 'o' 'b' and 'a'?",
      "lang" : "en",
      "in_reply_to_screen_name" : "edderiofer",
      "in_reply_to_user_id_str" : "56060517"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "696467143106392065"
          ],
          "editableUntil" : "2016-02-07T23:24:41.307Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "59"
      ],
      "favorite_count" : "1",
      "id_str" : "696467143106392065",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "696467143106392065",
      "created_at" : "Sun Feb 07 22:54:41 +0000 2016",
      "favorited" : false,
      "full_text" : "The phrase \"Disco ball\" consists entirely of three circles.",
      "lang" : "en"
    }
  }
]