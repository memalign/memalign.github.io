window.YTD.account_creation_ip.part0 = [
  {
    "accountCreationIp" : {
      "accountId" : "2444552670",
      "userCreationIp" : "24.62.126.112"
    }
  }
]