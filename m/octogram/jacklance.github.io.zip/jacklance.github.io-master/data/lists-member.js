window.YTD.lists_member.part0 = [
  {
    "userListInfo" : {
      "url" : "https://twitter.com/taletronic/lists/1494364891750313987"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/feytful/lists/puzzles"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/qwaffles_/lists/thinky-puzzle-games"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/wand_125/lists/puzzle"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/uam/lists/puzzles"
    }
  }
]