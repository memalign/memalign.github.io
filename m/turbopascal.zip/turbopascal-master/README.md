Turbo Pascal Compiler
---------------------

This is a web-based Pascal compiler that runs a subset of Turbo Pascal 5.5 code.
See the [full write-up](http://www.teamten.com/lawrence/projects/turbo_pascal_compiler/) or
[try it now](http://lkesteloot.github.io/turbopascal/)!

To run it locally, run the "GO" script to start a web server and go to
http://localhost:8000

Go to http://localhost:8000/unit.html to run the unit tests.

See the LICENSE file for the BSD 2-clause license.
