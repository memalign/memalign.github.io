
#import <UIKit/UIKit.h>

@interface LOGlareView : UIView {
}
@end
