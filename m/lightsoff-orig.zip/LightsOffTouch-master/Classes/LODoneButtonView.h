
#import <UIKit/UIKit.h>

@interface LODoneButtonView : UIView {
    BOOL pressed;
}
@end
