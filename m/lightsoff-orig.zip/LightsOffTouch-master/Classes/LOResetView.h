
#import <UIKit/UIKit.h>

@interface LOResetView : UIView {
    BOOL pressed;
}
@end
