
#import <UIKit/UIKit.h>

@interface LOInfoView : UIView {
}
@end
