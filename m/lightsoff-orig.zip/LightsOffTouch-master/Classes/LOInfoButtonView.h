
#import <UIKit/UIKit.h>

@interface LOInfoButtonView : UIView {
    BOOL pressed;
}
@end
