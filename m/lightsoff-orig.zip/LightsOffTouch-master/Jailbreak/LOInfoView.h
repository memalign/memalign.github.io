#import <UIKit/UIKit.h>
#import <UIKit/UIView.h>

@interface LOInfoView : UIView {
}
@end
