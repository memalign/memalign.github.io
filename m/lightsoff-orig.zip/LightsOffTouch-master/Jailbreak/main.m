#import <UIKit/UIKit.h>

#import "LOController.h"

int main(int argc, char **argv)
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    return UIApplicationMain(argc, argv, [LOController class]);
    [pool release];
}
