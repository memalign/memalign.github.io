#import <UIKit/UIKit.h>
#import <UIKit/UIView.h>

@interface LOInfoButtonView : UIView {
    BOOL pressed;
}
@end
