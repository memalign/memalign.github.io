#import <UIKit/UIKit.h>
#import <UIKit/UIView.h>

@interface LOGlareView : UIView {
}
@end
