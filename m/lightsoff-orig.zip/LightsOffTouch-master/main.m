//
//  main.m
//  LightsOffTouch
//
//  Created by Craig Hockenberry on 6/6/08.
//  Copyright The Iconfactory 2008. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
	
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"LightsOffTouchAppDelegate");
	[pool release];
	return retVal;
}
