# Lights Off

This is the source code for the first iPhone game created with UIKit. It was originally written by Lucas Newman in 2008.

The app in the Classes folder is an adaptation of the original in the Jailbreak folder. I've endeavored to leave the code as-is, but some changes were needed to build and run using modern tools. Use `diff` to see what I've changed.

This app was resurected to celebrate the [10th anniversary of the iPhone SDK]( https://blog.iconfactory.com/2018/03/a-lot-can-happen-in-a-decade/).

